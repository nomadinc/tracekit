WS-024 independent native timestamp regression at 135aab4467ab8b4d48f73695d6b88af6802db69f

Read REPORT.txt and execution-summary.json. The timestamp correction passes. NI-DB-001 remains OPEN; a new client timing miss and old unexplained literal timeout are preserved. Diagnostic runner exit 0 is not deadline acceptance.

Verified input: ws001-lossless-timestamp.bundle
SHA-256 e52606facaf8e55b2fe2d55fd23a6f879057bd9835493a984b6797319a5575b5
Detached checkout /private/tmp/ws024-timestamp-candidate at exact SHA. git fsck --full passes. Runtime code, prepared SQL, migrations, frozen vectors and contract unchanged from e8d2252. ui/node_modules symlinks /Users/nomadm/Projects/tracekit-ws024-security-review/ui/node_modules; no clean dependency installation claimed.

Executed dedicated synthetic local cluster:
docker run --name ws024-lossless-timestamp-postgres -e POSTGRES_HOST_AUTH_METHOD=trust -p 127.0.0.1:56862:5432 -d postgres:17 -c log_statement=none -c log_min_error_statement=panic -c log_parameter_max_length=0 -c log_parameter_max_length_on_error=0

After readiness, created EMPTY ni_disposable_lossless_suite in this new cluster. Existing NI roles must not be present. No production or shared database is permitted. Only native-suite fixture setup installs schema/roles; independent checks are read-only.

From candidate/ui, executed unchanged suite:
NI_NATIVE_TEST_URL=postgresql://postgres@127.0.0.1:56862/ni_disposable_lossless_suite NI_NATIVE_DISPOSABLE=synthetic-only node --import tsx --test tests/network-intelligence-security-database.test.mjs
Captured native-suite.log: 55 PASS / 0 FAIL / 0 SKIP, exit 0, 28.492s. Historical 53 PASS / 1 FAIL log/archive remains unchanged. No candidate test or implementation was edited.

From the WS-024 repository root, executed the independent checks below with candidate's tsx loader:
node --import /private/tmp/ws024-timestamp-candidate/ui/node_modules/tsx/dist/loader.mjs docs/operations/evidence/ws024-lossless-135aab4/verify-timestamps.mjs
node --import /private/tmp/ws024-timestamp-candidate/ui/node_modules/tsx/dist/loader.mjs docs/operations/evidence/ws024-lossless-135aab4/timeout-investigation.mjs

These read-only checks used separate native backend connections and were launched concurrently after the suite completed. Client timing may include external scheduling; no cause or backend duration is inferred from that fact. Raw stdout/stderr are timestamps.log and timeout-investigation.log; structured outputs are timestamp-results.json and timeout-results.json. Both processes exit 0; the latter intentionally records diagnostic behavior without declaring a timing PASS. execution-summary.json explicitly evaluates and retains the failed prior 7–9s window for its 9.337s sample.

verify-timestamps.mjs uses the candidate's exact extraction query, parseExact/normalizeRecord/digest and exact count of 3 rows. It captures native record_json text and both hashes, plus native JSON-text extraction for .000001/.123456/.999999. Date is only an explicitly named lossy negative control. The corrected candidate assertion checks all three original stored digests without altering expected data; assertion-diff.patch preserves the precise change.

timeout-investigation.mjs reads the exact historical failing SELECT in literal-query.original.sql. Its controls preserve raw JSON numeric tokens and query structure: original cold/warm literal, EXPLAIN VERBOSE without ANALYZE, identical-shape parameterization, requested force_generic_plan, direct parameterized digest, separately pre-armed pg_sleep(9) and same-command GUC pg_sleep(9) starting with timeout 0. All nine controls run BEGIN READ ONLY / ROLLBACK as ni_integrity_writer, with exactly recorded settings and monotonic client timings. Ten protected-table count/full-content hashes match before/after. The read-only timer controls are not actual current ingestion/Core route executions. No function, schema, grants or persistence writer is created/modified by them.

The suite leaves its disposable database safely paused; independent checks need only read/helper access and do not restore runtime grants. The cluster/database and source checkout are retained for review. Do not replay a fixture-creating suite against an already-populated database. To reproduce elsewhere, create a NEW isolated cluster and empty ni_disposable_* database, verify the same candidate, adjust only independent harness path/loopback fixture names, preserve each output separately and keep historical logs sealed. Never substitute production credentials.

Historical actual Core TLS execution, function-only failure and pre-armed control logs are verbatim copies labeled historical. They are not fresh tests. transport-source-comparison.json confirms current transport files equal historical actual-adapter source 55759aa byte-for-byte; this is source provenance, not new transport acceptance. Installed current ingest proconfig is in timeout metadata (lock_timeout only). Raw plan outputs/settings are evidence, not proof of a root cause for the earlier intermittent timeout.

SHA256SUMS covers all payload files; archive checksum sidecar covers the archive including the manifest. Copies under fixtures/ preserve source bytes. file-provenance.json lists hashes and original locations. Historical archive/log integrity is recorded separately. No external upload or communication is authorized/inferred from earlier publication tasks; this candidate's evidence is local. Production V1 HOLD.
