import {Client} from 'pg';
import {ContractError} from './integrity.ts';
import type {SecureConnection} from './core.ts';
export type ConnectionConfig={host:string;port:number;database:string;user:string;password:string;ca:string;environment:string;telemetryApprovalRef:string};
export interface Driver {
 connect():Promise<void>;
 query(config:{text:string;values:unknown[]}):Promise<{rows:Record<string,unknown>[]} >;
 end():Promise<void>;
 on(event:string,listener:()=>void):unknown;
}
export type DriverFactory=(config:Record<string,unknown>)=>Driver;
export type ManagedConnection=SecureConnection & {dispose():Promise<void>};
const sanitized=(error:unknown)=>new ContractError(error&&typeof error==='object'&&'code'in error&&['28000','42501','23505','22023','40001','40P01','55P03','57014'].includes(String(error.code))?String(error.code):'TRANSPORT');
/** Direct transport; no connection URL capable of overriding TLS options is accepted. */
export async function openSecureConnection(config:ConnectionConfig,factory:DriverFactory=c=>new Client(c) as unknown as Driver,deadlineMs=10000):Promise<ManagedConnection>{
 if(!config.host||config.host.startsWith('/')||!Number.isInteger(config.port)||config.port<1||config.port>65535||!config.database||!config.password||!config.user||['postgres','service_role','supabase_admin','ni_integrity_writer','ni_controller_writer'].includes(config.user)||!config.ca.includes('BEGIN CERTIFICATE')||!config.telemetryApprovalRef||!/^[a-z][a-z0-9_-]{0,31}$/.test(config.environment))throw new ContractError('TRANSPORT_CONFIG');
 const client=factory({host:config.host,port:config.port,database:config.database,user:config.user,password:config.password,ssl:{rejectUnauthorized:true,ca:config.ca,servername:config.host},connectionTimeoutMillis:2000,statement_timeout:8000,lock_timeout:2000,query_timeout:8000,application_name:'tracekit-ni-model-b',client_encoding:'UTF8'});
 let terminal=false,timer:ReturnType<typeof setTimeout>|undefined,deadline:Promise<never>|undefined;
 const close=()=>{terminal=true;if(timer)clearTimeout(timer);return client.end().catch(()=>undefined);};
 client.on('error',()=>{void close();});
 try{
  await client.connect();
  const result=await client.query({text:`select current_user as identity,r.rolsuper,r.rolbypassrls,
   pg_has_role(current_user,'ni_integrity_writer','MEMBER') as writer_member,pg_has_role(current_user,'ni_controller_writer','MEMBER') as controller_member,
   current_setting('log_statement') as log_statement,current_setting('log_min_error_statement') as log_min_error_statement,
   current_setting('log_parameter_max_length') as parameter_length,current_setting('log_parameter_max_length_on_error') as error_parameter_length,
   current_setting('pgaudit.log',true) as audit_log from pg_roles r where r.rolname=current_user`,values:[]});
  const s=result.rows[0];
  if(!s||s.identity!==config.user||s.rolsuper!==false||s.rolbypassrls!==false||s.writer_member!==false||s.controller_member!==false||s.log_statement!=='none'||!['panic','fatal'].includes(String(s.log_min_error_statement))||String(s.parameter_length)!=='0'||String(s.error_parameter_length)!=='0'||s.audit_log!=null&&s.audit_log!=='none')throw new ContractError('TELEMETRY_OR_ROLE');
 }catch(error){await close();throw sanitized(error);}
 const query:SecureConnection['query']=async(text,values)=>{
  if(terminal)throw new ContractError('CONNECTION_CLOSED');
  if(text.trim().toLowerCase()==='begin'){
   if(deadline)throw new ContractError('TRANSACTION');
   deadline=new Promise<never>((_,reject)=>{timer=setTimeout(()=>{terminal=true;reject(new ContractError('TRANSACTION_DEADLINE'));void client.end().catch(()=>undefined);},deadlineMs);});
   void deadline.catch(()=>undefined);
  }
  try{
   const operation=client.query({text,values});const result=await(deadline?Promise.race([operation,deadline]):operation);
   if(terminal)throw new ContractError('CONNECTION_CLOSED');
   if(['commit','rollback'].includes(text.trim().toLowerCase())&&timer){clearTimeout(timer);timer=undefined;}
   return result;
  }catch(error){await close();throw sanitized(error);}
 };
 return{query,tlsVerified:true,parameterCaptureDisabled:true,errorCaptureDisabled:true,dispose:close};
}
