import { createHash, createHmac, createPublicKey, verify } from 'node:crypto';

export const PROFILE = 'NI-IMM-DIGEST-v1/typed-tree-1';
export class ContractError extends Error {
  readonly code:string;
  constructor(code: string) { super(code); this.code=code; }
}
const fail = (code: string): never => { throw new ContractError(code); };
export class ExactNumber {
  readonly decimal: string;
  constructor(token: string) {
    if (token.length > 4096 || !/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(token)) fail('NUMBER');
    const [mantissa, e = '0'] = token.toLowerCase().split('e');
    if (Math.abs(Number(e)) > 4096) fail('NUMBER');
    const negative = mantissa[0] === '-';
    const [whole, fraction = ''] = (negative ? mantissa.slice(1) : mantissa).split('.');
    const digits = whole + fraction;
    const point = whole.length + Number(e);
    let result = point <= 0 ? '0.' + '0'.repeat(-point) + digits : point >= digits.length ? digits + '0'.repeat(point-digits.length) : digits.slice(0,point)+'.'+digits.slice(point);
    result = result.replace(/^0+(?=\d)/, '');
    if (result.includes('.')) result = result.replace(/0+$/, '').replace(/\.$/, '');
    if (/^0(?:\.0*)?$/.test(result)) result = '0';
    else if (negative) result = '-' + result;
    if (result.length > 4096) fail('NUMBER');
    this.decimal = result;
  }
  toString():string { return this.decimal; }
}
export type ExactValue = null | boolean | string | number | bigint | ExactNumber | ExactValue[] | { [key: string]: ExactValue };

/** Parse before JSONB or JSON.parse: retain decimals and reject duplicate decoded keys. */
export function parseExact(text: string): ExactValue {
  if (Buffer.byteLength(text) > 1024 * 1024 || text.charCodeAt(0) === 0xfeff) fail('JSON');
  let i = 0;
  const ws = () => { while (/^[\t\r\n ]$/.test(text[i] ?? '')) i++; };
  const string = () => {
    const start = i++;
    while (i < text.length) {
      if (text[i] === '\\') { i += 2; continue; }
      if (text[i++] === '"') { const s = JSON.parse(text.slice(start, i)); quote(s); return s as string; }
    }
    return fail('JSON');
  };
  const read = (depth: number): ExactValue => {
    if (depth > 64) fail('DEPTH');
    ws();
    if (text[i] === '"') return string();
    if (text[i] === '{') {
      i++; ws(); const out = Object.create(null) as Record<string, ExactValue>;
      if (text[i] === '}') { i++; return out; }
      for (;;) {
        ws(); if (text[i] !== '"') fail('JSON'); const k=string();
        if (Object.hasOwn(out,k)) fail('DUPLICATE_KEY'); ws(); if(text[i++]!==':')fail('JSON'); out[k]=read(depth+1); ws();
        const c=text[i++]; if(c==='}')return out; if(c!==',')fail('JSON');
      }
    }
    if (text[i] === '[') {
      i++; ws(); const out:ExactValue[]=[]; if(text[i]===']'){i++;return out;}
      for(;;){out.push(read(depth+1));ws();const c=text[i++];if(c===']')return out;if(c!==',')fail('JSON');}
    }
    for(const [literal,value] of [['true',true],['false',false],['null',null]] as const)if(text.startsWith(literal,i)){i+=literal.length;return value;}
    const n=text.slice(i).match(/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/);
    if(!n)return fail('JSON');i+=n[0].length;return new ExactNumber(n[0]);
  };
  try { const value=read(0); ws(); if(i!==text.length)fail('JSON');return value; }
  catch { return fail('INVALID_JSON'); } // Never include input or parser diagnostics.
}
function quote(s:string):string {
  let result='"';
  for(const c of s){const cp=c.codePointAt(0)!;if(cp>=0xd800&&cp<=0xdfff)fail('UNICODE');result+=c==='"'?'\\"':c==='\\'?'\\\\':cp<32?'\\u'+cp.toString(16).padStart(4,'0'):c;}
  return result+'"';
}
export function canonical(value:ExactValue):string {
  const walk=(v:ExactValue,d:number):string=>{
    if(d>64)fail('DEPTH');
    if(v===null)return '["z"]';
    if(typeof v==='boolean')return '["b",'+v+']';
    if(typeof v==='string')return '["s",'+quote(v)+']';
    if(v instanceof ExactNumber)return '["n",'+quote(v.decimal)+']';
    if(typeof v==='bigint')return '["n",'+quote(new ExactNumber(String(v)).decimal)+']';
    if(typeof v==='number'){if(!Number.isSafeInteger(v))fail('LOSSY_NUMBER');return '["n",'+quote(String(v))+']';}
    if(Array.isArray(v))return '["a",['+v.map(x=>walk(x,d+1)).join(',')+']]';
    if(typeof v!=='object'||(Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null))return fail('TYPE');
    return '["o",['+Object.keys(v).sort((a,b)=>Buffer.compare(Buffer.from(a),Buffer.from(b))).map(k=>'['+quote(k)+','+walk(v[k],d+1)+']').join(',')+']]';
  };
  return walk(value,0);
}
export const frame=(type:string,value:ExactValue):Buffer=>{
  if(!/^[a-z][a-z_]*$/.test(type))fail('RECORD_TYPE');
  return Buffer.from('NI-IMM-DIGEST-v1\n'+type+'\n'+canonical(value),'utf8');
};
export const digest=(type:string,value:ExactValue):string=>createHash('sha256').update(frame(type,value)).digest('hex');
export function normalizeTimestamp(input:string):string {
  const m=input.match(/^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.(\d{1,6}))?(Z|[+-]\d\d:\d\d)$/);
  if(!m)return fail('TIMESTAMP');
  const [year,month,day,hour,minute,second]=m.slice(1,7).map(Number);
  const local=new Date(0);local.setUTCFullYear(year,month-1,day);local.setUTCHours(hour,minute,second,0);
  if(year<1||year>9999||local.getUTCFullYear()!==year||local.getUTCMonth()!==month-1||local.getUTCDate()!==day||hour>23||minute>59||second>59)fail('TIMESTAMP');
  const off=m[8];let delta=0;if(off!=='Z'){const h=Number(off.slice(1,3)),min=Number(off.slice(4,6));if(h>14||min>59||(h===14&&min))fail('TIMESTAMP');delta=(h*60+min)*(off[0]==='-'?-1:1);}
  const utc=new Date(local.getTime()-delta*60000);if(utc.getUTCFullYear()<1||utc.getUTCFullYear()>9999)fail('TIMESTAMP');
  return utc.toISOString().slice(0,19)+'.'+(m[7]??'').padEnd(6,'0')+'Z';
}
export function credentialCommitment(key:Buffer,record:ExactValue):string {
  if(key.length!==32)fail('KEY');return createHmac('sha256',key).update('NI-AUTH-COMMIT-v1\n').update(canonical(record)).digest('hex');
}
export function verifySignature(publicKeyHex:string,signatureHex:string,purpose:'audit'|'quarantine',unsigned:ExactValue):boolean {
  try {
    if(!/^[0-9a-f]{64}$/.test(publicKeyHex)||!/^[0-9a-f]{128}$/.test(signatureHex))return false;
    const key=createPublicKey({key:Buffer.concat([Buffer.from('302a300506032b6570032100','hex'),Buffer.from(publicKeyHex,'hex')]),format:'der',type:'spki'});
    return verify(null,Buffer.from((purpose==='audit'?'NI-AUDIT-RECEIPT-v1\n':'NI-QUARANTINE-RECEIPT-v1\n')+canonical(unsigned)),key,Buffer.from(signatureHex,'hex'));
  }catch{return false;}
}
