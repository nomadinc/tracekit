# NI-AUTH-001/Model-B/v1 — Technical Specification

Assembly revision: `review-assembly-2`  
Status: PARTIAL — four security specification corrections supplied; independent ratification pending  
Source baseline: `57eaec27b4b5022ec5ba5e81c0cdcb3182c150f3`  
Prior assembly SHA-256: `653a6638dd0edd36d87acdf8a5ca8b080af3b7bb94acfe58b371c98c1d9aa7f7`  
Date: 2026-10-17 UTC / 2026-10-16 America/Los_Angeles  
Owner: WS-001; reviewers: WS-004, WS-022, WS-024; consumer: Master / WS-025 M1.

This revision preserves the complete prior assembly byte-for-byte in the final source-history section. S4 and its normative vector appendix precede it and control conflicting integrity and Edge-clarification clauses. Historical open-item/status wording in the archived assembly is source history, not a competing current specification. Previously accepted architecture is retained. No runtime controls, prototypes, database tests or independent certifications are claimed.

Vector inventory: 32 positive record/encoding vectors, 5 cryptographic vectors, 59 negative expected-outcome cases and 6 comparison vectors. Negative expected outcomes are specifications, not executed runtime test results. Exact vector bytes and outputs are embedded in this same artifact to avoid divergent reviewer packages.

# S4 — Final integrity specification closure

Revision: `review-assembly-2`; contract: `NI-AUTH-001/Model-B/v1`; digest profile: `NI-IMM-DIGEST-v1/typed-tree-1`.

Status: proposed exact specification for independent ratification, not implementation authorization. S1/S2/S3 are preserved below as source history. S4 controls conflicting clauses. No prototype or runtime validation has occurred. Synthetic vector calculation is documentary work only.

## S4.1 Clause-level changes and precedence

| Earlier clause | Replacement |
|---|---|
| S1.6 / S3 canonicalization, incomplete typed tags | S4.2 exact universal typed-tree grammar and numeric/timestamp rules |
| S3 descriptive manifests and unclassified operational columns | S4.3 exhaustive proposed integrity manifests; physical-schema acceptance must prove exact coverage |
| S1.9 duplicate ambiguity | S4.4 separate source-evidence comparison from authentication/delivery provenance |
| S3 unspecified keyed commitment and receipt construction | S4.5 HMAC-SHA-256 and pure Ed25519, exact bytes and trust rules |
| S3 three basic vectors treated as sufficient | S4.6 full normative input/byte/output vector appendix; original vectors remain legacy framing examples only |
| S3 general terminal-4xx row | 408/429 take precedence and remain bounded-retry eligible |
| S3 parked-delivery recovery ambiguity | Durable, unacknowledged parking; no automatic observation redelivery, budget reset or tenant/epoch/payload replacement; recovery only through verified quarantine receipt or separately approved replay |

S2's authorized 200 stale policy, thresholds, locks, timeouts and governance remain unchanged. S4 does not certify previously accepted designs as implemented. The wire authorization contract version stays Model-B/v1; this is its first completely specified proposed digest profile, not permission to rehash existing records.

## S4.2 Exact canonical encoding

### Grammar

For every record, first validate its manifest and normalize each column by its declared type. Then encode the entire record, including nested JSON, as the following universal typed tree T:

```text
T(null)    = ["z"]
T(boolean)= ["b",true] or ["b",false]
T(string) = ["s",J(string)]
T(number) = ["n",J(normalized_decimal)]
T(array)  = ["a",[T(value0),T(value1),...]]
T(object) = ["o",[[J(key0),T(value0)],[J(key1),T(value1)],...]]
```

J denotes the JSON string serialization below, not additional literal text. Object member pairs are sorted by the UTF-8 bytes of the original key; duplicate decoded keys are invalid. Array order is preserved. Empty object is `["o",[]]`; empty array is `["a",[]]`. Every node has exactly the indicated arity. Unknown tags, added elements and malformed nodes are rejected. The alternative S3 `$number` object illustration is superseded; user objects cannot collide with type tags because every user object is itself wrapped as an object node.

The serialized tree uses literal ASCII brackets/commas, no spaces, no BOM and no trailing newline. All strings use double quotes. Escape U+0022 as `\"`, U+005C as `\\`, and U+0000–U+001F as six ASCII bytes `\u00xx` with lowercase hex. Do not use short control escapes. Other Unicode scalar values, including slash and U+2028/U+2029, are emitted as shortest-form UTF-8. Reject invalid UTF-8, unpaired surrogates and BOM-prefixed inputs. Preserve composed/decomposed Unicode distinctly; do not normalize. PostgreSQL-backed JSON/text cannot store U+0000, so manifest payload/text containing it is rejected before persistence even though the encoding grammar defines its representation.

JSON input must be parsed with exact decimals and duplicate-key detection before JSONB conversion. Keys `"a"` and `"\u0061"` are duplicates. A JavaScript Number parse followed by reserialization is not acceptable for large/precise numbers.

### Numeric normalization

Accepted JSON decimal tokens follow `-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?`. Convert exactly to coefficient and decimal exponent. Expand exponent notation, strip unnecessary integer leading zeros and fractional trailing zeros, omit a decimal point with empty fraction, and map every signed zero to `0`. Do not round. Examples: `1.2300e2 -> 123`, `1e-7 -> 0.0000001`, `-0.00 -> 0`.

Number input token length is at most 4096 ASCII bytes; absolute exponent at most 4096; normalized number at most 4096 ASCII bytes including sign and decimal point. Reject values exceeding any bound. These are encoding limits, not permission to accept observations exceeding existing contract size limits. Integers have no decimal point after normalization and must fit their manifest range. All numeric values use the number tag; numeric strings use the string tag and remain distinct.

### Column type normalization

| Type | Rule |
|---|---|
| U | Lowercase canonical UUID `8-4-4-4-12`; nil permitted only where a domain rule allows; vector UUIDs are synthetic |
| S | Unicode scalar string with the escaping rules above; existing identifier/domain restrictions still apply |
| E | S, environment regex `^[a-z][a-z0-9_-]{0,31}$` |
| T | S, tenant regex `^tenant_[A-Za-z0-9_-]{8,128}$` |
| H | S, exactly 64 lowercase hex characters representing SHA-256/HMAC output |
| K | S, key ID regex `^[a-z][a-z0-9_-]{0,62}$`; immutable key-to-purpose/version/bytes mapping |
| I | Exact integer 0 through 2147483647; revision/sequence-specific constraints below |
| Q | Exact integer 0 through 9223372036854775807 |
| V | Exact integer 1 through 2147483647 |
| TS | UTC timestamp string normalized as below |
| J | Arbitrary contract-permitted JSON recursively encoded by T, without interpretation of timestamp-like strings |
| B | Boolean |
| SIG | Exactly 128 lowercase hex characters, raw 64-byte Ed25519 signature |

TS accepts Gregorian dates from year 0001 through 9999, valid time 00:00:00–23:59:59, and `Z` or an explicit offset `+/-HH:MM` (maximum 14:00). Fraction has zero through six digits. Pad to six, convert to UTC, reject UTC overflow, invalid dates, leap seconds, absent timezone and more than six fractional digits. Emit `YYYY-MM-DDTHH:mm:ss.ffffffZ`. This rule applies to manifest TS columns only, never to arbitrary payload strings.

All manifest columns are mandatory in the digest input. `?` permits explicit null only; absence is invalid. A nullable before-state in an audit event is null for creation, not an omitted key. Inside J payloads, absent keys and explicit null differ. Unknown record columns are rejected until classified in a new manifest version.

### Framing and version compatibility

For record type R and normalized full record x:

`C(x) = UTF8(serialize(T(x)))`

`D(R,x) = SHA256(ASCII("NI-IMM-DIGEST-v1\n") || ASCII(R) || LF || C(x))`

Record type is exactly a manifest identifier below. Hex outputs are lowercase. `digest_version` is exactly `NI-IMM-DIGEST-v1/typed-tree-1`. A field, type, normalization, algorithm or framing change requires a new profile/version and fresh ratification, fixtures and migration checkpoints. Never reinterpret old version bytes. Unknown versions fail closed. The three original plain-JSON vectors do not use this new typed-tree profile and are not its conformance vectors.

## S4.3 Frozen manifest inventory

These define proposed integrity records, not deployed DDL. Each row below is an exact column manifest. No implicit columns, default omission or generic `to_jsonb(*)` may silently change it. A physical migration may use protected sidecars for added provenance, but must demonstrate one-to-one coverage and atomicity; it cannot invent a parallel payload store. Tuple order below is descriptive; canonical key order is always UTF-8 sorting.

```text
observation:
 id:U organization_id:U tenant_ref:T observation_id:S revision:V previous_revision:V?
 schema_version:S semantics_version:S derivation_rule_version:S session_ref:S event_ref:S?
 observed_at:TS updated_at_source:TS completed_at_source:TS? status:S payload:J payload_hash:H received_at:TS
 environment:E binding_epoch:U credential_id:U grant_id:U delivery_id:U digest_version:S

current_projection:
 organization_id:U tenant_ref:T observation_id:S observation_row_id:U revision:V updated_at:TS
 audit_event_id:U digest_version:S

journey_link:
 id:U organization_id:U observation_row_id:U journey_id:U? linkage_basis:S linkage_evidence:J created_at:TS
 updated_at:TS audit_event_id:U digest_version:S

credential_authorization:
 id:U status:S label:S created_at:TS last_used_at:TS? revoked_at:TS?
 verifier_algorithm:S verifier_commitment:H commitment_key_id:K commitment_key_version:V
 digest_version:S

tenant_binding:
 tenant_ref:T organization_id:U status:S created_at:TS updated_at:TS environment:E binding_epoch:U
 approval_ref:S approved_by:S digest_version:S

credential_grant:
 id:U credential_id:U environment:E tenant_ref:T organization_id:U binding_epoch:U status:S
 valid_from:TS expires_at:TS? approval_ref:S approved_by:S created_at:TS revoked_at:TS?
 revoked_by:S? revocation_reason:S? digest_version:S

authorization_audit:
 id:U stream_id:U sequence:Q previous_digest:H event_type:S record_type:S record_key:J
 before_state:J? after_state:J? before_digest:H? after_digest:H? actor_ref:S approval_ref:S
 reason:S occurred_at:TS correlation_id:U digest_version:S

observation_audit:
 id:U stream_id:U sequence:Q previous_digest:H event_type:S record_type:S record_key:J
 before_digest:H? after_digest:H? authorization_context:J before_projection:J? after_projection:J?
 before_link:J? after_link:J? outcome:S occurred_at:TS correlation_id:U digest_version:S

protected_outbox:
 event_id:U destination_id:S stream_id:U sequence:Q event_digest:H created_at:TS digest_version:S

independent_receipt:
 receipt_version:S receipt_id:U receipt_kind:S contract_version:S environment:E destination_id:S
 stream_id:U sequence:Q event_digest:H previous_receipt_digest:H durable_at:TS key_id:K key_version:V
 signature:SIG
```

observation.previous_revision is null for revision 1 and revision-1 otherwise; this does not claim predecessors have arrived. Current pointer must reference the exact same organization/tenant/observation/revision. Journey links must prove authoritative journey organization through the existing workspace relationship; absence of proof denies resolution. Unresolved links use null journey_id. linkage_basis retains the existing allowed values. No customer matching heuristic becomes authority.

Credential status is active/revoked; binding active/disabled; grant active/revoked. Grant validity and approved nullable-expiry policy remain from S1. Every last_used_at mutation is covered by an atomic audit if this column remains in the physical table; best-effort unaudited updates are prohibited. Physical `token_hash` is deliberately not exported: its exact bytes are bound by the commitment in S4.5. It remains subject to direct-write denial and independently governed controller changes.

Audit sequence starts at 1. Genesis previous_digest is 64 zero characters. event_type for authorization is credential_created/credential_revoked/credential_usage/grant_created/grant_revoked/binding_created/binding_disabled. record_type selects exactly credential_authorization, tenant_binding or credential_grant. record_key is the manifest's complete primary identity object. before/after state must be complete normalized matching manifests; before_digest/after_digest must equal their D values, or null with absent state. Controller action actor/approval/reason are nonempty authoritative strings.

Observation audit event_type is observation_retained/projection_changed/link_changed. record_type is observation/current_projection/journey_link accordingly; record_key is its complete primary identity. authorization_context has exactly credential_id:U, grant_id:U, environment:E, tenant_ref:T, organization_id:U, binding_epoch:U, delivery_id:U. Projection/link snapshots are complete corresponding records or explicit null. Outcomes are accepted/stale/duplicate/linked/unresolved as applicable. Digest outputs are stored outside their own input bodies; audit IDs may be preallocated, so references do not create hash circularity. A mutation affecting multiple records emits separate events and covers every affected record.

Receipt_kind is event/checkpoint. receipt_version is exactly NI-AUDIT-RECEIPT-v1 and contract_version is exactly NI-AUTH-001/Model-B/v1. sequence is >=1 for event; checkpoints allow 0 for an empty stream. Checkpoint event_digest is the latest anchored event digest, or all zeros for empty stream; durable_at is destination acknowledgement time. The independent destination must verify/store the source event chain before signing a checkpoint. Independent receipt digest covers the complete signed receipt including signature. Signature bytes are excluded only from the signing input, not from the receipt's chain digest. A checkpoint is signed even when the stream is idle; receipt_id makes each new heartbeat distinct. Duplicate event submission returns its original receipt, never a fabricated later storage time.

Auxiliary integrity records use their own complete schemas: credential_commitment (S4.5), source_evidence (S4.4), quarantine_receipt (S4.5), audit_stream_state and export_state. audit_stream_state has stream_id:U, last_sequence:Q, last_event_digest:H, updated_at:TS, digest_version:S. export_state has destination_id:S, stream_id:U, acknowledged_sequence:Q, acknowledged_event_digest:H, last_receipt_digest:H, last_checkpoint_at:TS?, attempt_count:Q, next_attempt_at:TS?, last_error_code:S?, updated_at:TS, digest_version:S. These mutable states never substitute for independently verified events/receipts; counters/checkpoints are reconciled against authoritative records. Their mutations occur only through governed functions; unauthorized acknowledgements are rejected. This inventory does not authorize new tables or migrations.

## S4.4 Source identity and duplicate/conflict comparison

source_evidence manifest is exactly:

```text
environment:E organization_id:U tenant_ref:T binding_epoch:U observation_id:S revision:V
previous_revision:V? schema_version:S semantics_version:S derivation_rule_version:S
session_ref:S event_ref:S? observed_at:TS updated_at_source:TS completed_at_source:TS?
status:S payload:J digest_version:S
```

Scope lookup uses environment, organization_id, tenant_ref, binding_epoch, observation_id, revision. Existing identity uniqueness must not permit epoch reuse to overwrite old rows. D(source_evidence,x) determines source equality, confirmed by canonical byte equality, not hash alone.

Excluded from source comparison: generated row IDs, received_at, credential_id, grant_id, delivery_id, transport attempts/responses/receipts, original payload_hash serialization and audit/export state. Those remain covered by their full record digests and audit; they are not editable source fields. Legacy payload_hash is preserved but cannot decide new-profile equality by itself.

Same scoped revision and same canonical source bytes => duplicate after fresh authorization. Different source bytes => 409, no replacement. Same delivery_id with changed original envelope or source bytes => 409 even if a different observation key is supplied. A delivery retry may use an independently approved replacement credential, but cannot change source context. Retained observation provenance remains first acceptance; a different authenticated delivery receives a separately audited receipt/provenance event rather than rewriting it. Such an event uses observation_audit with event_type delivery_replay, outcome duplicate, unchanged before/after record digests and snapshots, and the new authorization_context. This extends the enumerations above explicitly. It creates no new source observation.

A new lower revision under valid current authorization is retained with outcome stale; current projection unchanged. Source differences in new revisions do not create same-revision conflicts. Canonically equal numbers 1 and 1.0 compare equal; string "1" and number 1 do not. JSON object member order is immaterial; array order and Unicode composition are material. Fields resembling timestamps inside payload remain literal strings.

## S4.5 Cryptography and independent trust

Use established primitives only: SHA-256, HMAC-SHA-256 (RFC 2104) and pure Ed25519 (RFC 8032, not Ed25519ph/ctx). Domain framing is protocol byte encoding, not a new cryptographic primitive. Use maintained implementations; do not implement elliptic-curve arithmetic. This specification still requires WS-022 protocol review.

### Credential verifier commitment

credential_commitment has exactly credential_id:U, verifier_algorithm:S, verifier_hex:H, key_id:K, key_version:V, digest_version:S. verifier_algorithm is exactly sha256-bearer-v1; verifier_hex is SHA256 of the exact bearer UTF-8 bytes, without prefix, whitespace normalization or newline. Non-ASCII bearer tokens are denied. Neither this verifier nor its commitment is accepted as authentication proof.

Commitment input is ASCII("NI-AUTH-COMMIT-v1\n") || C(credential_commitment). Commitment output is lowercase hex HMAC-SHA-256(K, input), full 32 bytes without truncation. K is a separate 32-byte randomly generated MAC key. verifier_hex is restricted input, never exported; only MAC, key identity/version and algorithm enter credential_authorization records/audit. Masking, encryption or MAC does not make this metadata automatically anonymous.

The independently administered authorization controller/commitment service holds the MAC key. Ingestion, exporters, browser roles and ordinary service-role database sessions cannot retrieve it or invoke an unrestricted MAC oracle. Commitment generation is restricted to approved controller actions and audited; ordinary ingestion only verifies bearer possession against protected verification material and reads approved state. Commitment-service unavailability blocks authorization changes, not an otherwise safe authorized ingestion path. Commitment and protected verifier changes commit atomically through the controller; audit/export failure rolls back the change. A MAC alone does not authorize a state change.

Rotation uses a new immutable key ID/version, explicit controller approval and an audited recommitment event; old audit bodies and commitments remain unchanged. The authorization_audit event_type enumeration additionally includes credential_recommitted, with full before/after states and digests. Verification-only old keys remain under approved retention controls. Revoked/compromised MAC keys cannot create new trusted commitments. Unanchored changes relying on them are quarantined for independent reconciliation. The database-owner threat and unanchored outage interval are not eliminated.

### Independent event/checkpoint receipts

Unsigned receipt is independent_receipt minus signature. Signing bytes are ASCII("NI-AUDIT-RECEIPT-v1\n") || C(unsigned_receipt). Signature is pure Ed25519 over those bytes; no application prehash. Public key is 32 raw bytes; signature is 64 raw bytes represented by lowercase hex. Receipt chain digest is D(independent_receipt, complete_signed_receipt). Previous_receipt_digest is that digest for the preceding receipt in the destination/stream chain, or all zeros for genesis. Retry returns the same durable receipt; conflicting reuse of receipt_id is rejected.

Independent destination owns a non-exportable signing key or equivalent independently administered signing service. Ingestion and exporter have no signing, key-admin, delete/rewrite or arbitrary-sign authority. Destination signs only after durable append and stream/digest validation. It validates request event bytes and digest, not merely exporter assertions. Receipt is evidence of independent storage of submitted audit content, not proof that a compromised database's pre-checkpoint claims were true.

Verification uses a security-administered pinned trust registry keyed by environment, destination_id, purpose, key_id and key_version. Registry records algorithm, raw public key, active-from, active-until, status and revocation-effective-at. Provision trust out of band; never trust a receipt-supplied public key or algorithm. Unknown keys/purpose/environment/version and malformed/noncanonical signatures fail closed. Verify destination, exact local pending event/sequence/digest and previous receipt chain before acknowledgement. Event receipt cannot stand in for checkpoint heartbeat or vice versa. durable_at must be within key validity and not more than 60 seconds in the future relative to verifier database time. Age alone never authorizes discarding an otherwise valid old pending receipt; normal backlog gates still apply.

Rotation installs the new public key through independent approval before signing switches; old keys become verification-only for already durable records. Revocation removes new acknowledgement authority regardless of self-asserted durable_at. Previously checkpointed receipts remain historical evidence but are marked affected if compromise invalidates their trust. New acknowledgement using a revoked key is denied unless a new trusted independent key re-attests the matching durable stored chain under a governed recovery action. Do not trust an attacker-controlled timestamp to backdate around revocation.

Compromise: stop new admission/acknowledgement for affected streams; preserve queue/outbox/history; revoke affected trust; investigate from last independently trusted checkpoint; reconcile destination and source records; install independently approved replacement trust; re-attest retained durable data; resume only through governed clearance. Never rewrite old events, reset sequences/budgets or restore broad privileges. Missing key material, failed verification, signing outage or unexpected error returns sanitized codes and correlation IDs; no secret, MAC input, verifier, SQL parameters or private key appears in telemetry.

### Quarantine receipts

quarantine_receipt has exactly receipt_version:S, receipt_id:U, destination_id:S, environment:E, entry_id:U, delivery_id:U, envelope_digest:H, payload_digest:H, durable_at:TS, key_id:K, key_version:V, signature:SIG. Version is NI-QUARANTINE-RECEIPT-v1. Signing input is ASCII("NI-QUARANTINE-RECEIPT-v1\n") || C(receipt without signature), using pure Ed25519 with a separately purposed destination key. Digest is D(quarantine_receipt, signed receipt). Exact immutable envelope and redacted payload are separately digested using record types delivery_envelope and quarantine_payload; their exact fields are the five S3 headers and the complete permitted JSON payload respectively. No bearer/header containing a secret is included. Trust/rotation/revocation rules mirror audit receipts, with quarantine-specific purpose and durable-entry match. Quarantine does not authorize observation persistence.

## S4.6 Normative vectors and independent reproduction

The generated appendix contains exact normalized input, typed canonical UTF-8 bytes as hex, complete framed input hex and SHA-256 output for every manifest and auxiliary record; full HMAC inputs/output; deterministic synthetic Ed25519 keys, signing bytes and signatures; and negative expected outcomes. Hex is normative where display text escaping differs. All private keys and bearer strings in fixtures are PUBLIC SYNTHETIC TEST MATERIAL, never operational credentials.

The appendix was calculated by WS-001 with Python exact decimals, hashlib/hmac and the installed cryptography library. Mathematical/signature consistency checks are documentary checks, not WS-024 independent validation, production proofs or runtime prototype results. Independent implementations must reproduce outputs, including negative cases, before acceptance. The three S3 legacy vectors remain insufficient by themselves.

## S4.7 Edge clarifications and compatibility

408 and 429 override the general terminal-4xx rule and receive the existing bounded retry schedule. Parking is durable and unacknowledged; no automatic observation redelivery, budget reset, tenant/epoch replacement or payload rewrite. Transfer acknowledgement requires verified durable quarantine receipt. Separately governed replay creates a linked new attempt under fresh authorization, preserves the original evidence/budget and is not an automatic retry reset.

S3 five headers, eight attempts/delays/jitter, identity-matched accepted/duplicate/stale responses and 409 reconciliation are unchanged. Revised integrity encoding is internal; it does not add fields to Intelligence Contract v1 JSON. Edge must preserve exact decimal input when constructing/replaying JSON; independent conformance must catch lossy parsing. Existing canary remains untouched. Changed Core duplicate semantics and receipt/profile expectations need focused WS-004 review; prior acceptance is not automatically extended to these bytes.

## S4.8 WS-024 validation mapping and release gates

| Requirement | Documentary vectors / future disposable tests |
|---|---|
| Typed encoding | Every T tag, nested arrays/objects, duplicate decoded keys, UTF-8 order/escaping/composition, numeric exactness, null/absence, timestamp limits |
| Manifests | One positive fixture per manifest; omit/add/change every column; enforce type/range/nullability/domain and physical-column classification |
| Equality | Same source with changed auth/receipt returns duplicate without row rewrite; source mutation conflicts; delivery identity reuse conflicts; lower revision preserves pointer |
| Crypto | HMAC and Ed25519 known-input reproduction; wrong key/purpose/env/version, tampered bytes/signature, revoked/unknown trust, forged acknowledgement and receipt-chain gaps |
| Database enforcement | Historical privileged INSERT bypass/UPDATE/DELETE/TRUNCATE denied; composite tenant pointer/link checks; direct RPC and SET ROLE bypass denied |
| Authorization races | Ingestion/revocation/expiration/grant/binding/controller concurrency; lock ordering and bounded waits; cross-org/epoch/foreign denial |
| Atomic audit | Evidence/controller/projection/link audit failures roll back; immutable body and mutable export-state separation; sequence rollback and duplicate replay |
| Operations | Outage thresholds (age/count/checkpoint), simultaneous admission, governed recovery, parking durability/no budget reset, receipt acknowledgement checks |
| Secrecy and governance | All telemetry failure paths, commitment-key boundary, retention/holds/cascades/backups, safe rollback and canary compatibility |

Master must still name destinations, administrators and accountable retention/privacy/deletion/backup authorities. Runtime logging controls, platform key-service support, trust registry administration, quarantine bounds/storage retry policy and approved rotation/incident procedures require operational readiness evidence. No retention duration is implied. No deletion activation is permitted.

Final WS-022 exact-contract ratification and WS-004 concurrence remain pending. WS-024 can plan tests now; execution requires separate authorization. WS-025 M1 joint gate remains PARTIAL. No prototype, runtime implementation, production mutations, schema/grants, rotations, canary changes, customer activation, M2, commit/push, merge or deployment is authorized.

## S4.9 Primary cryptographic references

- HMAC construction: https://www.rfc-editor.org/rfc/rfc2104
- HMAC-SHA-256 primitive vectors: https://www.rfc-editor.org/rfc/rfc4231
- Pure Ed25519 and primitive vectors: https://www.rfc-editor.org/rfc/rfc8032

These references establish primitives, not independent approval of this application protocol.


## S4 normative vector appendix

Exact bytes are supplied as hex. Readable input numeric-token wrappers are fixture notation only; canonical_hex is authoritative. These are encoding fixtures, not valid provider observations.

### Record and encoding vectors

#### record-observation

```json
{
  "id": "record-observation",
  "record_type": "observation",
  "input": {
    "id": "00000000-0000-4000-8000-000000000001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "revision": 2,
    "previous_revision": 1,
    "schema_version": "1.0",
    "semantics_version": "m23-v1",
    "derivation_rule_version": "hybrid-derived-v1",
    "session_ref": "session_test0001",
    "event_ref": null,
    "observed_at": "2026-10-17T00:00:00.000000Z",
    "updated_at_source": "2026-10-17T00:00:00.000000Z",
    "completed_at_source": null,
    "status": "PARTIAL",
    "payload": {
      "value": {
        "exact_json_number_token": "9007199254740993"
      },
      "nested": [
        null,
        true,
        {
          "x": "é"
        }
      ]
    },
    "payload_hash": "1111111111111111111111111111111111111111111111111111111111111111",
    "received_at": "2026-10-17T00:00:00.000000Z",
    "environment": "test",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "grant_id": "00000000-0000-4000-8000-000000000005",
    "delivery_id": "00000000-0000-4000-8000-000000000006",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"binding_epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"completed_at_source\",[\"z\"]],[\"credential_id\",[\"s\",\"00000000-0000-4000-8000-000000000004\"]],[\"delivery_id\",[\"s\",\"00000000-0000-4000-8000-000000000006\"]],[\"derivation_rule_version\",[\"s\",\"hybrid-derived-v1\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"environment\",[\"s\",\"test\"]],[\"event_ref\",[\"z\"]],[\"grant_id\",[\"s\",\"00000000-0000-4000-8000-000000000005\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000001\"]],[\"observation_id\",[\"s\",\"obs_test0001\"]],[\"observed_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"payload\",[\"o\",[[\"nested\",[\"a\",[[\"z\"],[\"b\",true],[\"o\",[[\"x\",[\"s\",\"é\"]]]]]]],[\"value\",[\"n\",\"9007199254740993\"]]]]],[\"payload_hash\",[\"s\",\"1111111111111111111111111111111111111111111111111111111111111111\"]],[\"previous_revision\",[\"n\",\"1\"]],[\"received_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"revision\",[\"n\",\"2\"]],[\"schema_version\",[\"s\",\"1.0\"]],[\"semantics_version\",[\"s\",\"m23-v1\"]],[\"session_ref\",[\"s\",\"session_test0001\"]],[\"status\",[\"s\",\"PARTIAL\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]],[\"updated_at_source\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22636f6d706c657465645f61745f736f75726365222c5b227a225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2264657269766174696f6e5f72756c655f76657273696f6e222c5b2273222c226879627269642d646572697665642d7631225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f726566222c5b227a225d5d2c5b226772616e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f627365727665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227061796c6f6164222c5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393933225d5d5d5d5d2c5b227061796c6f61645f68617368222c5b2273222c2231313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131225d5d2c5b2270726576696f75735f7265766973696f6e222c5b226e222c2231225d5d2c5b2272656365697665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b22736368656d615f76657273696f6e222c5b2273222c22312e30225d5d2c5b2273656d616e746963735f76657273696f6e222c5b2273222c226d32332d7631225d5d2c5b2273657373696f6e5f726566222c5b2273222c2273657373696f6e5f7465737430303031225d5d2c5b22737461747573222c5b2273222c225041525449414c225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f61745f736f75726365222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a6f62736572766174696f6e0a5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22636f6d706c657465645f61745f736f75726365222c5b227a225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2264657269766174696f6e5f72756c655f76657273696f6e222c5b2273222c226879627269642d646572697665642d7631225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f726566222c5b227a225d5d2c5b226772616e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f627365727665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227061796c6f6164222c5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393933225d5d5d5d5d2c5b227061796c6f61645f68617368222c5b2273222c2231313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131313131225d5d2c5b2270726576696f75735f7265766973696f6e222c5b226e222c2231225d5d2c5b2272656365697665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b22736368656d615f76657273696f6e222c5b2273222c22312e30225d5d2c5b2273656d616e746963735f76657273696f6e222c5b2273222c226d32332d7631225d5d2c5b2273657373696f6e5f726566222c5b2273222c2273657373696f6e5f7465737430303031225d5d2c5b22737461747573222c5b2273222c225041525449414c225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f61745f736f75726365222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "4b16caaa974468534ed718c171a76d0253266529b8b79a060c919018a7999fd1",
  "expected": "VALID_ENCODING"
}
```

#### record-current_projection

```json
{
  "id": "record-current_projection",
  "record_type": "current_projection",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "revision": 2,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000008",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"audit_event_id\",[\"s\",\"00000000-0000-4000-8000-000000000008\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"observation_id\",[\"s\",\"obs_test0001\"]],[\"observation_row_id\",[\"s\",\"00000000-0000-4000-8000-000000000001\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"revision\",[\"n\",\"2\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]],[\"updated_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2261756469745f6576656e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303038225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f62736572766174696f6e5f726f775f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a63757272656e745f70726f6a656374696f6e0a5b226f222c5b5b2261756469745f6576656e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303038225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f62736572766174696f6e5f726f775f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "b6c2d6c41dedcd03e70b93e3209b46e4b75f63ca850183d9a16061d33f58b4df",
  "expected": "VALID_ENCODING"
}
```

#### record-journey_link

```json
{
  "id": "record-journey_link",
  "record_type": "journey_link",
  "input": {
    "id": "00000000-0000-4000-8000-000000000009",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "journey_id": null,
    "linkage_basis": "unresolved",
    "linkage_evidence": {},
    "created_at": "2026-10-17T00:00:00.000000Z",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000010",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"audit_event_id\",[\"s\",\"00000000-0000-4000-8000-000000000010\"]],[\"created_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000009\"]],[\"journey_id\",[\"z\"]],[\"linkage_basis\",[\"s\",\"unresolved\"]],[\"linkage_evidence\",[\"o\",[]]],[\"observation_row_id\",[\"s\",\"00000000-0000-4000-8000-000000000001\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"updated_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2261756469745f6576656e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303130225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303039225d5d2c5b226a6f75726e65795f6964222c5b227a225d5d2c5b226c696e6b6167655f6261736973222c5b2273222c22756e7265736f6c766564225d5d2c5b226c696e6b6167655f65766964656e6365222c5b226f222c5b5d5d5d2c5b226f62736572766174696f6e5f726f775f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a6a6f75726e65795f6c696e6b0a5b226f222c5b5b2261756469745f6576656e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303130225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303039225d5d2c5b226a6f75726e65795f6964222c5b227a225d5d2c5b226c696e6b6167655f6261736973222c5b2273222c22756e7265736f6c766564225d5d2c5b226c696e6b6167655f65766964656e6365222c5b226f222c5b5d5d5d2c5b226f62736572766174696f6e5f726f775f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "2dec5f8b133ea7bc276239341c23f7dbf6bf61c33d747fc34fd2e0f532c1f77a",
  "expected": "VALID_ENCODING"
}
```

#### record-credential_authorization

```json
{
  "id": "record-credential_authorization",
  "record_type": "credential_authorization",
  "input": {
    "id": "00000000-0000-4000-8000-000000000004",
    "status": "active",
    "label": "synthetic",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "last_used_at": null,
    "revoked_at": null,
    "verifier_algorithm": "sha256-bearer-v1",
    "verifier_commitment": "535b8af7faca0b8c0729103011cb23cd38e1160ec73f13a79c6452e7e05bb7f3",
    "commitment_key_id": "test_commit_1",
    "commitment_key_version": 1,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"commitment_key_id\",[\"s\",\"test_commit_1\"]],[\"commitment_key_version\",[\"n\",\"1\"]],[\"created_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000004\"]],[\"label\",[\"s\",\"synthetic\"]],[\"last_used_at\",[\"z\"]],[\"revoked_at\",[\"z\"]],[\"status\",[\"s\",\"active\"]],[\"verifier_algorithm\",[\"s\",\"sha256-bearer-v1\"]],[\"verifier_commitment\",[\"s\",\"535b8af7faca0b8c0729103011cb23cd38e1160ec73f13a79c6452e7e05bb7f3\"]]]]",
  "canonical_hex": "5b226f222c5b5b22636f6d6d69746d656e745f6b65795f6964222c5b2273222c22746573745f636f6d6d69745f31225d5d2c5b22636f6d6d69746d656e745f6b65795f76657273696f6e222c5b226e222c2231225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226c6162656c222c5b2273222c2273796e746865746963225d5d2c5b226c6173745f757365645f6174222c5b227a225d5d2c5b227265766f6b65645f6174222c5b227a225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2276657269666965725f616c676f726974686d222c5b2273222c227368613235362d6265617265722d7631225d5d2c5b2276657269666965725f636f6d6d69746d656e74222c5b2273222c2235333562386166376661636130623863303732393130333031316362323363643338653131363065633733663133613739633634353265376530356262376633225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a63726564656e7469616c5f617574686f72697a6174696f6e0a5b226f222c5b5b22636f6d6d69746d656e745f6b65795f6964222c5b2273222c22746573745f636f6d6d69745f31225d5d2c5b22636f6d6d69746d656e745f6b65795f76657273696f6e222c5b226e222c2231225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226c6162656c222c5b2273222c2273796e746865746963225d5d2c5b226c6173745f757365645f6174222c5b227a225d5d2c5b227265766f6b65645f6174222c5b227a225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2276657269666965725f616c676f726974686d222c5b2273222c227368613235362d6265617265722d7631225d5d2c5b2276657269666965725f636f6d6d69746d656e74222c5b2273222c2235333562386166376661636130623863303732393130333031316362323363643338653131363065633733663133613739633634353265376530356262376633225d5d5d5d",
  "sha256": "39360040b40ffe45c9eea8b26fde23708e2c1f15e0e5490500ee862cec8ee6d3",
  "expected": "VALID_ENCODING"
}
```

#### record-tenant_binding

```json
{
  "id": "record-tenant_binding",
  "record_type": "tenant_binding",
  "input": {
    "tenant_ref": "tenant_test0001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "status": "active",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "environment": "test",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "approval_ref": "synthetic-approval",
    "approved_by": "test-controller",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"approval_ref\",[\"s\",\"synthetic-approval\"]],[\"approved_by\",[\"s\",\"test-controller\"]],[\"binding_epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"created_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"environment\",[\"s\",\"test\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"status\",[\"s\",\"active\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]],[\"updated_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b22617070726f7665645f6279222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a74656e616e745f62696e64696e670a5b226f222c5b5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b22617070726f7665645f6279222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "64d2ec108cfa502c4f89f4cf2e1fc1b1ad3d2911f5a2bb1d7ba61150e325e9ef",
  "expected": "VALID_ENCODING"
}
```

#### record-credential_grant

```json
{
  "id": "record-credential_grant",
  "record_type": "credential_grant",
  "input": {
    "id": "00000000-0000-4000-8000-000000000005",
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "environment": "test",
    "tenant_ref": "tenant_test0001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "status": "active",
    "valid_from": "2026-10-17T00:00:00.000000Z",
    "expires_at": null,
    "approval_ref": "synthetic-approval",
    "approved_by": "test-controller",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "revoked_at": null,
    "revoked_by": null,
    "revocation_reason": null,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"approval_ref\",[\"s\",\"synthetic-approval\"]],[\"approved_by\",[\"s\",\"test-controller\"]],[\"binding_epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"created_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"credential_id\",[\"s\",\"00000000-0000-4000-8000-000000000004\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"environment\",[\"s\",\"test\"]],[\"expires_at\",[\"z\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000005\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"revocation_reason\",[\"z\"]],[\"revoked_at\",[\"z\"]],[\"revoked_by\",[\"z\"]],[\"status\",[\"s\",\"active\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]],[\"valid_from\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b22617070726f7665645f6279222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b22657870697265735f6174222c5b227a225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227265766f636174696f6e5f726561736f6e222c5b227a225d5d2c5b227265766f6b65645f6174222c5b227a225d5d2c5b227265766f6b65645f6279222c5b227a225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b2276616c69645f66726f6d222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a63726564656e7469616c5f6772616e740a5b226f222c5b5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b22617070726f7665645f6279222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b22657870697265735f6174222c5b227a225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227265766f636174696f6e5f726561736f6e222c5b227a225d5d2c5b227265766f6b65645f6174222c5b227a225d5d2c5b227265766f6b65645f6279222c5b227a225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b2276616c69645f66726f6d222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "c1e25f6cab4435022cc150f5d4eb8475be4d1463791df0b9f8481ca4d3901756",
  "expected": "VALID_ENCODING"
}
```

#### record-authorization_audit

```json
{
  "id": "record-authorization_audit",
  "record_type": "authorization_audit",
  "input": {
    "id": "00000000-0000-4000-8000-000000000011",
    "stream_id": "00000000-0000-4000-8000-000000000012",
    "sequence": 1,
    "previous_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "event_type": "grant_created",
    "record_type": "credential_grant",
    "record_key": {
      "id": "00000000-0000-4000-8000-000000000005"
    },
    "before_state": null,
    "after_state": {
      "id": "00000000-0000-4000-8000-000000000005",
      "credential_id": "00000000-0000-4000-8000-000000000004",
      "environment": "test",
      "tenant_ref": "tenant_test0001",
      "organization_id": "00000000-0000-4000-8000-000000000002",
      "binding_epoch": "00000000-0000-4000-8000-000000000003",
      "status": "active",
      "valid_from": "2026-10-17T00:00:00.000000Z",
      "expires_at": null,
      "approval_ref": "synthetic-approval",
      "approved_by": "test-controller",
      "created_at": "2026-10-17T00:00:00.000000Z",
      "revoked_at": null,
      "revoked_by": null,
      "revocation_reason": null,
      "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
    },
    "before_digest": null,
    "after_digest": "c1e25f6cab4435022cc150f5d4eb8475be4d1463791df0b9f8481ca4d3901756",
    "actor_ref": "test-controller",
    "approval_ref": "synthetic-approval",
    "reason": "test-only",
    "occurred_at": "2026-10-17T00:00:00.000000Z",
    "correlation_id": "00000000-0000-4000-8000-000000000013",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"actor_ref\",[\"s\",\"test-controller\"]],[\"after_digest\",[\"s\",\"c1e25f6cab4435022cc150f5d4eb8475be4d1463791df0b9f8481ca4d3901756\"]],[\"after_state\",[\"o\",[[\"approval_ref\",[\"s\",\"synthetic-approval\"]],[\"approved_by\",[\"s\",\"test-controller\"]],[\"binding_epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"created_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"credential_id\",[\"s\",\"00000000-0000-4000-8000-000000000004\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"environment\",[\"s\",\"test\"]],[\"expires_at\",[\"z\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000005\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"revocation_reason\",[\"z\"]],[\"revoked_at\",[\"z\"]],[\"revoked_by\",[\"z\"]],[\"status\",[\"s\",\"active\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]],[\"valid_from\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]],[\"approval_ref\",[\"s\",\"synthetic-approval\"]],[\"before_digest\",[\"z\"]],[\"before_state\",[\"z\"]],[\"correlation_id\",[\"s\",\"00000000-0000-4000-8000-000000000013\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"event_type\",[\"s\",\"grant_created\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000011\"]],[\"occurred_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"previous_digest\",[\"s\",\"0000000000000000000000000000000000000000000000000000000000000000\"]],[\"reason\",[\"s\",\"test-only\"]],[\"record_key\",[\"o\",[[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000005\"]]]]],[\"record_type\",[\"s\",\"credential_grant\"]],[\"sequence\",[\"n\",\"1\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000012\"]]]]",
  "canonical_hex": "5b226f222c5b5b226163746f725f726566222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2261667465725f646967657374222c5b2273222c2263316532356636636162343433353032326363313530663564346562383437356265346431343633373931646630623966383438316361346433393031373536225d5d2c5b2261667465725f7374617465222c5b226f222c5b5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b22617070726f7665645f6279222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b22657870697265735f6174222c5b227a225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227265766f636174696f6e5f726561736f6e222c5b227a225d5d2c5b227265766f6b65645f6174222c5b227a225d5d2c5b227265766f6b65645f6279222c5b227a225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b2276616c69645f66726f6d222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d5d2c5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b226265666f72655f646967657374222c5b227a225d5d2c5b226265666f72655f7374617465222c5b227a225d5d2c5b22636f7272656c6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303133225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226576656e745f74797065222c5b2273222c226772616e745f63726561746564225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303131225d5d2c5b226f636375727265645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2270726576696f75735f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726561736f6e222c5b2273222c22746573742d6f6e6c79225d5d2c5b227265636f72645f6b6579222c5b226f222c5b5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d5d5d5d2c5b227265636f72645f74797065222c5b2273222c2263726564656e7469616c5f6772616e74225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303132225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a617574686f72697a6174696f6e5f61756469740a5b226f222c5b5b226163746f725f726566222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2261667465725f646967657374222c5b2273222c2263316532356636636162343433353032326363313530663564346562383437356265346431343633373931646630623966383438316361346433393031373536225d5d2c5b2261667465725f7374617465222c5b226f222c5b5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b22617070726f7665645f6279222c5b2273222c22746573742d636f6e74726f6c6c6572225d5d2c5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b22657870697265735f6174222c5b227a225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227265766f636174696f6e5f726561736f6e222c5b227a225d5d2c5b227265766f6b65645f6174222c5b227a225d5d2c5b227265766f6b65645f6279222c5b227a225d5d2c5b22737461747573222c5b2273222c22616374697665225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b2276616c69645f66726f6d222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d5d2c5b22617070726f76616c5f726566222c5b2273222c2273796e7468657469632d617070726f76616c225d5d2c5b226265666f72655f646967657374222c5b227a225d5d2c5b226265666f72655f7374617465222c5b227a225d5d2c5b22636f7272656c6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303133225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226576656e745f74797065222c5b2273222c226772616e745f63726561746564225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303131225d5d2c5b226f636375727265645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2270726576696f75735f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726561736f6e222c5b2273222c22746573742d6f6e6c79225d5d2c5b227265636f72645f6b6579222c5b226f222c5b5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d5d5d5d2c5b227265636f72645f74797065222c5b2273222c2263726564656e7469616c5f6772616e74225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303132225d5d5d5d",
  "sha256": "2bbc339109af9b000e9f5dc23775d4ad34731f6ad0b0b1ac9ac5969af7c452de",
  "expected": "VALID_ENCODING"
}
```

#### record-observation_audit

```json
{
  "id": "record-observation_audit",
  "record_type": "observation_audit",
  "input": {
    "id": "00000000-0000-4000-8000-000000000014",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "previous_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "event_type": "observation_retained",
    "record_type": "observation",
    "record_key": {
      "id": "00000000-0000-4000-8000-000000000001"
    },
    "before_digest": null,
    "after_digest": "4b16caaa974468534ed718c171a76d0253266529b8b79a060c919018a7999fd1",
    "authorization_context": {
      "credential_id": "00000000-0000-4000-8000-000000000004",
      "grant_id": "00000000-0000-4000-8000-000000000005",
      "environment": "test",
      "tenant_ref": "tenant_test0001",
      "organization_id": "00000000-0000-4000-8000-000000000002",
      "binding_epoch": "00000000-0000-4000-8000-000000000003",
      "delivery_id": "00000000-0000-4000-8000-000000000006"
    },
    "before_projection": null,
    "after_projection": null,
    "before_link": null,
    "after_link": null,
    "outcome": "accepted",
    "occurred_at": "2026-10-17T00:00:00.000000Z",
    "correlation_id": "00000000-0000-4000-8000-000000000016",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"after_digest\",[\"s\",\"4b16caaa974468534ed718c171a76d0253266529b8b79a060c919018a7999fd1\"]],[\"after_link\",[\"z\"]],[\"after_projection\",[\"z\"]],[\"authorization_context\",[\"o\",[[\"binding_epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"credential_id\",[\"s\",\"00000000-0000-4000-8000-000000000004\"]],[\"delivery_id\",[\"s\",\"00000000-0000-4000-8000-000000000006\"]],[\"environment\",[\"s\",\"test\"]],[\"grant_id\",[\"s\",\"00000000-0000-4000-8000-000000000005\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]]]]],[\"before_digest\",[\"z\"]],[\"before_link\",[\"z\"]],[\"before_projection\",[\"z\"]],[\"correlation_id\",[\"s\",\"00000000-0000-4000-8000-000000000016\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"event_type\",[\"s\",\"observation_retained\"]],[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000014\"]],[\"occurred_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"outcome\",[\"s\",\"accepted\"]],[\"previous_digest\",[\"s\",\"0000000000000000000000000000000000000000000000000000000000000000\"]],[\"record_key\",[\"o\",[[\"id\",[\"s\",\"00000000-0000-4000-8000-000000000001\"]]]]],[\"record_type\",[\"s\",\"observation\"]],[\"sequence\",[\"n\",\"1\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000015\"]]]]",
  "canonical_hex": "5b226f222c5b5b2261667465725f646967657374222c5b2273222c2234623136636161613937343436383533346564373138633137316137366430323533323636353239623862373961303630633931393031386137393939666431225d5d2c5b2261667465725f6c696e6b222c5b227a225d5d2c5b2261667465725f70726f6a656374696f6e222c5b227a225d5d2c5b22617574686f72697a6174696f6e5f636f6e74657874222c5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226772616e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d5d5d5d2c5b226265666f72655f646967657374222c5b227a225d5d2c5b226265666f72655f6c696e6b222c5b227a225d5d2c5b226265666f72655f70726f6a656374696f6e222c5b227a225d5d2c5b22636f7272656c6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303136225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226576656e745f74797065222c5b2273222c226f62736572766174696f6e5f72657461696e6564225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303134225d5d2c5b226f636375727265645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7574636f6d65222c5b2273222c226163636570746564225d5d2c5b2270726576696f75735f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b227265636f72645f6b6579222c5b226f222c5b5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d5d5d5d2c5b227265636f72645f74797065222c5b2273222c226f62736572766174696f6e225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a6f62736572766174696f6e5f61756469740a5b226f222c5b5b2261667465725f646967657374222c5b2273222c2234623136636161613937343436383533346564373138633137316137366430323533323636353239623862373961303630633931393031386137393939666431225d5d2c5b2261667465725f6c696e6b222c5b227a225d5d2c5b2261667465725f70726f6a656374696f6e222c5b227a225d5d2c5b22617574686f72697a6174696f6e5f636f6e74657874222c5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226772616e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303035225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d5d5d5d2c5b226265666f72655f646967657374222c5b227a225d5d2c5b226265666f72655f6c696e6b222c5b227a225d5d2c5b226265666f72655f70726f6a656374696f6e222c5b227a225d5d2c5b22636f7272656c6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303136225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226576656e745f74797065222c5b2273222c226f62736572766174696f6e5f72657461696e6564225d5d2c5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303134225d5d2c5b226f636375727265645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7574636f6d65222c5b2273222c226163636570746564225d5d2c5b2270726576696f75735f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b227265636f72645f6b6579222c5b226f222c5b5b226964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303031225d5d5d5d5d2c5b227265636f72645f74797065222c5b2273222c226f62736572766174696f6e225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "sha256": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
  "expected": "VALID_ENCODING"
}
```

#### record-protected_outbox

```json
{
  "id": "record-protected_outbox",
  "record_type": "protected_outbox",
  "input": {
    "event_id": "00000000-0000-4000-8000-000000000014",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"created_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"destination_id\",[\"s\",\"synthetic-audit\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"event_digest\",[\"s\",\"25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0\"]],[\"event_id\",[\"s\",\"00000000-0000-4000-8000-000000000014\"]],[\"sequence\",[\"n\",\"1\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000015\"]]]]",
  "canonical_hex": "5b226f222c5b5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226576656e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303134225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a70726f7465637465645f6f7574626f780a5b226f222c5b5b22637265617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226576656e745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303134225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "sha256": "3be73c09e2ce5717e19178043793f40a56425c9c2880b0729cd4be49e9e38cb0",
  "expected": "VALID_ENCODING"
}
```

#### record-independent_receipt

```json
{
  "id": "record-independent_receipt",
  "record_type": "independent_receipt",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105"
  },
  "canonical_utf8": "[\"o\",[[\"contract_version\",[\"s\",\"NI-AUTH-001/Model-B/v1\"]],[\"destination_id\",[\"s\",\"synthetic-audit\"]],[\"durable_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"environment\",[\"s\",\"test\"]],[\"event_digest\",[\"s\",\"25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0\"]],[\"key_id\",[\"s\",\"test_receipt_1\"]],[\"key_version\",[\"n\",\"1\"]],[\"previous_receipt_digest\",[\"s\",\"0000000000000000000000000000000000000000000000000000000000000000\"]],[\"receipt_id\",[\"s\",\"00000000-0000-4000-8000-000000000017\"]],[\"receipt_kind\",[\"s\",\"event\"]],[\"receipt_version\",[\"s\",\"NI-AUDIT-RECEIPT-v1\"]],[\"sequence\",[\"n\",\"1\"]],[\"signature\",[\"s\",\"f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000015\"]]]]",
  "canonical_hex": "5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b227369676e6174757265222c5b2273222c226630303562313239623563643339383438633163383738666436313864383565373030653862633030353065636439376164393330383763333633336662666664393265336231336436383662333331333661336431306333356165623565633131353337303533316436613334366362303565376638653633356538313035225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a696e646570656e64656e745f726563656970740a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b227369676e6174757265222c5b2273222c226630303562313239623563643339383438633163383738666436313864383565373030653862633030353065636439376164393330383763333633336662666664393265336231336436383662333331333661336431306333356165623565633131353337303533316436613334366362303565376638653633356538313035225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "sha256": "fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb",
  "expected": "VALID_ENCODING"
}
```

#### record-source_evidence

```json
{
  "id": "record-source_evidence",
  "record_type": "source_evidence",
  "input": {
    "environment": "test",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "observation_id": "obs_test0001",
    "revision": 2,
    "previous_revision": 1,
    "schema_version": "1.0",
    "semantics_version": "m23-v1",
    "derivation_rule_version": "hybrid-derived-v1",
    "session_ref": "session_test0001",
    "event_ref": null,
    "observed_at": "2026-10-17T00:00:00.000000Z",
    "updated_at_source": "2026-10-17T00:00:00.000000Z",
    "completed_at_source": null,
    "status": "PARTIAL",
    "payload": {
      "value": {
        "exact_json_number_token": "9007199254740993"
      },
      "nested": [
        null,
        true,
        {
          "x": "é"
        }
      ]
    },
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"binding_epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"completed_at_source\",[\"z\"]],[\"derivation_rule_version\",[\"s\",\"hybrid-derived-v1\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"environment\",[\"s\",\"test\"]],[\"event_ref\",[\"z\"]],[\"observation_id\",[\"s\",\"obs_test0001\"]],[\"observed_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"organization_id\",[\"s\",\"00000000-0000-4000-8000-000000000002\"]],[\"payload\",[\"o\",[[\"nested\",[\"a\",[[\"z\"],[\"b\",true],[\"o\",[[\"x\",[\"s\",\"é\"]]]]]]],[\"value\",[\"n\",\"9007199254740993\"]]]]],[\"previous_revision\",[\"n\",\"1\"]],[\"revision\",[\"n\",\"2\"]],[\"schema_version\",[\"s\",\"1.0\"]],[\"semantics_version\",[\"s\",\"m23-v1\"]],[\"session_ref\",[\"s\",\"session_test0001\"]],[\"status\",[\"s\",\"PARTIAL\"]],[\"tenant_ref\",[\"s\",\"tenant_test0001\"]],[\"updated_at_source\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22636f6d706c657465645f61745f736f75726365222c5b227a225d5d2c5b2264657269766174696f6e5f72756c655f76657273696f6e222c5b2273222c226879627269642d646572697665642d7631225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f726566222c5b227a225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f627365727665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227061796c6f6164222c5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393933225d5d5d5d5d2c5b2270726576696f75735f7265766973696f6e222c5b226e222c2231225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b22736368656d615f76657273696f6e222c5b2273222c22312e30225d5d2c5b2273656d616e746963735f76657273696f6e222c5b2273222c226d32332d7631225d5d2c5b2273657373696f6e5f726566222c5b2273222c2273657373696f6e5f7465737430303031225d5d2c5b22737461747573222c5b2273222c225041525449414c225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f61745f736f75726365222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a736f757263655f65766964656e63650a5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22636f6d706c657465645f61745f736f75726365222c5b227a225d5d2c5b2264657269766174696f6e5f72756c655f76657273696f6e222c5b2273222c226879627269642d646572697665642d7631225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f726566222c5b227a225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f627365727665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227061796c6f6164222c5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393933225d5d5d5d5d2c5b2270726576696f75735f7265766973696f6e222c5b226e222c2231225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b22736368656d615f76657273696f6e222c5b2273222c22312e30225d5d2c5b2273656d616e746963735f76657273696f6e222c5b2273222c226d32332d7631225d5d2c5b2273657373696f6e5f726566222c5b2273222c2273657373696f6e5f7465737430303031225d5d2c5b22737461747573222c5b2273222c225041525449414c225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f61745f736f75726365222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "5c227fbf6f8b81f94f7435796b287e97abbb972f927ca17a32c211af6d42e645",
  "expected": "VALID_ENCODING"
}
```

#### record-credential_commitment

```json
{
  "id": "record-credential_commitment",
  "record_type": "credential_commitment",
  "input": {
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "verifier_algorithm": "sha256-bearer-v1",
    "verifier_hex": "fa8341cc4e752388ffd25d6101181bfb6e64651c0741e71f5b565616f018152a",
    "key_id": "test_commit_1",
    "key_version": 1,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"credential_id\",[\"s\",\"00000000-0000-4000-8000-000000000004\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"key_id\",[\"s\",\"test_commit_1\"]],[\"key_version\",[\"n\",\"1\"]],[\"verifier_algorithm\",[\"s\",\"sha256-bearer-v1\"]],[\"verifier_hex\",[\"s\",\"fa8341cc4e752388ffd25d6101181bfb6e64651c0741e71f5b565616f018152a\"]]]]",
  "canonical_hex": "5b226f222c5b5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226b65795f6964222c5b2273222c22746573745f636f6d6d69745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2276657269666965725f616c676f726974686d222c5b2273222c227368613235362d6265617265722d7631225d5d2c5b2276657269666965725f686578222c5b2273222c2266613833343163633465373532333838666664323564363130313138316266623665363436353163303734316537316635623536353631366630313831353261225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a63726564656e7469616c5f636f6d6d69746d656e740a5b226f222c5b5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226b65795f6964222c5b2273222c22746573745f636f6d6d69745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2276657269666965725f616c676f726974686d222c5b2273222c227368613235362d6265617265722d7631225d5d2c5b2276657269666965725f686578222c5b2273222c2266613833343163633465373532333838666664323564363130313138316266623665363436353163303734316537316635623536353631366630313831353261225d5d5d5d",
  "sha256": "b2d1d15fc2901ce523c6e4ea96a496475eb36486ca6da1380fb6a87c6911cd73",
  "expected": "VALID_ENCODING"
}
```

#### record-delivery_envelope

```json
{
  "id": "record-delivery_envelope",
  "record_type": "delivery_envelope",
  "input": {
    "TraceKit-Authorization-Contract": "NI-AUTH-001/Model-B/v1",
    "TraceKit-Environment": "test",
    "TraceKit-Tenant-Ref": "tenant_test0001",
    "TraceKit-Binding-Epoch": "00000000-0000-4000-8000-000000000003",
    "TraceKit-Delivery-Id": "00000000-0000-4000-8000-000000000006"
  },
  "canonical_utf8": "[\"o\",[[\"TraceKit-Authorization-Contract\",[\"s\",\"NI-AUTH-001/Model-B/v1\"]],[\"TraceKit-Binding-Epoch\",[\"s\",\"00000000-0000-4000-8000-000000000003\"]],[\"TraceKit-Delivery-Id\",[\"s\",\"00000000-0000-4000-8000-000000000006\"]],[\"TraceKit-Environment\",[\"s\",\"test\"]],[\"TraceKit-Tenant-Ref\",[\"s\",\"tenant_test0001\"]]]]",
  "canonical_hex": "5b226f222c5b5b2254726163654b69742d417574686f72697a6174696f6e2d436f6e7472616374222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2254726163654b69742d42696e64696e672d45706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b2254726163654b69742d44656c69766572792d4964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2254726163654b69742d456e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b2254726163654b69742d54656e616e742d526566222c5b2273222c2274656e616e745f7465737430303031225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a64656c69766572795f656e76656c6f70650a5b226f222c5b5b2254726163654b69742d417574686f72697a6174696f6e2d436f6e7472616374222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2254726163654b69742d42696e64696e672d45706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b2254726163654b69742d44656c69766572792d4964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2254726163654b69742d456e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b2254726163654b69742d54656e616e742d526566222c5b2273222c2274656e616e745f7465737430303031225d5d5d5d",
  "sha256": "cae98ce6fba5387f8baafa265d96ad558409006e7df4f3551f00a7e765777cb1",
  "expected": "VALID_ENCODING"
}
```

#### record-quarantine_payload

```json
{
  "id": "record-quarantine_payload",
  "record_type": "quarantine_payload",
  "input": {
    "value": {
      "exact_json_number_token": "9007199254740993"
    },
    "nested": [
      null,
      true,
      {
        "x": "é"
      }
    ]
  },
  "canonical_utf8": "[\"o\",[[\"nested\",[\"a\",[[\"z\"],[\"b\",true],[\"o\",[[\"x\",[\"s\",\"é\"]]]]]]],[\"value\",[\"n\",\"9007199254740993\"]]]]",
  "canonical_hex": "5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393933225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a71756172616e74696e655f7061796c6f61640a5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393933225d5d5d5d",
  "sha256": "310d1b949c122a51245fcbc56adb603916eddb52c1123a754ac504af13e1057d",
  "expected": "VALID_ENCODING"
}
```

#### record-quarantine_receipt

```json
{
  "id": "record-quarantine_receipt",
  "record_type": "quarantine_receipt",
  "input": {
    "receipt_version": "NI-QUARANTINE-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000018",
    "destination_id": "synthetic-quarantine",
    "environment": "test",
    "entry_id": "00000000-0000-4000-8000-000000000019",
    "delivery_id": "00000000-0000-4000-8000-000000000006",
    "envelope_digest": "cae98ce6fba5387f8baafa265d96ad558409006e7df4f3551f00a7e765777cb1",
    "payload_digest": "310d1b949c122a51245fcbc56adb603916eddb52c1123a754ac504af13e1057d",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_quarantine_1",
    "key_version": 1,
    "signature": "44df9fa4fb0b1e41368517cd007af3ad75fdd7d3d51650171994a559b7f02793c1b27aed122d36340f7bf89d8a51427dc1caf6e26b7d27cde2cd673106fa1505"
  },
  "canonical_utf8": "[\"o\",[[\"delivery_id\",[\"s\",\"00000000-0000-4000-8000-000000000006\"]],[\"destination_id\",[\"s\",\"synthetic-quarantine\"]],[\"durable_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"entry_id\",[\"s\",\"00000000-0000-4000-8000-000000000019\"]],[\"envelope_digest\",[\"s\",\"cae98ce6fba5387f8baafa265d96ad558409006e7df4f3551f00a7e765777cb1\"]],[\"environment\",[\"s\",\"test\"]],[\"key_id\",[\"s\",\"test_quarantine_1\"]],[\"key_version\",[\"n\",\"1\"]],[\"payload_digest\",[\"s\",\"310d1b949c122a51245fcbc56adb603916eddb52c1123a754ac504af13e1057d\"]],[\"receipt_id\",[\"s\",\"00000000-0000-4000-8000-000000000018\"]],[\"receipt_version\",[\"s\",\"NI-QUARANTINE-RECEIPT-v1\"]],[\"signature\",[\"s\",\"44df9fa4fb0b1e41368517cd007af3ad75fdd7d3d51650171994a559b7f02793c1b27aed122d36340f7bf89d8a51427dc1caf6e26b7d27cde2cd673106fa1505\"]]]]",
  "canonical_hex": "5b226f222c5b5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d71756172616e74696e65225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7472795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303139225d5d2c5b22656e76656c6f70655f646967657374222c5b2273222c2263616539386365366662613533383766386261616661323635643936616435353834303930303665376466346633353531663030613765373635373737636231225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226b65795f6964222c5b2273222c22746573745f71756172616e74696e655f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b227061796c6f61645f646967657374222c5b2273222c2233313064316239343963313232613531323435666362633536616462363033393136656464623532633131323361373534616335303461663133653130353764225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303138225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d51554152414e54494e452d524543454950542d7631225d5d2c5b227369676e6174757265222c5b2273222c223434646639666134666230623165343133363835313763643030376166336164373566646437643364353136353031373139393461353539623766303237393363316232376165643132326433363334306637626638396438613531343237646331636166366532366237643237636465326364363733313036666131353035225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a71756172616e74696e655f726563656970740a5b226f222c5b5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d71756172616e74696e65225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7472795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303139225d5d2c5b22656e76656c6f70655f646967657374222c5b2273222c2263616539386365366662613533383766386261616661323635643936616435353834303930303665376466346633353531663030613765373635373737636231225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226b65795f6964222c5b2273222c22746573745f71756172616e74696e655f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b227061796c6f61645f646967657374222c5b2273222c2233313064316239343963313232613531323435666362633536616462363033393136656464623532633131323361373534616335303461663133653130353764225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303138225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d51554152414e54494e452d524543454950542d7631225d5d2c5b227369676e6174757265222c5b2273222c223434646639666134666230623165343133363835313763643030376166336164373566646437643364353136353031373139393461353539623766303237393363316232376165643132326433363334306637626638396438613531343237646331636166366532366237643237636465326364363733313036666131353035225d5d5d5d",
  "sha256": "a8cff6b86bd358a66d162cd6e4df74f1b65d3e044e16dddc71e1d807b0c943d9",
  "expected": "VALID_ENCODING"
}
```

#### record-audit_stream_state

```json
{
  "id": "record-audit_stream_state",
  "record_type": "audit_stream_state",
  "input": {
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "last_sequence": 1,
    "last_event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"last_event_digest\",[\"s\",\"25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0\"]],[\"last_sequence\",[\"n\",\"1\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000015\"]],[\"updated_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226c6173745f6576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226c6173745f73657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a61756469745f73747265616d5f73746174650a5b226f222c5b5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226c6173745f6576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226c6173745f73657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "28c74ef48c5b83c93bf82b29f108873cf922091cb03dfbdb2c4c75d1effc1599",
  "expected": "VALID_ENCODING"
}
```

#### record-export_state

```json
{
  "id": "record-export_state",
  "record_type": "export_state",
  "input": {
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "acknowledged_sequence": 1,
    "acknowledged_event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "last_receipt_digest": "fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb",
    "last_checkpoint_at": null,
    "attempt_count": 0,
    "next_attempt_at": null,
    "last_error_code": null,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  },
  "canonical_utf8": "[\"o\",[[\"acknowledged_event_digest\",[\"s\",\"25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0\"]],[\"acknowledged_sequence\",[\"n\",\"1\"]],[\"attempt_count\",[\"n\",\"0\"]],[\"destination_id\",[\"s\",\"synthetic-audit\"]],[\"digest_version\",[\"s\",\"NI-IMM-DIGEST-v1/typed-tree-1\"]],[\"last_checkpoint_at\",[\"z\"]],[\"last_error_code\",[\"z\"]],[\"last_receipt_digest\",[\"s\",\"fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb\"]],[\"next_attempt_at\",[\"z\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000015\"]],[\"updated_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2261636b6e6f776c65646765645f6576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b2261636b6e6f776c65646765645f73657175656e6365222c5b226e222c2231225d5d2c5b22617474656d70745f636f756e74222c5b226e222c2230225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226c6173745f636865636b706f696e745f6174222c5b227a225d5d2c5b226c6173745f6572726f725f636f6465222c5b227a225d5d2c5b226c6173745f726563656970745f646967657374222c5b2273222c2266643339386331323034353266613430396632316663326434336237346366643032623765316233313635613065643565383535616136656336336335646562225d5d2c5b226e6578745f617474656d70745f6174222c5b227a225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a6578706f72745f73746174650a5b226f222c5b5b2261636b6e6f776c65646765645f6576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b2261636b6e6f776c65646765645f73657175656e6365222c5b226e222c2231225d5d2c5b22617474656d70745f636f756e74222c5b226e222c2230225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226c6173745f636865636b706f696e745f6174222c5b227a225d5d2c5b226c6173745f6572726f725f636f6465222c5b227a225d5d2c5b226c6173745f726563656970745f646967657374222c5b2273222c2266643339386331323034353266613430396632316663326434336237346366643032623765316233313635613065643565383535616136656336336335646562225d5d2c5b226e6578745f617474656d70745f6174222c5b227a225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d2c5b22757064617465645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "0f39d8d8bae591e0d1faeeefacad1a8c377fbeadf1202acb7483abe19bac11bb",
  "expected": "VALID_ENCODING"
}
```

#### all-tags

```json
{
  "id": "all-tags",
  "record_type": "encoding_test",
  "input": {
    "o": {},
    "a": [],
    "s": "",
    "n": {
      "exact_json_number_token": "123.00"
    },
    "b": false,
    "z": null
  },
  "canonical_utf8": "[\"o\",[[\"a\",[\"a\",[]]],[\"b\",[\"b\",false]],[\"n\",[\"n\",\"123\"]],[\"o\",[\"o\",[]]],[\"s\",[\"s\",\"\"]],[\"z\",[\"z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2261222c5b2261222c5b5d5d5d2c5b2262222c5b2262222c66616c73655d5d2c5b226e222c5b226e222c22313233225d5d2c5b226f222c5b226f222c5b5d5d5d2c5b2273222c5b2273222c22225d5d2c5b227a222c5b227a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b226f222c5b5b2261222c5b2261222c5b5d5d5d2c5b2262222c5b2262222c66616c73655d5d2c5b226e222c5b226e222c22313233225d5d2c5b226f222c5b226f222c5b5d5d5d2c5b2273222c5b2273222c22225d5d2c5b227a222c5b227a225d5d5d5d",
  "sha256": "8a0f9003cc7ab9a876795ffb3002e85a245cf06b17d1be24f3c06018910dc9fb",
  "expected": "VALID_ENCODING"
}
```

#### nested

```json
{
  "id": "nested",
  "record_type": "encoding_test",
  "input": {
    "z": [
      {
        "b": [
          {
            "exact_json_number_token": "1E-7"
          },
          [
            "x",
            true,
            null
          ]
        ]
      }
    ],
    "a": {
      "x": []
    }
  },
  "canonical_utf8": "[\"o\",[[\"a\",[\"o\",[[\"x\",[\"a\",[]]]]]],[\"z\",[\"a\",[[\"o\",[[\"b\",[\"a\",[[\"n\",\"0.0000001\"],[\"a\",[[\"s\",\"x\"],[\"b\",true],[\"z\"]]]]]]]]]]]]]",
  "canonical_hex": "5b226f222c5b5b2261222c5b226f222c5b5b2278222c5b2261222c5b5d5d5d5d5d5d2c5b227a222c5b2261222c5b5b226f222c5b5b2262222c5b2261222c5b5b226e222c22302e30303030303031225d2c5b2261222c5b5b2273222c2278225d2c5b2262222c747275655d2c5b227a225d5d5d5d5d5d5d5d5d5d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b226f222c5b5b2261222c5b226f222c5b5b2278222c5b2261222c5b5d5d5d5d5d5d2c5b227a222c5b2261222c5b5b226f222c5b5b2262222c5b2261222c5b5b226e222c22302e30303030303031225d2c5b2261222c5b5b2273222c2278225d2c5b2262222c747275655d2c5b227a225d5d5d5d5d5d5d5d5d5d5d5d5d",
  "sha256": "aa1905c92b0dfbf723f74e4b02af5510f104a02b8dfb621cf3f3eaaa06a33d64",
  "expected": "VALID_ENCODING"
}
```

#### unicode-escape

```json
{
  "id": "unicode-escape",
  "record_type": "encoding_test",
  "input": {
    "𐀀": "é",
    "": "é",
    "control": "line\n\t\"\\\u001f/ "
  },
  "canonical_utf8": "[\"o\",[[\"control\",[\"s\",\"line\\u000a\\u0009\\\"\\\\\\u001f/ \"]],[\"\",[\"s\",\"é\"]],[\"𐀀\",[\"s\",\"é\"]]]]",
  "canonical_hex": "5b226f222c5b5b22636f6e74726f6c222c5b2273222c226c696e655c75303030615c75303030395c225c5c5c75303031662fe280a8225d5d2c5b22ee8080222c5b2273222c2265cc81225d5d2c5b22f0908080222c5b2273222c22c3a9225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b226f222c5b5b22636f6e74726f6c222c5b2273222c226c696e655c75303030615c75303030395c225c5c5c75303031662fe280a8225d5d2c5b22ee8080222c5b2273222c2265cc81225d5d2c5b22f0908080222c5b2273222c22c3a9225d5d5d5d",
  "sha256": "bc1f8adb70dfc79ab65938ff96d1350488cbb585f34f70ec16a3417d8ee0c841",
  "expected": "VALID_ENCODING"
}
```

#### numeric-boundaries

```json
{
  "id": "numeric-boundaries",
  "record_type": "encoding_test",
  "input": [
    {
      "exact_json_number_token": "9007199254740993"
    },
    {
      "exact_json_number_token": "9223372036854775807"
    },
    {
      "exact_json_number_token": "0.123456789012345678901234567890"
    },
    {
      "exact_json_number_token": "-0.00"
    },
    {
      "exact_json_number_token": "1E-100"
    },
    {
      "exact_json_number_token": "1E+100"
    }
  ],
  "canonical_utf8": "[\"a\",[[\"n\",\"9007199254740993\"],[\"n\",\"9223372036854775807\"],[\"n\",\"0.12345678901234567890123456789\"],[\"n\",\"0\"],[\"n\",\"0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001\"],[\"n\",\"10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\"]]]",
  "canonical_hex": "5b2261222c5b5b226e222c2239303037313939323534373430393933225d2c5b226e222c2239323233333732303336383534373735383037225d2c5b226e222c22302e3132333435363738393031323334353637383930313233343536373839225d2c5b226e222c2230225d2c5b226e222c22302e30303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303031225d2c5b226e222c223130303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b2261222c5b5b226e222c2239303037313939323534373430393933225d2c5b226e222c2239323233333732303336383534373735383037225d2c5b226e222c22302e3132333435363738393031323334353637383930313233343536373839225d2c5b226e222c2230225d2c5b226e222c22302e30303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303031225d2c5b226e222c223130303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d5d",
  "sha256": "fc2011abe6f85e4c630ec93045a2fd9e596a281622a7565a82d35757d37fbf14",
  "expected": "VALID_ENCODING"
}
```

#### null-present

```json
{
  "id": "null-present",
  "record_type": "encoding_test",
  "input": {
    "a": null
  },
  "canonical_utf8": "[\"o\",[[\"a\",[\"z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2261222c5b227a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b226f222c5b5b2261222c5b227a225d5d5d5d",
  "sha256": "fd063301a745f039a36482b065c67f3ddeac6c4abff5484bffae1c1525331f7a",
  "expected": "VALID_ENCODING"
}
```

#### null-absent

```json
{
  "id": "null-absent",
  "record_type": "encoding_test",
  "input": {},
  "canonical_utf8": "[\"o\",[]]",
  "canonical_hex": "5b226f222c5b5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b226f222c5b5d5d",
  "sha256": "0e3820d61a2e769f30387a38112c3c11743e176af40e756da7b722139278c5b0",
  "expected": "VALID_ENCODING"
}
```

#### number

```json
{
  "id": "number",
  "record_type": "encoding_test",
  "input": {
    "exact_json_number_token": "1.0"
  },
  "canonical_utf8": "[\"n\",\"1\"]",
  "canonical_hex": "5b226e222c2231225d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b226e222c2231225d",
  "sha256": "374b2206868453a3e9e882fbc5698691030eb31a5ad832995e1fd7c792eaecd2",
  "expected": "VALID_ENCODING"
}
```

#### string-number

```json
{
  "id": "string-number",
  "record_type": "encoding_test",
  "input": "1",
  "canonical_utf8": "[\"s\",\"1\"]",
  "canonical_hex": "5b2273222c2231225d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b2273222c2231225d",
  "sha256": "851b310d568a423be0c08708de0fcd373b6a42a90bbb3ac468c0aa5749f192a4",
  "expected": "VALID_ENCODING"
}
```

#### unicode-composed

```json
{
  "id": "unicode-composed",
  "record_type": "encoding_test",
  "input": "é",
  "canonical_utf8": "[\"s\",\"é\"]",
  "canonical_hex": "5b2273222c22c3a9225d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b2273222c22c3a9225d",
  "sha256": "95609f1666b6afc2398412720c3d94672bce195349ddf3b9cc6db189451eb019",
  "expected": "VALID_ENCODING"
}
```

#### unicode-decomposed

```json
{
  "id": "unicode-decomposed",
  "record_type": "encoding_test",
  "input": "é",
  "canonical_utf8": "[\"s\",\"é\"]",
  "canonical_hex": "5b2273222c2265cc81225d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a656e636f64696e675f746573740a5b2273222c2265cc81225d",
  "sha256": "c94b196e73486c35f61b8ad18233c36ce80889803b511f42ed73e60f647be123",
  "expected": "VALID_ENCODING"
}
```

#### timestamp-0001-01-01T00:00:00Z

```json
{
  "id": "timestamp-0001-01-01T00:00:00Z",
  "record_type": "timestamp_test",
  "input": "0001-01-01T00:00:00Z",
  "normalized": "0001-01-01T00:00:00.000000Z",
  "canonical_utf8": "[\"o\",[[\"timestamp\",[\"s\",\"0001-01-01T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2274696d657374616d70222c5b2273222c22303030312d30312d30315430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a74696d657374616d705f746573740a5b226f222c5b5b2274696d657374616d70222c5b2273222c22303030312d30312d30315430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "fc6bd52ca3d12bb696b7391eb698765facf14e757570d9919dfc321ed579f5b1",
  "expected": "VALID_ENCODING"
}
```

#### timestamp-9999-12-31T23:59:59.999999Z

```json
{
  "id": "timestamp-9999-12-31T23:59:59.999999Z",
  "record_type": "timestamp_test",
  "input": "9999-12-31T23:59:59.999999Z",
  "normalized": "9999-12-31T23:59:59.999999Z",
  "canonical_utf8": "[\"o\",[[\"timestamp\",[\"s\",\"9999-12-31T23:59:59.999999Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2274696d657374616d70222c5b2273222c22393939392d31322d33315432333a35393a35392e3939393939395a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a74696d657374616d705f746573740a5b226f222c5b5b2274696d657374616d70222c5b2273222c22393939392d31322d33315432333a35393a35392e3939393939395a225d5d5d5d",
  "sha256": "7facada24deeaddbeeeaa86dd337b73874a47d8b8d005a519ec54f749a439491",
  "expected": "VALID_ENCODING"
}
```

#### timestamp-2026-10-16T17:00:00-07:00

```json
{
  "id": "timestamp-2026-10-16T17:00:00-07:00",
  "record_type": "timestamp_test",
  "input": "2026-10-16T17:00:00-07:00",
  "normalized": "2026-10-17T00:00:00.000000Z",
  "canonical_utf8": "[\"o\",[[\"timestamp\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2274696d657374616d70222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a74696d657374616d705f746573740a5b226f222c5b5b2274696d657374616d70222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "sha256": "a55d1ab3260a3da16e1e502bb0bbc1d6fc799f5c1adf5a24b939783ca28ac6d9",
  "expected": "VALID_ENCODING"
}
```

#### timestamp-2026-10-17T00:00:00.1Z

```json
{
  "id": "timestamp-2026-10-17T00:00:00.1Z",
  "record_type": "timestamp_test",
  "input": "2026-10-17T00:00:00.1Z",
  "normalized": "2026-10-17T00:00:00.100000Z",
  "canonical_utf8": "[\"o\",[[\"timestamp\",[\"s\",\"2026-10-17T00:00:00.100000Z\"]]]]",
  "canonical_hex": "5b226f222c5b5b2274696d657374616d70222c5b2273222c22323032362d31302d31375430303a30303a30302e3130303030305a225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a74696d657374616d705f746573740a5b226f222c5b5b2274696d657374616d70222c5b2273222c22323032362d31302d31375430303a30303a30302e3130303030305a225d5d5d5d",
  "sha256": "59c4863c8fc0265d48f1cb99df9e26af340b33b0a001381e841b90de5670c4e4",
  "expected": "VALID_ENCODING"
}
```

#### record-checkpoint-receipt

```json
{
  "id": "record-checkpoint-receipt",
  "record_type": "independent_receipt",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000020",
    "receipt_kind": "checkpoint",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "853df6b5a3ba6b5a4a3d7b7f339dea48ef1b40aca2693b1519cf391581f9135f75f3e9dc342d7767a79a5c8ec0ad79e1aee198d10dee735221f30a2d08c8a202"
  },
  "canonical_utf8": "[\"o\",[[\"contract_version\",[\"s\",\"NI-AUTH-001/Model-B/v1\"]],[\"destination_id\",[\"s\",\"synthetic-audit\"]],[\"durable_at\",[\"s\",\"2026-10-17T00:00:00.000000Z\"]],[\"environment\",[\"s\",\"test\"]],[\"event_digest\",[\"s\",\"25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0\"]],[\"key_id\",[\"s\",\"test_receipt_1\"]],[\"key_version\",[\"n\",\"1\"]],[\"previous_receipt_digest\",[\"s\",\"fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb\"]],[\"receipt_id\",[\"s\",\"00000000-0000-4000-8000-000000000020\"]],[\"receipt_kind\",[\"s\",\"checkpoint\"]],[\"receipt_version\",[\"s\",\"NI-AUDIT-RECEIPT-v1\"]],[\"sequence\",[\"n\",\"1\"]],[\"signature\",[\"s\",\"853df6b5a3ba6b5a4a3d7b7f339dea48ef1b40aca2693b1519cf391581f9135f75f3e9dc342d7767a79a5c8ec0ad79e1aee198d10dee735221f30a2d08c8a202\"]],[\"stream_id\",[\"s\",\"00000000-0000-4000-8000-000000000015\"]]]]",
  "canonical_hex": "5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2266643339386331323034353266613430396632316663326434336237346366643032623765316233313635613065643565383535616136656336336335646562225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303230225d5d2c5b22726563656970745f6b696e64222c5b2273222c22636865636b706f696e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b227369676e6174757265222c5b2273222c223835336466366235613362613662356134613364376237663333396465613438656631623430616361323639336231353139636633393135383166393133356637356633653964633334326437373637613739613563386563306164373965316165653139386431306465653733353232316633306132643038633861323032225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "framed_hex": "4e492d494d4d2d4449474553542d76310a696e646570656e64656e745f726563656970740a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2266643339386331323034353266613430396632316663326434336237346366643032623765316233313635613065643565383535616136656336336335646562225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303230225d5d2c5b22726563656970745f6b696e64222c5b2273222c22636865636b706f696e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b227369676e6174757265222c5b2273222c223835336466366235613362613662356134613364376237663333396465613438656631623430616361323639336231353139636633393135383166393133356637356633653964633334326437373637613739613563386563306164373965316165653139386431306465653733353232316633306132643038633861323032225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "sha256": "a473e15a602e5aa01f1c72457e6e7068d4560dd09b5ff82ff21d8eb8ffe49af5",
  "signing_input_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2266643339386331323034353266613430396632316663326434336237346366643032623765316233313635613065643565383535616136656336336335646562225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303230225d5d2c5b22726563656970745f6b696e64222c5b2273222c22636865636b706f696e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "expected": "VERIFY_TRUE_WITH_TRUSTED_STATE"
}
```

### Cryptographic vectors

#### credential-hmac

```json
{
  "id": "credential-hmac",
  "algorithm": "HMAC-SHA-256",
  "key_hex": "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f",
  "synthetic_bearer": "PUBLIC-SYNTHETIC-BEARER-0000000000000001",
  "verifier_hex": "fa8341cc4e752388ffd25d6101181bfb6e64651c0741e71f5b565616f018152a",
  "message_hex": "4e492d415554482d434f4d4d49542d76310a5b226f222c5b5b2263726564656e7469616c5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303034225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b226b65795f6964222c5b2273222c22746573745f636f6d6d69745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2276657269666965725f616c676f726974686d222c5b2273222c227368613235362d6265617265722d7631225d5d2c5b2276657269666965725f686578222c5b2273222c2266613833343163633465373532333838666664323564363130313138316266623665363436353163303734316537316635623536353631366630313831353261225d5d5d5d",
  "mac_hex": "535b8af7faca0b8c0729103011cb23cd38e1160ec73f13a79c6452e7e05bb7f3"
}
```

#### event-receipt-signature

```json
{
  "id": "event-receipt-signature",
  "algorithm": "Ed25519",
  "seed_hex": "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8",
  "message_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "signature_hex": "f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105",
  "expected": "VERIFY_TRUE"
}
```

#### quarantine-receipt-signature

```json
{
  "id": "quarantine-receipt-signature",
  "algorithm": "Ed25519",
  "seed_hex": "202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f",
  "public_key_hex": "29acbae141bccaf0b22e1a94d34d0bc7361e526d0bfe12c89794bc9322966dd7",
  "message_hex": "4e492d51554152414e54494e452d524543454950542d76310a5b226f222c5b5b2264656c69766572795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303036225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d71756172616e74696e65225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7472795f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303139225d5d2c5b22656e76656c6f70655f646967657374222c5b2273222c2263616539386365366662613533383766386261616661323635643936616435353834303930303665376466346633353531663030613765373635373737636231225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226b65795f6964222c5b2273222c22746573745f71756172616e74696e655f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b227061796c6f61645f646967657374222c5b2273222c2233313064316239343963313232613531323435666362633536616462363033393136656464623532633131323361373534616335303461663133653130353764225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303138225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d51554152414e54494e452d524543454950542d7631225d5d5d5d",
  "signature_hex": "44df9fa4fb0b1e41368517cd007af3ad75fdd7d3d51650171994a559b7f02793c1b27aed122d36340f7bf89d8a51427dc1caf6e26b7d27cde2cd673106fa1505",
  "expected": "VERIFY_TRUE"
}
```

#### rfc8032-ed25519-test1

```json
{
  "id": "rfc8032-ed25519-test1",
  "algorithm": "Ed25519",
  "seed_hex": "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
  "public_key_hex": "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a",
  "message_hex": "",
  "signature_hex": "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b",
  "expected": "VERIFY_TRUE"
}
```

#### rfc4231-hmac-test1

```json
{
  "id": "rfc4231-hmac-test1",
  "algorithm": "HMAC-SHA-256",
  "key_hex": "0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b",
  "message_hex": "4869205468657265",
  "mac_hex": "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7"
}
```

### Invalid vectors

#### missing-observation

```json
{
  "id": "missing-observation",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "observation",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "revision": 2,
    "previous_revision": 1,
    "schema_version": "1.0",
    "semantics_version": "m23-v1",
    "derivation_rule_version": "hybrid-derived-v1",
    "session_ref": "session_test0001",
    "event_ref": null,
    "observed_at": "2026-10-17T00:00:00.000000Z",
    "updated_at_source": "2026-10-17T00:00:00.000000Z",
    "completed_at_source": null,
    "status": "PARTIAL",
    "payload": {
      "value": {
        "exact_json_number_token": "9007199254740993"
      },
      "nested": [
        null,
        true,
        {
          "x": "é"
        }
      ]
    },
    "payload_hash": "1111111111111111111111111111111111111111111111111111111111111111",
    "received_at": "2026-10-17T00:00:00.000000Z",
    "environment": "test",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "grant_id": "00000000-0000-4000-8000-000000000005",
    "delivery_id": "00000000-0000-4000-8000-000000000006",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-observation

```json
{
  "id": "extra-observation",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "observation",
  "input": {
    "id": "00000000-0000-4000-8000-000000000001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "revision": 2,
    "previous_revision": 1,
    "schema_version": "1.0",
    "semantics_version": "m23-v1",
    "derivation_rule_version": "hybrid-derived-v1",
    "session_ref": "session_test0001",
    "event_ref": null,
    "observed_at": "2026-10-17T00:00:00.000000Z",
    "updated_at_source": "2026-10-17T00:00:00.000000Z",
    "completed_at_source": null,
    "status": "PARTIAL",
    "payload": {
      "value": {
        "exact_json_number_token": "9007199254740993"
      },
      "nested": [
        null,
        true,
        {
          "x": "é"
        }
      ]
    },
    "payload_hash": "1111111111111111111111111111111111111111111111111111111111111111",
    "received_at": "2026-10-17T00:00:00.000000Z",
    "environment": "test",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "grant_id": "00000000-0000-4000-8000-000000000005",
    "delivery_id": "00000000-0000-4000-8000-000000000006",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-current_projection

```json
{
  "id": "missing-current_projection",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "current_projection",
  "input": {
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "revision": 2,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000008",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-current_projection

```json
{
  "id": "extra-current_projection",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "current_projection",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "revision": 2,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000008",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-journey_link

```json
{
  "id": "missing-journey_link",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "journey_link",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "journey_id": null,
    "linkage_basis": "unresolved",
    "linkage_evidence": {},
    "created_at": "2026-10-17T00:00:00.000000Z",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000010",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-journey_link

```json
{
  "id": "extra-journey_link",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "journey_link",
  "input": {
    "id": "00000000-0000-4000-8000-000000000009",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "journey_id": null,
    "linkage_basis": "unresolved",
    "linkage_evidence": {},
    "created_at": "2026-10-17T00:00:00.000000Z",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000010",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-credential_authorization

```json
{
  "id": "missing-credential_authorization",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "credential_authorization",
  "input": {
    "status": "active",
    "label": "synthetic",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "last_used_at": null,
    "revoked_at": null,
    "verifier_algorithm": "sha256-bearer-v1",
    "verifier_commitment": "535b8af7faca0b8c0729103011cb23cd38e1160ec73f13a79c6452e7e05bb7f3",
    "commitment_key_id": "test_commit_1",
    "commitment_key_version": 1,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-credential_authorization

```json
{
  "id": "extra-credential_authorization",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "credential_authorization",
  "input": {
    "id": "00000000-0000-4000-8000-000000000004",
    "status": "active",
    "label": "synthetic",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "last_used_at": null,
    "revoked_at": null,
    "verifier_algorithm": "sha256-bearer-v1",
    "verifier_commitment": "535b8af7faca0b8c0729103011cb23cd38e1160ec73f13a79c6452e7e05bb7f3",
    "commitment_key_id": "test_commit_1",
    "commitment_key_version": 1,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-tenant_binding

```json
{
  "id": "missing-tenant_binding",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "tenant_binding",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "status": "active",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "environment": "test",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "approval_ref": "synthetic-approval",
    "approved_by": "test-controller",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-tenant_binding

```json
{
  "id": "extra-tenant_binding",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "tenant_binding",
  "input": {
    "tenant_ref": "tenant_test0001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "status": "active",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "environment": "test",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "approval_ref": "synthetic-approval",
    "approved_by": "test-controller",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-credential_grant

```json
{
  "id": "missing-credential_grant",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "credential_grant",
  "input": {
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "environment": "test",
    "tenant_ref": "tenant_test0001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "status": "active",
    "valid_from": "2026-10-17T00:00:00.000000Z",
    "expires_at": null,
    "approval_ref": "synthetic-approval",
    "approved_by": "test-controller",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "revoked_at": null,
    "revoked_by": null,
    "revocation_reason": null,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-credential_grant

```json
{
  "id": "extra-credential_grant",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "credential_grant",
  "input": {
    "id": "00000000-0000-4000-8000-000000000005",
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "environment": "test",
    "tenant_ref": "tenant_test0001",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "status": "active",
    "valid_from": "2026-10-17T00:00:00.000000Z",
    "expires_at": null,
    "approval_ref": "synthetic-approval",
    "approved_by": "test-controller",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "revoked_at": null,
    "revoked_by": null,
    "revocation_reason": null,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-authorization_audit

```json
{
  "id": "missing-authorization_audit",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "authorization_audit",
  "input": {
    "stream_id": "00000000-0000-4000-8000-000000000012",
    "sequence": 1,
    "previous_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "event_type": "grant_created",
    "record_type": "credential_grant",
    "record_key": {
      "id": "00000000-0000-4000-8000-000000000005"
    },
    "before_state": null,
    "after_state": {
      "id": "00000000-0000-4000-8000-000000000005",
      "credential_id": "00000000-0000-4000-8000-000000000004",
      "environment": "test",
      "tenant_ref": "tenant_test0001",
      "organization_id": "00000000-0000-4000-8000-000000000002",
      "binding_epoch": "00000000-0000-4000-8000-000000000003",
      "status": "active",
      "valid_from": "2026-10-17T00:00:00.000000Z",
      "expires_at": null,
      "approval_ref": "synthetic-approval",
      "approved_by": "test-controller",
      "created_at": "2026-10-17T00:00:00.000000Z",
      "revoked_at": null,
      "revoked_by": null,
      "revocation_reason": null,
      "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
    },
    "before_digest": null,
    "after_digest": "c1e25f6cab4435022cc150f5d4eb8475be4d1463791df0b9f8481ca4d3901756",
    "actor_ref": "test-controller",
    "approval_ref": "synthetic-approval",
    "reason": "test-only",
    "occurred_at": "2026-10-17T00:00:00.000000Z",
    "correlation_id": "00000000-0000-4000-8000-000000000013",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-authorization_audit

```json
{
  "id": "extra-authorization_audit",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "authorization_audit",
  "input": {
    "id": "00000000-0000-4000-8000-000000000011",
    "stream_id": "00000000-0000-4000-8000-000000000012",
    "sequence": 1,
    "previous_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "event_type": "grant_created",
    "record_type": "credential_grant",
    "record_key": {
      "id": "00000000-0000-4000-8000-000000000005"
    },
    "before_state": null,
    "after_state": {
      "id": "00000000-0000-4000-8000-000000000005",
      "credential_id": "00000000-0000-4000-8000-000000000004",
      "environment": "test",
      "tenant_ref": "tenant_test0001",
      "organization_id": "00000000-0000-4000-8000-000000000002",
      "binding_epoch": "00000000-0000-4000-8000-000000000003",
      "status": "active",
      "valid_from": "2026-10-17T00:00:00.000000Z",
      "expires_at": null,
      "approval_ref": "synthetic-approval",
      "approved_by": "test-controller",
      "created_at": "2026-10-17T00:00:00.000000Z",
      "revoked_at": null,
      "revoked_by": null,
      "revocation_reason": null,
      "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
    },
    "before_digest": null,
    "after_digest": "c1e25f6cab4435022cc150f5d4eb8475be4d1463791df0b9f8481ca4d3901756",
    "actor_ref": "test-controller",
    "approval_ref": "synthetic-approval",
    "reason": "test-only",
    "occurred_at": "2026-10-17T00:00:00.000000Z",
    "correlation_id": "00000000-0000-4000-8000-000000000013",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-observation_audit

```json
{
  "id": "missing-observation_audit",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "observation_audit",
  "input": {
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "previous_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "event_type": "observation_retained",
    "record_type": "observation",
    "record_key": {
      "id": "00000000-0000-4000-8000-000000000001"
    },
    "before_digest": null,
    "after_digest": "4b16caaa974468534ed718c171a76d0253266529b8b79a060c919018a7999fd1",
    "authorization_context": {
      "credential_id": "00000000-0000-4000-8000-000000000004",
      "grant_id": "00000000-0000-4000-8000-000000000005",
      "environment": "test",
      "tenant_ref": "tenant_test0001",
      "organization_id": "00000000-0000-4000-8000-000000000002",
      "binding_epoch": "00000000-0000-4000-8000-000000000003",
      "delivery_id": "00000000-0000-4000-8000-000000000006"
    },
    "before_projection": null,
    "after_projection": null,
    "before_link": null,
    "after_link": null,
    "outcome": "accepted",
    "occurred_at": "2026-10-17T00:00:00.000000Z",
    "correlation_id": "00000000-0000-4000-8000-000000000016",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-observation_audit

```json
{
  "id": "extra-observation_audit",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "observation_audit",
  "input": {
    "id": "00000000-0000-4000-8000-000000000014",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "previous_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "event_type": "observation_retained",
    "record_type": "observation",
    "record_key": {
      "id": "00000000-0000-4000-8000-000000000001"
    },
    "before_digest": null,
    "after_digest": "4b16caaa974468534ed718c171a76d0253266529b8b79a060c919018a7999fd1",
    "authorization_context": {
      "credential_id": "00000000-0000-4000-8000-000000000004",
      "grant_id": "00000000-0000-4000-8000-000000000005",
      "environment": "test",
      "tenant_ref": "tenant_test0001",
      "organization_id": "00000000-0000-4000-8000-000000000002",
      "binding_epoch": "00000000-0000-4000-8000-000000000003",
      "delivery_id": "00000000-0000-4000-8000-000000000006"
    },
    "before_projection": null,
    "after_projection": null,
    "before_link": null,
    "after_link": null,
    "outcome": "accepted",
    "occurred_at": "2026-10-17T00:00:00.000000Z",
    "correlation_id": "00000000-0000-4000-8000-000000000016",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-protected_outbox

```json
{
  "id": "missing-protected_outbox",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "protected_outbox",
  "input": {
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-protected_outbox

```json
{
  "id": "extra-protected_outbox",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "protected_outbox",
  "input": {
    "event_id": "00000000-0000-4000-8000-000000000014",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "created_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-independent_receipt

```json
{
  "id": "missing-independent_receipt",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "independent_receipt",
  "input": {
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105"
  }
}
```

#### extra-independent_receipt

```json
{
  "id": "extra-independent_receipt",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "independent_receipt",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105",
    "unclassified_column": null
  }
}
```

#### missing-source_evidence

```json
{
  "id": "missing-source_evidence",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "source_evidence",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "observation_id": "obs_test0001",
    "revision": 2,
    "previous_revision": 1,
    "schema_version": "1.0",
    "semantics_version": "m23-v1",
    "derivation_rule_version": "hybrid-derived-v1",
    "session_ref": "session_test0001",
    "event_ref": null,
    "observed_at": "2026-10-17T00:00:00.000000Z",
    "updated_at_source": "2026-10-17T00:00:00.000000Z",
    "completed_at_source": null,
    "status": "PARTIAL",
    "payload": {
      "value": {
        "exact_json_number_token": "9007199254740993"
      },
      "nested": [
        null,
        true,
        {
          "x": "é"
        }
      ]
    },
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-source_evidence

```json
{
  "id": "extra-source_evidence",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "source_evidence",
  "input": {
    "environment": "test",
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "binding_epoch": "00000000-0000-4000-8000-000000000003",
    "observation_id": "obs_test0001",
    "revision": 2,
    "previous_revision": 1,
    "schema_version": "1.0",
    "semantics_version": "m23-v1",
    "derivation_rule_version": "hybrid-derived-v1",
    "session_ref": "session_test0001",
    "event_ref": null,
    "observed_at": "2026-10-17T00:00:00.000000Z",
    "updated_at_source": "2026-10-17T00:00:00.000000Z",
    "completed_at_source": null,
    "status": "PARTIAL",
    "payload": {
      "value": {
        "exact_json_number_token": "9007199254740993"
      },
      "nested": [
        null,
        true,
        {
          "x": "é"
        }
      ]
    },
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-credential_commitment

```json
{
  "id": "missing-credential_commitment",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "credential_commitment",
  "input": {
    "verifier_algorithm": "sha256-bearer-v1",
    "verifier_hex": "fa8341cc4e752388ffd25d6101181bfb6e64651c0741e71f5b565616f018152a",
    "key_id": "test_commit_1",
    "key_version": 1,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-credential_commitment

```json
{
  "id": "extra-credential_commitment",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "credential_commitment",
  "input": {
    "credential_id": "00000000-0000-4000-8000-000000000004",
    "verifier_algorithm": "sha256-bearer-v1",
    "verifier_hex": "fa8341cc4e752388ffd25d6101181bfb6e64651c0741e71f5b565616f018152a",
    "key_id": "test_commit_1",
    "key_version": 1,
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-quarantine_receipt

```json
{
  "id": "missing-quarantine_receipt",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "quarantine_receipt",
  "input": {
    "receipt_id": "00000000-0000-4000-8000-000000000018",
    "destination_id": "synthetic-quarantine",
    "environment": "test",
    "entry_id": "00000000-0000-4000-8000-000000000019",
    "delivery_id": "00000000-0000-4000-8000-000000000006",
    "envelope_digest": "cae98ce6fba5387f8baafa265d96ad558409006e7df4f3551f00a7e765777cb1",
    "payload_digest": "310d1b949c122a51245fcbc56adb603916eddb52c1123a754ac504af13e1057d",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_quarantine_1",
    "key_version": 1,
    "signature": "44df9fa4fb0b1e41368517cd007af3ad75fdd7d3d51650171994a559b7f02793c1b27aed122d36340f7bf89d8a51427dc1caf6e26b7d27cde2cd673106fa1505"
  }
}
```

#### extra-quarantine_receipt

```json
{
  "id": "extra-quarantine_receipt",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "quarantine_receipt",
  "input": {
    "receipt_version": "NI-QUARANTINE-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000018",
    "destination_id": "synthetic-quarantine",
    "environment": "test",
    "entry_id": "00000000-0000-4000-8000-000000000019",
    "delivery_id": "00000000-0000-4000-8000-000000000006",
    "envelope_digest": "cae98ce6fba5387f8baafa265d96ad558409006e7df4f3551f00a7e765777cb1",
    "payload_digest": "310d1b949c122a51245fcbc56adb603916eddb52c1123a754ac504af13e1057d",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_quarantine_1",
    "key_version": 1,
    "signature": "44df9fa4fb0b1e41368517cd007af3ad75fdd7d3d51650171994a559b7f02793c1b27aed122d36340f7bf89d8a51427dc1caf6e26b7d27cde2cd673106fa1505",
    "unclassified_column": null
  }
}
```

#### missing-audit_stream_state

```json
{
  "id": "missing-audit_stream_state",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "audit_stream_state",
  "input": {
    "last_sequence": 1,
    "last_event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-audit_stream_state

```json
{
  "id": "extra-audit_stream_state",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "audit_stream_state",
  "input": {
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "last_sequence": 1,
    "last_event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### missing-export_state

```json
{
  "id": "missing-export_state",
  "expected": "REJECT",
  "reason": "MANIFEST_MISSING_FIELD",
  "record_type": "export_state",
  "input": {
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "acknowledged_sequence": 1,
    "acknowledged_event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "last_receipt_digest": "fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb",
    "last_checkpoint_at": null,
    "attempt_count": 0,
    "next_attempt_at": null,
    "last_error_code": null,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### extra-export_state

```json
{
  "id": "extra-export_state",
  "expected": "REJECT",
  "reason": "MANIFEST_UNKNOWN_FIELD",
  "record_type": "export_state",
  "input": {
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "acknowledged_sequence": 1,
    "acknowledged_event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "last_receipt_digest": "fd398c120452fa409f21fc2d43b74cfd02b7e1b3165a0ed5e855aa6ec63c5deb",
    "last_checkpoint_at": null,
    "attempt_count": 0,
    "next_attempt_at": null,
    "last_error_code": null,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1",
    "unclassified_column": null
  }
}
```

#### parse-DUPLICATE_DECODED_KEY

```json
{
  "id": "parse-DUPLICATE_DECODED_KEY",
  "expected": "REJECT",
  "reason": "DUPLICATE_DECODED_KEY",
  "input_json": " {\"a\":1,\"\\u0061\":2}",
  "input_utf8_hex": "207b2261223a312c225c7530303631223a327d"
}
```

#### parse-INVALID_JSON_NUMBER

```json
{
  "id": "parse-INVALID_JSON_NUMBER",
  "expected": "REJECT",
  "reason": "INVALID_JSON_NUMBER",
  "input_json": "01",
  "input_utf8_hex": "3031"
}
```

#### parse-NONFINITE_NUMBER

```json
{
  "id": "parse-NONFINITE_NUMBER",
  "expected": "REJECT",
  "reason": "NONFINITE_NUMBER",
  "input_json": "NaN",
  "input_utf8_hex": "4e614e"
}
```

#### parse-EXPONENT_LIMIT

```json
{
  "id": "parse-EXPONENT_LIMIT",
  "expected": "REJECT",
  "reason": "EXPONENT_LIMIT",
  "input_json": "1e4097",
  "input_utf8_hex": "316534303937"
}
```

#### parse-NORMALIZED_LENGTH_LIMIT

```json
{
  "id": "parse-NORMALIZED_LENGTH_LIMIT",
  "expected": "REJECT",
  "reason": "NORMALIZED_LENGTH_LIMIT",
  "input_json": "1e4096",
  "input_utf8_hex": "316534303936"
}
```

#### parse-UNPAIRED_SURROGATE

```json
{
  "id": "parse-UNPAIRED_SURROGATE",
  "expected": "REJECT",
  "reason": "UNPAIRED_SURROGATE",
  "input_json": "\"\\ud800\"",
  "input_utf8_hex": "225c756438303022"
}
```

#### timestamp-invalid-2026-10-17T00:00:00.0000001Z

```json
{
  "id": "timestamp-invalid-2026-10-17T00:00:00.0000001Z",
  "expected": "REJECT",
  "reason": "TIMESTAMP_INVALID",
  "input": "2026-10-17T00:00:00.0000001Z"
}
```

#### timestamp-invalid-2026-10-17T00:00:60Z

```json
{
  "id": "timestamp-invalid-2026-10-17T00:00:60Z",
  "expected": "REJECT",
  "reason": "TIMESTAMP_INVALID",
  "input": "2026-10-17T00:00:60Z"
}
```

#### timestamp-invalid-2026-02-30T00:00:00Z

```json
{
  "id": "timestamp-invalid-2026-02-30T00:00:00Z",
  "expected": "REJECT",
  "reason": "TIMESTAMP_INVALID",
  "input": "2026-02-30T00:00:00Z"
}
```

#### timestamp-invalid-2026-10-17T00:00:00

```json
{
  "id": "timestamp-invalid-2026-10-17T00:00:00",
  "expected": "REJECT",
  "reason": "TIMESTAMP_INVALID",
  "input": "2026-10-17T00:00:00"
}
```

#### timestamp-invalid-0001-01-01T00:00:00+14:00

```json
{
  "id": "timestamp-invalid-0001-01-01T00:00:00+14:00",
  "expected": "REJECT",
  "reason": "TIMESTAMP_INVALID",
  "input": "0001-01-01T00:00:00+14:00"
}
```

#### timestamp-invalid-9999-12-31T23:59:59-14:00

```json
{
  "id": "timestamp-invalid-9999-12-31T23:59:59-14:00",
  "expected": "REJECT",
  "reason": "TIMESTAMP_INVALID",
  "input": "9999-12-31T23:59:59-14:00"
}
```

#### tampered-message

```json
{
  "id": "tampered-message",
  "expected": "REJECT",
  "reason": "SIGNATURE_INVALID",
  "message_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d78",
  "signature_hex": "f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8"
}
```

#### tampered-signature

```json
{
  "id": "tampered-signature",
  "expected": "REJECT",
  "reason": "SIGNATURE_INVALID",
  "message_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "signature_hex": "f105b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8"
}
```

#### wrong-key

```json
{
  "id": "wrong-key",
  "expected": "REJECT",
  "reason": "SIGNATURE_INVALID",
  "message_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "signature_hex": "f005b129b5cd39848c1c878fd618d85e700e8bc0050ecd97ad93087c3633fbffd92e3b13d686b33136a3d10c35aeb5ec115370531d6a346cb05e7f8e635e8105",
  "public_key_hex": "29acbae141bccaf0b22e1a94d34d0bc7361e526d0bfe12c89794bc9322966dd7"
}
```

#### unknown-key

```json
{
  "id": "unknown-key",
  "expected": "REJECT",
  "reason": "POLICY_UNKNOWN_KEY",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### revoked-key

```json
{
  "id": "revoked-key",
  "expected": "REJECT",
  "reason": "POLICY_REVOKED_KEY",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### wrong-environment

```json
{
  "id": "wrong-environment",
  "expected": "REJECT",
  "reason": "POLICY_WRONG_ENVIRONMENT",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### wrong-purpose

```json
{
  "id": "wrong-purpose",
  "expected": "REJECT",
  "reason": "POLICY_WRONG_PURPOSE",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### noncontiguous-sequence

```json
{
  "id": "noncontiguous-sequence",
  "expected": "REJECT",
  "reason": "POLICY_NONCONTIGUOUS_SEQUENCE",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### unmatched-event-digest

```json
{
  "id": "unmatched-event-digest",
  "expected": "REJECT",
  "reason": "POLICY_UNMATCHED_EVENT_DIGEST",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### future-durable-time

```json
{
  "id": "future-durable-time",
  "expected": "REJECT",
  "reason": "POLICY_FUTURE_DURABLE_TIME",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### missing-durable-entry

```json
{
  "id": "missing-durable-entry",
  "expected": "REJECT",
  "reason": "POLICY_MISSING_DURABLE_ENTRY",
  "signed_receipt_reference": "record-independent_receipt",
  "note": "Signature may be mathematically valid; independent trust/state policy must deny acknowledgement."
}
```

#### signed-policy-wrong-environment

```json
{
  "id": "signed-policy-wrong-environment",
  "expected": "REJECT",
  "reason": "POLICY_WRONG_ENVIRONMENT",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "foreign",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "9ed795dbc58b8b4a39cdb10e497b92b5351032c737797e455139f8cb0d7432e3f5f72e5dd5254ee6dad9faa36bd1a97bbd26e0d1e936eeb24bd42ff28af28508"
  },
  "signing_input_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c22666f726569676e225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8",
  "verifier_time": "2026-10-17T00:00:00.000000Z",
  "expected_environment": "test",
  "expected_sequence": 1,
  "expected_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0"
}
```

#### signed-policy-noncontiguous-sequence

```json
{
  "id": "signed-policy-noncontiguous-sequence",
  "expected": "REJECT",
  "reason": "POLICY_NONCONTIGUOUS_SEQUENCE",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 3,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "f84345fb25dade14b1c3213797b6e244941475f99f1c11851d795048e2d58c5dbd3bf2140a59d5b7ed8884852ff1e6ee619a93cf9e34251c2a970d37b342250b"
  },
  "signing_input_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2233225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8",
  "verifier_time": "2026-10-17T00:00:00.000000Z",
  "expected_environment": "test",
  "expected_sequence": 1,
  "expected_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0"
}
```

#### signed-policy-unmatched-event-digest

```json
{
  "id": "signed-policy-unmatched-event-digest",
  "expected": "REJECT",
  "reason": "POLICY_UNMATCHED_EVENT_DIGEST",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:00:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "a211b8762076882bc3ba9f00b7e3752da94343acde44e273923f79cddb77e46aa5670cdf5a9aa69aae5077b8c453daaf546552f5ed463a1d2470852cbbd03c09"
  },
  "signing_input_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2266666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8",
  "verifier_time": "2026-10-17T00:00:00.000000Z",
  "expected_environment": "test",
  "expected_sequence": 1,
  "expected_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0"
}
```

#### signed-policy-future-durable-time

```json
{
  "id": "signed-policy-future-durable-time",
  "expected": "REJECT",
  "reason": "POLICY_FUTURE_DURABLE_TIME",
  "input": {
    "receipt_version": "NI-AUDIT-RECEIPT-v1",
    "receipt_id": "00000000-0000-4000-8000-000000000017",
    "receipt_kind": "event",
    "contract_version": "NI-AUTH-001/Model-B/v1",
    "environment": "test",
    "destination_id": "synthetic-audit",
    "stream_id": "00000000-0000-4000-8000-000000000015",
    "sequence": 1,
    "event_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0",
    "previous_receipt_digest": "0000000000000000000000000000000000000000000000000000000000000000",
    "durable_at": "2026-10-17T00:02:00.000000Z",
    "key_id": "test_receipt_1",
    "key_version": 1,
    "signature": "369e9c231b35956f71f39fba22e74c500ee51ca0ca651e83cc13bb587f8144a240e1ba71b180f3e59204aa852e8b2edd6399291ea0e50259c50ee784f4678902"
  },
  "signing_input_hex": "4e492d41554449542d524543454950542d76310a5b226f222c5b5b22636f6e74726163745f76657273696f6e222c5b2273222c224e492d415554482d3030312f4d6f64656c2d422f7631225d5d2c5b2264657374696e6174696f6e5f6964222c5b2273222c2273796e7468657469632d6175646974225d5d2c5b2264757261626c655f6174222c5b2273222c22323032362d31302d31375430303a30323a30302e3030303030305a225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f646967657374222c5b2273222c2232356631343733643931623639386339663832636632356630323265633637663731303033353035663965656335663737336432386362303364323962346630225d5d2c5b226b65795f6964222c5b2273222c22746573745f726563656970745f31225d5d2c5b226b65795f76657273696f6e222c5b226e222c2231225d5d2c5b2270726576696f75735f726563656970745f646967657374222c5b2273222c2230303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030303030225d5d2c5b22726563656970745f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303137225d5d2c5b22726563656970745f6b696e64222c5b2273222c226576656e74225d5d2c5b22726563656970745f76657273696f6e222c5b2273222c224e492d41554449542d524543454950542d7631225d5d2c5b2273657175656e6365222c5b226e222c2231225d5d2c5b2273747265616d5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303135225d5d5d5d",
  "public_key_hex": "03a107bff3ce10be1d70dd18e74bc09967e4d6309ba50d5f1ddc8664125531b8",
  "verifier_time": "2026-10-17T00:00:00.000000Z",
  "expected_environment": "test",
  "expected_sequence": 1,
  "expected_digest": "25f1473d91b698c9f82cf25f022ec67f71003505f9eec5f773d28cb03d29b4f0"
}
```

#### out-of-range-integer

```json
{
  "id": "out-of-range-integer",
  "expected": "REJECT",
  "reason": "INTEGER_RANGE",
  "record_type": "current_projection",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "observation_row_id": "00000000-0000-4000-8000-000000000001",
    "revision": 2147483648,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000008",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

#### required-nonnull

```json
{
  "id": "required-nonnull",
  "expected": "REJECT",
  "reason": "MANIFEST_NONNULL",
  "record_type": "current_projection",
  "input": {
    "organization_id": "00000000-0000-4000-8000-000000000002",
    "tenant_ref": "tenant_test0001",
    "observation_id": "obs_test0001",
    "observation_row_id": null,
    "revision": 2,
    "updated_at": "2026-10-17T00:00:00.000000Z",
    "audit_event_id": "00000000-0000-4000-8000-000000000008",
    "digest_version": "NI-IMM-DIGEST-v1/typed-tree-1"
  }
}
```

### Comparison vectors

#### authentication-change

```json
{
  "id": "authentication-change",
  "source_before_digest": "5c227fbf6f8b81f94f7435796b287e97abbb972f927ca17a32c211af6d42e645",
  "source_after_digest": "5c227fbf6f8b81f94f7435796b287e97abbb972f927ca17a32c211af6d42e645",
  "full_before_digest": "4b16caaa974468534ed718c171a76d0253266529b8b79a060c919018a7999fd1",
  "full_after_digest": "b7382e465abe281b9831e27b42a2135d4b31f6fc5eaa1e47f72f72cf020add30",
  "expected": "DUPLICATE_SOURCE_NO_HISTORICAL_REWRITE"
}
```

#### same-revision-source-change

```json
{
  "id": "same-revision-source-change",
  "before_digest": "5c227fbf6f8b81f94f7435796b287e97abbb972f927ca17a32c211af6d42e645",
  "after_digest": "018d2868182a6f8a63ee2f3266a61a2190ebf680f1b19d1b4d3d1ed35f9eaccc",
  "changed_canonical_hex": "5b226f222c5b5b2262696e64696e675f65706f6368222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303033225d5d2c5b22636f6d706c657465645f61745f736f75726365222c5b227a225d5d2c5b2264657269766174696f6e5f72756c655f76657273696f6e222c5b2273222c226879627269642d646572697665642d7631225d5d2c5b226469676573745f76657273696f6e222c5b2273222c224e492d494d4d2d4449474553542d76312f74797065642d747265652d31225d5d2c5b22656e7669726f6e6d656e74222c5b2273222c2274657374225d5d2c5b226576656e745f726566222c5b227a225d5d2c5b226f62736572766174696f6e5f6964222c5b2273222c226f62735f7465737430303031225d5d2c5b226f627365727665645f6174222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d2c5b226f7267616e697a6174696f6e5f6964222c5b2273222c2230303030303030302d303030302d343030302d383030302d303030303030303030303032225d5d2c5b227061796c6f6164222c5b226f222c5b5b226e6573746564222c5b2261222c5b5b227a225d2c5b2262222c747275655d2c5b226f222c5b5b2278222c5b2273222c22c3a9225d5d5d5d5d5d5d2c5b2276616c7565222c5b226e222c2239303037313939323534373430393934225d5d5d5d5d2c5b2270726576696f75735f7265766973696f6e222c5b226e222c2231225d5d2c5b227265766973696f6e222c5b226e222c2232225d5d2c5b22736368656d615f76657273696f6e222c5b2273222c22312e30225d5d2c5b2273656d616e746963735f76657273696f6e222c5b2273222c226d32332d7631225d5d2c5b2273657373696f6e5f726566222c5b2273222c2273657373696f6e5f7465737430303031225d5d2c5b22737461747573222c5b2273222c225041525449414c225d5d2c5b2274656e616e745f726566222c5b2273222c2274656e616e745f7465737430303031225d5d2c5b22757064617465645f61745f736f75726365222c5b2273222c22323032362d31302d31375430303a30303a30302e3030303030305a225d5d5d5d",
  "expected": "409_CONFLICT"
}
```

#### numeric-equivalence

```json
{
  "id": "numeric-equivalence",
  "a_hex": "5b226e222c2231225d",
  "b_hex": "5b226e222c2231225d",
  "equal": true
}
```

#### string-vs-number

```json
{
  "id": "string-vs-number",
  "a_hex": "5b2273222c2231225d",
  "b_hex": "5b226e222c2231225d",
  "equal": false
}
```

#### unicode-composition

```json
{
  "id": "unicode-composition",
  "a_hex": "5b2273222c22c3a9225d",
  "b_hex": "5b2273222c2265cc81225d",
  "equal": false
}
```

#### null-vs-missing

```json
{
  "id": "null-vs-missing",
  "a_hex": "5b226f222c5b5b2261222c5b227a225d5d5d5d",
  "b_hex": "5b226f222c5b5d5d",
  "equal": false
}
```


# Preserved review-assembly-1 source history

# NI-AUTH-001/Model-B/v1 — Technical Specification

Assembly revision: review-assembly-1  
Status: PARTIAL — authoritative review candidate; not jointly ratified  
Source baseline: `57eaec27b4b5022ec5ba5e81c0cdcb3182c150f3`  
Assembly date: 2026-10-17 UTC (2026-10-16 America/Los_Angeles)  
Owner: WS-001. Reviewers: WS-004, WS-022, WS-024. Consumer: Master / WS-025 M1.

## Provenance and source inventory

This is a documentary assembly of complete source responses, not a new architecture proposal. Source bodies below retain their wording; Markdown table spacing may differ when copied from conversation. No implementation or production verification is claimed.

| Source | Identification | Completeness |
|---|---|---|
| S1 | WS-001 assistant response to “WS-001 — Final NI-AUTH-001/Model-B/v1 Contract Ratification”, beginning “STATUS: PARTIAL — WS-001 ratifies the following technical design.” in this conversation | Complete visible response, including all numbered sections and owner/validation sections |
| S2 | WS-001 assistant response to WS-022 Ratification Report, titled “WS-001 → Master / WS-022 / WS-004 — Consolidated Contract Addendum” in this conversation | Complete visible response |
| S3 | Exact-contract amendments; saved source “Pasted markdown(6).md”, library identity libfile_ed6a68d82a348191a5e4846af56b8ed5, file identity file_000000003ff481fd8663dfa0d5102d7b; created/modified 2026-10-17T04:15:06.118714Z; full read 152/152 lines, has_more=false | Complete returned text, included below |

S1 and S2 are sourced from full conversation messages, not memory summaries. No standalone source files for S1/S2 were located. S3's returned version_id was null; no version number is invented.

Numbering discrepancy: earlier requests and S2 call S1 “14-part”. The complete visible S1 has numbered sections 1–12 followed by compatibility, security review, validation, ownership, unresolved decisions and M1 recommendation. No missing numbered sections 13/14 have been fabricated.

## Precedence and version history

1. S1 establishes the original technical requirements.
2. S2 (Addendum A) supersedes conflicting S1 wording.
3. S3 supplies the latest exact-contract amendments and supersedes conflicting earlier wording.
4. This assembly adds provenance and review notes only. It does not resolve unapproved technical choices or confer authority.

| Superseded clause | Controlling source |
|---|---|
| S1 section 11: blanket quarantine of previously unseen authorized lower revisions; terminal-stale compatibility references and stale-quarantine test wording | S2 section 1: retain authorized lower revision and atomic audit, preserve current pointer, 200 stale; S3 acknowledgement schedule |
| S1 section 2: envelope representation unresolved | S3 Binding Epoch Envelope fixes proposed headers; WS-004 concurrence still required |
| S1 sections 8/11: retry schedule unspecified | S3 Retry Schedule: eight attempts, exact delays/jitter and 60-minute window |
| S1 section 10: backlog capacity and recovery unspecified | S2 section 2: age/count/checkpoint thresholds, stop and reconciled recovery |
| S1 section 6: general digest rules only | S3 Digest Manifest and Golden Vectors refine coverage/encoding, subject to open completeness issues below |
| S2 section 3: general quarantine controls | S3 Quarantine Contract supplies detailed durability/access/replay requirements; destination remains undesignated |

## Remaining operational decisions and activation gates

- Joint WS-004 and WS-022 concurrence on this exact assembled candidate remains pending.
- Master must designate independent audit and quarantine destinations/administrators and accountable privacy, retention, deletion and backup authorities.
- Independent integrity-key custody, verification-commitment algorithm and rotation policy remain unresolved.
- S3 does not define the exact complete typed-tree grammar despite requiring type tags. Do not invent it during assembly.
- S3 provides existing-column inventories and proposed fields, but some event manifests remain descriptive rather than exact typed column definitions. S1's governing audit-reference/change-timestamp requirements remain normative even where absent from a proposed field list.
- Initial golden vectors cover framing/basic JSON only, not complete records, typed payloads, numeric normalization, timestamps or commitments. They were computed by WS-001, not independently certified by WS-024.
- Duplicate comparison must distinguish immutable source evidence from receipt/authentication provenance; no mutation of original provenance is permitted.
- Concrete receipt signature algorithm, key lifecycle and trust configuration require approval.
- Retry-envelope acknowledgement requires future response compatibility; no deployed-support claim is made.
- Quarantine storage retry policy, limits and alert ownership remain to be designated.
- Original epoch capture/provisioning and queued-delivery cutover require WS-004 agreement; existing deliveries must not be silently relabelled.
- Credential-safe logging/transport, full schema coverage, concurrency, admission limits, governance and rollback require separately authorized disposable validation.
- No retention duration is approved. No prototype or runtime implementation is authorized.
- Production V1 remains HOLD. No customer network access, M2, production schema/grants, rotation, canary changes, merge, deployment, commit or push is authorized.

## S1 — Original technical specification (source body)

**STATUS:** PARTIAL — WS-001 ratifies the following technical design. Implementation and independent security acceptance remain pending.

**CONTRACT VERSION:** `NI-AUTH-001/Model-B/v1`

**TECHNICAL SPECIFICATION:**

This specification fixes the Core requirements without changing Model B. Unconfirmed Edge transport details and operational governance remain explicit acceptance gates.

**1. Credential possession and transport**

Edge retains HTTPS bearer authentication. Core passes the original bearer transiently through a bound parameter over a certificate-verified TLS database connection to the restricted writer.

The database independently hashes the presented secret, verifies the active credential and evaluates its explicit grants. Neither a credential ID nor a stored digest is accepted as possession proof.

The writer is non-login, non-bypass, narrowly privileged and invoked through a security-definer function with an empty trusted search path and fully qualified objects. Application roles cannot assume the writer role, change authorization records or invoke a proof-free ingestion fallback.

Credential-bearing operations must exclude secrets from statement/parameter logging, gateway capture, tracing, monitoring, exceptions and response bodies. Parameterization alone is insufficient. Failure responses contain allowlisted codes and generated correlation IDs.

**Activation gate:** If disposable testing cannot demonstrate credential-safe transport across the actual telemetry stack, this transport cannot activate.

**2. Exact authorization relationship**

Authorization requires one unambiguous active relationship:

`credential → explicit grant → environment + tenant reference + organization + binding epoch → active binding`

- Environment is a protected deployment identifier, never inferred from hostname or caller input.
- Tenant reference uses exact canonical matching; no case folding or alias fallback.
- Organization is derived from the protected binding and must equal the grant’s organization.
- Binding epoch is an immutable UUID identifying a binding generation.
- The delivery’s original epoch must equal both the grant epoch and active binding epoch.
- Intelligence Contract v1 validation succeeds before evidence persistence.

The original environment, tenant and epoch must be captured with the queued delivery and preserved across retries. Core must not attach today’s epoch to an older delivery.

An additive transport envelope may carry this context while leaving the observation payload unchanged. **Its exact representation requires WS-004 acceptance; absent context denies delivery after enforcement.** Context fields select the authorization relationship; they do not themselves confer authority.

**3. Grant lifecycle**

Each grant contains immutable identity and scope fields, approval reference, approving actor, validity interval, lifecycle state and revocation metadata.

Only the independently authorized control plane may create or change grants. Grant creation requires explicit approval of the credential’s tenant set. Historical deliveries and organization membership provide no authority.

Validity is evaluated using database time: `valid_from ≤ authorization_time < expires_at`, where an absent expiry is permitted only by an explicitly approved policy. Revocation is terminal; replacement requires a new grant. Ambiguous overlapping grants deny authorization.

Multi-tenant credentials require separately approved grants for every tenant.

**4. Revocation, expiration and reassignment**

Authorization locks remain held through commit. Revocation and scope changes use conflicting locks, establishing transaction ordering:

- Ingestion authorized and committed before revocation takes effect remains accepted.
- Ingestion ordered after revocation denies.
- Retries always reauthorize.
- Authorization must still be valid at the final pre-commit check.

Reassignment disables the prior binding generation and invalidates its grants. Historical observations retain their original ownership. Cross-organization tenant-reference reuse is prohibited under this version; use a new tenant reference.

Credential replacement does not inherit grants automatically.

**5. Fail-closed outcomes**

| Condition | Result |
|---|---|
| Missing/invalid/revoked credential | 401 |
| Missing, expired, ambiguous or foreign grant; environment/org/epoch mismatch; inactive binding | 403 |
| Invalid observation payload | 400 |
| Same observation revision with conflicting source evidence | 409 |
| Database contention, audit failure or admission gate | 503 |
| Accepted observation | 201 |
| Identical authorized replay | 200, `duplicate` |

Errors disclose no secret or foreign-tenant detail. Denied deliveries create no authoritative observation, current pointer or journey link.

**6. Integrity digest specification**

Version: `NI-IMM-DIGEST-v1`.

Digest input is:

`UTF8("NI-IMM-DIGEST-v1\n" + record_type + "\n" + canonical_document)`

Hash algorithm: SHA-256; output: lowercase hexadecimal.

Canonical documents use:

- Object keys sorted by UTF-8 byte order.
- No insignificant whitespace.
- Preserved array order.
- Explicit nulls.
- Lowercase canonical UUID strings.
- UTC timestamps formatted `YYYY-MM-DDTHH:mm:ss.ffffffZ`.
- Database integer/numeric fields represented as canonical decimal strings without exponent notation or redundant zeros.
- JSON strings with deterministic escaping and no Unicode normalization.
- Payload numbers encoded through an exact decimal parser, never a lossy floating-point conversion.

Duplicate JSON keys and unsupported numeric values are rejected. Shared byte-level golden vectors are mandatory.

| Record | Integrity-covered fields |
|---|---|
| Observation | Every persisted identity, ownership, revision, payload, hash, provenance, source/receipt timestamp and authorization-reference field |
| Current projection | Complete scope key, selected observation/revision, timestamps and audit reference |
| Journey link | Scope, observation/journey targets, resolution state, authority, provenance and timestamps |
| Authorization event | Grant/binding/credential identity, approval, scope, epoch, validity and before/after lifecycle state |
| Audit event | Stream, sequence, previous digest, event identity/type, affected record digests, outcome, timestamp and correlation ID |

Credential secrets and verification digests are excluded from exported audit documents. Mutable export-attempt metadata is outside the immutable event body; acknowledgement changes require validated receipts.

The implementation must freeze a column-by-column manifest. An added or unclassified persisted column fails acceptance until classified.

**7. Deterministic locking**

All governed transactions acquire locks in this order:

1. Credentials, sorted by immutable ID.
2. Grants, sorted by immutable ID.
3. Bindings, sorted by environment and tenant reference.
4. Observation streams, sorted by environment, organization, tenant and observation ID.
5. Current projections, then journey links, each sorted by primary key.
6. Audit stream counters, sorted by stream ID.

No later step may acquire an earlier category. Controller operations determine a bounded affected set, lock and revalidate it; a changed set requires rollback.

Audit sequences use transactional counters, with sequence and previous digest allocated under the stream lock. Rolled-back transactions create no committed sequence gap.

**8. Bounded timeouts**

| Operation | Lock timeout | Statement timeout | Transaction deadline |
|---|---:|---:|---:|
| Ingestion | 2 seconds | 8 seconds | 10 seconds |
| Authorization controller | 2 seconds | 10 seconds | 15 seconds |
| Receipt recording | 2 seconds | 5 seconds | 8 seconds |

Controller batches affect at most 100 grants/bindings. Deadline enforcement must cancel and roll back the database transaction before releasing the connection. No retry occurs inside an aborted transaction.

These are design parameters requiring disposable validation.

**9. Atomic persistence**

Observation evidence, authorized projection/link changes, audit events, transactional counters and outbox insertion commit together. Authorization-control transactions likewise commit their changes and audit/outbox records atomically.

Any required audit failure rolls back the transaction. No successful response precedes commit.

A duplicate must match immutable source evidence and have a valid audit association. A replacement credential may replay identical evidence after current authorization succeeds; original ingestion provenance remains unchanged.

**10. Independent receipts and backlog**

The independent destination issues a signed receipt only after durable storage. The receipt covers contract version, destination identity, stream, sequence and event digest.

Receipt verification uses protected trust configuration. Ingestion and exporter processes possess no destination signing key or destination rewrite/delete authority. Acknowledgement requires an exact valid receipt; contiguous advancement cannot skip missing events.

Backlog age is measured from the oldest unacknowledged committed event:

- **5 minutes:** warning.
- **15 minutes:** critical; stop new observation admission with retryable 503.
- Preserve durable outbox records and keep export/reconciliation available.

Backlog capacity limits and recovery-clearance rules require operational acceptance before activation. No receipt means no acknowledgement.

**11. Stale delivery, quarantine and retries**

Stale authorization or binding epoch always denies observation persistence.

For this contract’s fail-closed stale-delivery requirement, an older, previously unseen observation revision is quarantined rather than inserted into authoritative history. It cannot replace the current pointer. An already retained identical revision may return `duplicate` only after current authorization succeeds.

This supersedes the earlier proposal to retain new stale revisions and return successful `stale`.

Quarantine preserves original context without retargeting. It is restricted operational evidence, excluded from customer APIs and authoritative observation projections. Replay requires governed approval and fresh authorization; original evidence is never rewritten.

WS-004 must accept the terminal stale outcome and quarantine disposition. HTTP 401/403 remain non-retryable. Network failures and 408/429/5xx permit bounded retries; exact retry count/window requires WS-004 agreement. Recovery never bypasses authorization.

**12. Migration, rollback and canary continuity**

The eventual migration must:

- Inventory callers, privileges, credential scope and tenant relationships.
- Establish explicitly approved grants and binding epochs.
- Introduce mutation guards, tenant-consistent constraints and protected audit structures.
- Establish a baseline checkpoint clearly distinguished from original ingestion-time audit.
- Remove direct mutation and proof-free execution authority atomically with cutover.
- Prevent organization cascades from deleting protected evidence.
- Keep deletion disabled pending approved retention and hold policies.

Existing queued deliveries lacking original epoch context cannot be silently upgraded.

Canary activation requires separate WS-004 acceptance of transport, queued-delivery handling and scope. This specification authorizes no canary modification.

Rollback preserves evidence, receipts and outbox and pauses ingestion where necessary. It does not automatically restore broad privileges or proof-free ingestion. Any rollback reopening those paths requires explicit WS-022 risk acceptance.

**WS-004 COMPATIBILITY:** Pending final acceptance of the original-context envelope, terminal stale behavior, retry bounds, backlog/recovery behavior and canary transition. Payload compatibility alone does not establish delivery compatibility.

**WS-022 REVIEW STATUS:** Accepted security direction; independent ratification of this complete specification remains pending. In particular, review the explicit stale-revision disposition and credential telemetry requirements.

**WS-024 VALIDATION SCOPE:**

| Area | Required disposable evidence |
|---|---|
| Mutation controls | Historical INSERT bypass, UPDATE, DELETE, TRUNCATE and payload/hash rewrites denied |
| Authorization | Valid grants succeed; missing, foreign, ambiguous, expired, revoked and mismatched context deny |
| Concurrency | Ingestion versus revocation; overlapping controller batches; deterministic lock order and bounded waits |
| Revisions/replay | Advancement, identical replay, conflicting revision and stale quarantine |
| Tenant integrity | Foreign organization pointers and journey links denied |
| Digests | Golden vectors, complete column coverage and changes to every covered field detected |
| Secrecy | Success/error/timeout paths across database, gateway, tracing and monitoring |
| Audit | Atomic rollback, authorization/projection/link coverage and sequence integrity |
| Receipts | Forgery, wrong event/destination, skipped sequence and replay handling |
| Operations | Destination outage, thresholds, durable recovery and reconciliation |
| Governance/rollback | Disabled deletion/cascades, hold boundaries and rollback preserving protections |

**IMPLEMENTATION OWNER:** WS-001. Independent validation: WS-024. Security ratification: WS-022. Edge compatibility: WS-004.

**UNRESOLVED DECISIONS:**

- WS-004 approval of the exact original-context envelope and delivery dispositions.
- Independent audit destination, administrator and receipt trust configuration.
- Quarantine ownership and approved evidence/retention rules.
- Retry bounds, backlog capacity and recovery-clearance criteria.
- Named privacy, retention, deletion and backup authorities.
- Independent security ratification and subsequent disposable evidence.

**M1 CLOSURE RECOMMENDATION:** PARTIAL — technical contract submitted for ratification. Master and WS-025 should track the remaining decisions explicitly. No implemented-control or customer-readiness claim is supported.

No prototype, M2 implementation, production mutation, credential rotation, canary change, merge or deployment occurred.

## S2 — Technical Specification, Addendum A (source body)

**WS-001 → Master / WS-022 / WS-004 — Consolidated Contract Addendum**

**STATUS:** PARTIAL — WS-001 ratifies this proposed design; joint concurrence remains pending.

**ARTIFACT:** `NI-AUTH-001/Model-B/v1 — Technical Specification, Addendum A`

The preceding 14-part WS-001 technical specification plus the corrections below constitute the review artifact. These corrections supersede conflicting wording in earlier WS-001 reports. No controls are implemented or validated.

**1. Stale authorization versus observation revisions**

| Case | Core behavior | Required Edge behavior |
|---|---|---|
| Invalid credential | 401; no observation persistence | Stop automatic retries; restricted quarantine |
| Invalid grant, foreign scope or outdated epoch | 403; no observation persistence | Stop automatic retries; preserve original context |
| Authorized identical retained revision | 200 `duplicate` | Acknowledge |
| Authorized, previously unseen lower revision | Retain immutable historical evidence and atomic audit; leave current pointer unchanged; 200 `stale` | Acknowledge only after WS-004 explicitly accepts this outcome |
| Same revision with conflicting evidence | 409; no replacement | Stop automatic retries; governed reconciliation |
| Transient infrastructure/audit failure | 503; transaction rolled back | Bounded retry |

**Correction:** WS-001 withdraws its previous proposal to quarantine every authorized lower revision. Stale authorization fails closed; authorized revision ordering follows the historical-evidence policy above. This preserves the existing Core distinction between retained history and the current projection. WS-004 concurrence remains required before activation.

**2. Audit enforcement parameters**

The following are **proposed acceptance parameters**, requiring WS-004 operational concurrence and WS-022 approval:

| Measure | Warning | Stop new observation admission |
|---|---:|---:|
| Oldest unacknowledged event | 5 minutes | 15 minutes |
| Unacknowledged events | 50,000 | 100,000 |
| Age of latest independently verified checkpoint/heartbeat | 5 minutes | 15 minutes |

Any stop condition returns retryable 503. Missing initial checkpoint, invalid receipt, detected sequence gap or digest mismatch also stops admission. Export and reconciliation remain available.

Admission checks and capacity reservations must be transactionally coordinated so concurrent ingestion cannot bypass the count limit. Local audit/outbox failure always rolls back ingestion.

Recovery requires verified contiguous receipts, matching digests, no unresolved integrity discrepancy, backlog below warning limits, a fresh independent checkpoint and explicit clearance by the designated audit operator. No automatic scope relaxation.

**3. Quarantine controls**

- **Authority:** Governed operational reconciliation; owner designated by Master.
- **Contents:** Minimum necessary original delivery/context, reason code, timestamps and correlation reference. Never bearer secrets or credential verification digests.
- **Access:** Dedicated restricted operator scope; no customer access or ingestion-application update/delete authority.
- **Ownership:** Claimed tenant context remains untrusted until verified. Quarantine does not establish observation ownership or create projections/journey links.
- **Retention:** Requires named privacy/retention authority and approved policy before activation. No duration is assumed.
- **Replay:** Requires an approved reconciliation record and fresh authorization. Preserve original evidence; never replace its epoch or silently retarget it.

The original queue must not acknowledge a denied delivery as safely quarantined until its approved quarantine destination confirms durable receipt. Quarantine failure cannot turn denial into successful ingestion.

**4. Technical specification carried forward**

The identified specification retains:

- Transient bearer verification through bound parameters over verified TLS, subject to demonstrated telemetry secrecy.
- Immutable UUID binding epochs and original delivery-context preservation.
- `NI-IMM-DIGEST-v1` canonicalization and complete persisted-column manifests.
- Deterministic credential → grant → binding → observation → projection → link → audit-counter locking.
- Ingestion timeouts of **2s lock / 8s statement / 10s transaction**; controller **2s / 10s / 15s**; receipt recording **2s / 5s / 8s**.
- Atomic evidence, governed changes, audit sequencing and outbox commits.
- Independently verifiable durable receipts.
- Migration without inferred grants and rollback that preserves authorization and evidence.

**REMAINING CONDITIONS:** Exact Edge epoch-envelope representation, bounded retry schedule, quarantine ownership, independent audit destination/administrator, governance assignments, column manifests/golden vectors and independent validation.

**OWNER HANDOFF:**

- **WS-004:** Accept or reject this exact artifact’s delivery and operational behavior.
- **WS-022:** Review this artifact for final design ratification.
- **WS-024:** Prepare independent disposable validation against it.
- **Master / WS-025:** Keep M1 **PARTIAL** until concurrence closes; separately authorize any prototype.

**Production V1 remains HOLD.** No prototype, production changes, credential rotation, canary changes, customer access, merge, deployment or M2 implementation occurred.

## S3 — Latest exact-contract amendments (source body)

**STATUS:** PARTIAL — the four sections below complete WS-001’s proposed technical requirements. Destination designation and independent owner acceptance remain open.

**CONTRACT ARTIFACT:** `NI-AUTH-001/Model-B/v1 — Technical Specification, Addendum A`

These are in-place amendments to the existing specification and Addendum A, not a separate contract. They supersede conflicting earlier wording. No repository document was modified.

**BINDING EPOCH ENVELOPE:**

Keep the existing observation JSON body and HTTPS bearer authentication. Add these required HTTP headers:

| Header                            | Type and representation                                                                        |
| --------------------------------- | ---------------------------------------------------------------------------------------------- |
| `TraceKit-Authorization-Contract` | Exact string `NI-AUTH-001/Model-B/v1`                                                          |
| `TraceKit-Environment`            | Case-sensitive string matching protected Core configuration; pattern `[a-z][a-z0-9_-]{0,31}`   |
| `TraceKit-Tenant-Ref`             | Case-sensitive string matching `^tenant_[A-Za-z0-9_-]{8,128}$`; must equal payload `tenantRef` |
| `TraceKit-Binding-Epoch`          | Lowercase canonical UUID                                                                       |
| `TraceKit-Delivery-Id`            | Lowercase canonical UUID, generated once per queued delivery                                   |

Reject repeated headers, comma-joined values, invalid encodings and missing required fields. Do not trim or case-normalize identifiers into a match.

The bearer proves credential possession. Headers establish requested context only. The database independently verifies an active credential and exactly one active grant matching environment, tenant, canonical organization and binding epoch, together with the active binding.

Edge durably captures the envelope alongside the observation when enqueuing. Retries preserve delivery ID, envelope and observation unchanged. Credential replacement may change the bearer only through an approved credential transition; it cannot change queued tenant/epoch context.

Missing or invalid envelope returns sanitized 400. An outdated epoch or unauthorized scope returns 403. Neither persists an authoritative observation.

This is additive transport work requiring WS-004 concurrence. Existing canary traffic remains unchanged until separately authorized cutover. Core must never fill missing epochs from current bindings or silently retarget queued observations.

**RETRY SCHEDULE:**

Proposed exact schedule, pending WS-004 acceptance:

- Maximum **8 delivery attempts**, including the initial attempt.
- Seven retry base delays: **5s, 15s, 45s, 120s, 300s, 600s, 900s**.
- Each delay receives independent uniform jitter from **80% to 120%** of its base.
- Maximum automatic delivery window: **60 minutes from first attempt**.
- Respect a valid `Retry-After` when longer than the jittered delay, but never schedule beyond that window.
- Persist attempt counters and next-attempt times durably. Worker restarts do not reset either limit.

| Outcome                                                        | Queue disposition                                                           |
| -------------------------------------------------------------- | --------------------------------------------------------------------------- |
| 201 `accepted`                                                 | Acknowledge after valid matching response                                   |
| 200 `duplicate`                                                | Acknowledge after valid matching response                                   |
| 200 `stale`                                                    | Acknowledge: historical evidence/audit committed; current pointer unchanged |
| 400, 401, 403, 409, other terminal 4xx                         | No automatic redelivery; durable quarantine                                 |
| 408, 429, 5xx, network failure                                 | Retry within both bounds                                                    |
| Unexpected 2xx, malformed response, response identity mismatch | Treat as protocol failure; bounded retry, then quarantine                   |

Success responses must match delivery ID, observation ID and revision. An ambiguous timeout after commit is retried unchanged; database idempotency resolves it.

On exhaustion, transfer to durable quarantine with reason `retry_exhausted`. A terminal delivery leaves the active queue only after a matching quarantine receipt. Quarantine-storage failure preserves the original durable queue item in a parked state; it does not restart provider delivery or discard the item.

**DIGEST MANIFEST:**

The following existing columns were checked against the local schema migrations. Proposed additions are design fields, not deployed columns.

| Record             | Existing persisted columns covered                                                                                                                                                                                                                                                                    |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Observation        | `id`, `organization_id`, `tenant_ref`, `observation_id`, `revision`, `previous_revision`, `schema_version`, `semantics_version`, `derivation_rule_version`, `session_ref`, `event_ref`, `observed_at`, `updated_at_source`, `completed_at_source`, `status`, `payload`, `payload_hash`, `received_at` |
| Current projection | `organization_id`, `tenant_ref`, `observation_id`, `observation_row_id`, `revision`, `updated_at`                                                                                                                                                                                                     |
| Journey link       | `id`, `organization_id`, `observation_row_id`, `journey_id`, `linkage_basis`, `linkage_evidence`, `created_at`                                                                                                                                                                                        |
| Credential         | `id`, `status`, `label`, `created_at`, `last_used_at`, `revoked_at`; special treatment for `token_hash` below                                                                                                                                                                                         |
| Binding            | `tenant_ref`, `organization_id`, `status`, `created_at`, `updated_at`                                                                                                                                                                                                                                 |

Required proposed fields and record manifests:

| Record                         | Additional integrity-covered fields                                                                                                                                                                                        |
| ------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Observation                    | `environment`, `binding_epoch`, `credential_id`, `grant_id`, `delivery_id`, `digest_version`                                                                                                                               |
| Binding                        | `environment`, `binding_epoch`, `approval_ref`, `approved_by`                                                                                                                                                              |
| Grant                          | `id`, `credential_id`, `environment`, `tenant_ref`, `organization_id`, `binding_epoch`, `status`, `valid_from`, `expires_at`, `approval_ref`, `approved_by`, `created_at`, `revoked_at`, `revoked_by`, `revocation_reason` |
| Projection/link mutation event | Record identity, complete before/after documents, actor authority, reason, timestamp and correlation ID                                                                                                                    |
| Authorization event            | Record identity, complete before/after nonsecret state, actor, approval reference, reason and timestamp                                                                                                                    |
| Audit event                    | `id`, `stream_id`, `sequence`, `previous_digest`, `event_type`, `record_type`, `record_key`, `before_digest`, `after_digest`, `authorization_context`, `outcome`, `occurred_at`, `correlation_id`, `digest_version`        |
| Outbox immutable body          | `event_id`, `destination_id`, `stream_id`, `sequence`, `event_digest`, `created_at`                                                                                                                                        |
| Receipt                        | `receipt_version`, `destination_id`, `stream_id`, `sequence`, `event_digest`, `durable_at`, `key_id`, `signature`                                                                                                          |

`token_hash` remains protected verification material. Its integrity is covered by a keyed commitment using an independently controlled integrity key, not by exporting the verification digest. Key version and commitment are audited. This introduces an explicit key-management dependency.

Row/event digest outputs and receipt signatures are excluded from their own digest input to avoid circularity. Mutable export attempts and counters are classified separately; they cannot authorize acknowledgement. Every future column must be classified explicitly.

Canonicalization rules:

- SHA-256 input: UTF-8 bytes of `NI-IMM-DIGEST-v1`, LF, record type, LF, canonical document; **no trailing newline**.
- Objects sort keys by UTF-8 byte order; arrays preserve order.
- Strings retain Unicode without normalization; reject unpaired surrogates.
- Escape quotation marks and backslashes; encode control characters as lowercase `\u00xx`; leave other Unicode characters literal.
- Booleans use JSON `true`/`false`.
- Manifest integer/numeric fields become exact decimal strings: no exponent, leading plus, redundant leading/trailing zeros or negative zero.
- Payload JSON numbers become tagged canonical values, distinguished from payload strings: `{"$number":"<canonical decimal>"}`. To prevent collisions, payload values use a typed tree representation: objects, arrays, strings, numbers, booleans and null each have distinct type tags.
- UUIDs use lowercase canonical strings.
- Timestamps normalize to UTC with exactly six fractional digits; reject excess precision rather than silently round.
- Required nullable columns appear explicitly as null. Missing manifest fields fail validation. Within source payloads, absent keys remain absent and differ from explicit null.
- Duplicate JSON keys are rejected before conversion to JSONB.

Existing `payload_hash` semantics remain preserved and covered. The new integrity digest does not silently replace historical hashes.

Any change to encoding, covered fields or record semantics requires a new digest version. Historical records retain their original version; schema evolution requires explicit manifests, compatibility vectors and a governed checkpoint.

**GOLDEN VECTORS:**

These independently computed SHA-256 vectors fix the framing, key ordering, null handling, array ordering and UTF-8 behavior. Record type is `test`; documents shown are the exact canonical documents.

| Canonical document        | SHA-256                                                            |
| ------------------------- | ------------------------------------------------------------------ |
| `{}`                      | `8abaa3917ed9d3781e7d80b0f0d96cadcdd3084c3b6d4e2b94375553514be6b0` |
| `{"a":null,"b":"1"}`      | `397bfeb180d32ad4a578dcaa5d80c3d08b438ff2da2f3f39dad6c1f46a73b8ac` |
| `{"a":["2","1"],"z":"é"}` | `19f9bd2b85b60bee669d1de3ce721562589c02b623348a424b20d2ec9b72f94b` |

Full record fixtures—including typed payload trees, timestamps, numeric extremes and authorization commitments—remain required before prototype acceptance. These three vectors are not a claim of complete canonicalizer validation.

**QUARANTINE CONTRACT:**

**Approved destination:** Not yet designated. Master must approve a durable restricted quarantine destination and administrator before activation. WS-001 cannot declare an unselected service approved.

Required boundary:

- Separate authorization from observation ingestion.
- Ingestion may submit bounded quarantine entries but cannot read, rewrite, delete or replay them.
- Operators require explicit quarantine permissions; organization membership alone is insufficient.
- Unverified tenant claims never establish tenant access. Foreign or ambiguous entries require independently authorized security operators.
- No customer API, current projection or journey-link writes originate from quarantine.

Permitted contents: original redacted observation, immutable envelope, delivery ID, attempt history, reason code, timestamps, correlation ID and integrity digest. Apply existing prohibited-field validation and size limits before storage.

Prohibited contents: bearer credentials, authorization headers containing secrets, verification digests, connection credentials and unapproved raw/contact data.

A durable receipt must identify destination, entry ID, delivery ID, envelope/payload digest and durable-storage timestamp, with independently verifiable authentication. Queue acknowledgement requires an exact matching receipt. Duplicate submissions are idempotent.

Replay requires an independently approved reconciliation action, current authorization and a linked new delivery attempt. Preserve the original entry and context. If original scope is no longer authorized, replay remains denied; approval does not permit epoch rewriting or tenant retargeting.

Every quarantine admission, access, disposition and replay action requires protected audit evidence. Retention, legal holds and deletion require Master’s named authorities. No period is assumed.

If quarantine is unavailable, retain and park the original queue item, alert operators and retry only quarantine storage within its operational policy. Never acknowledge loss or treat quarantine failure as successful ingestion.

**OPEN OPERATIONAL DECISIONS:**

- Master’s quarantine and audit destination/administrator designations.
- Retention, privacy, deletion and backup authorities.
- Independent integrity-key custody and rotation policy.
- WS-004 approval of envelope, retry schedule and acknowledgement behavior.
- WS-022 approval of the completed encoding, secret commitments and quarantine boundary.

**WS-004 REVIEW READINESS:** Ready for concrete contract review; compatibility is not yet certified.

**WS-022 REVIEW READINESS:** Ready for review of these amendments. Destination approval and telemetry evidence remain activation gates.

**WS-024 TEST READINESS:** Sufficient to prepare the matrix. Full record vectors, selected infrastructure and separate execution authorization remain necessary.

**FINAL WS-001 RATIFICATION:** Conditional design concurrence with the amended artifact. Final joint ratification remains **PARTIAL**; no prototype or release authority is implied.

No implementation, production changes, credential rotation, canary changes, merge, deployment or WS-025 M2 work occurred.

