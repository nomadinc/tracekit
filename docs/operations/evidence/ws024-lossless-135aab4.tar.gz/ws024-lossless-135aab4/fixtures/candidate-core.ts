import { ContractError,parseExact, type ExactValue } from './integrity.ts';
import { envelope,CONTRACT,type Envelope } from './contracts.ts';
import {validateEdgeIntelligenceV1} from '../intelligence-v1-validator.ts';

export type Query = (sql:string,values:unknown[])=>Promise<{rows:Record<string,unknown>[]}>;
export type SecureConnection={query:Query;tlsVerified:true;parameterCaptureDisabled:true;errorCaptureDisabled:true};
export type Outcome={status:number;body:Record<string,unknown>};
/** Unmounted Core handler. Caller supplies a dedicated executor connection, never the service-role REST client. */
export async function deliverCore(request:Request,connection:SecureConnection,configuredEnvironment:string,enabled=false):Promise<Outcome>{
 if(!enabled)return {status:503,body:{ok:false,code:'not_activated'}};
 const correlationId=crypto.randomUUID();let begun=false;
 try{
  if(connection.tlsVerified!==true||connection.parameterCaptureDisabled!==true||connection.errorCaptureDisabled!==true)throw new ContractError('TRANSPORT');
  const authorization=request.headers.get('authorization')??'';
  if(!/^Bearer [!-~]{32,512}$/.test(authorization))return{status:401,body:{ok:false,code:'unauthorized',correlationId}};
  const raw=await request.text();const exact=parseExact(raw);
  if(!exact||typeof exact!=='object'||Array.isArray(exact))throw new ContractError('PAYLOAD');
  const context=envelope(request.headers,(exact as Record<string,ExactValue>).tenantRef);
  if(context.environment!==configuredEnvironment)return{status:403,body:{ok:false,code:'forbidden',correlationId}};
  // JSON.parse is used ONLY for the existing semantic validator. Persistence receives original exact text.
  const validation=validateEdgeIntelligenceV1(JSON.parse(raw));if(!validation.ok)throw new ContractError('PAYLOAD');
  await connection.query('begin',[]);begun=true;
  await connection.query("set local lock_timeout='2s'",[]);
  await connection.query("set local statement_timeout='8s'",[]);
  await connection.query("set local idle_in_transaction_session_timeout='10s'",[]);
  const result=await connection.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text) as result',[authorization.slice(7),context.environment,context.tenantRef,context.bindingEpoch,context.deliveryId,raw]);
  const body=result.rows[0]?.result as Record<string,unknown>;
  if(!body||!['accepted','duplicate','stale'].includes(String(body.outcome))||body.deliveryId!==context.deliveryId||body.observationId!==(exact as any).observationId||String(body.revision)!==String((exact as any).revision))throw new ContractError('RESPONSE');
  await connection.query('commit',[]);begun=false;
  return{status:body.outcome==='accepted'?201:200,body:{ok:true,...body,contract:CONTRACT,correlationId}};
 }catch(error){
  if(begun)await connection.query('rollback',[]).catch(()=>undefined);
  // No raw error, SQL or arguments reach telemetry or the response.
  const code=typeof error==='object'&&error!==null&&'code' in error?String(error.code):'';
  const status=code==='28000'?401:code==='42501'?403:code==='23505'?409:error instanceof ContractError&&['INVALID_JSON','ENVELOPE','PAYLOAD'].includes(code)||code==='22023'?400:503;
  return{status,body:{ok:false,code:status===401?'unauthorized':status===403?'forbidden':status===409?'conflict':status===400?'invalid_delivery':'delivery_unavailable',correlationId}};
 }
}

export type Parked={state:'parked';originalEnvelope:Envelope;payloadDigest:string;attempts:number;firstAttemptAt:string;reason:string};
/** Immutable transition data: storage adapters must durably CAS before acknowledging a queue item. */
export function park(originalEnvelope:Envelope,payloadDigest:string,attempts:number,firstAttemptAt:string,reason:string):Readonly<Parked>{
 if(!Number.isInteger(attempts)||attempts<1||attempts>8||!/^[0-9a-f]{64}$/.test(payloadDigest))throw new ContractError('PARK');
 return Object.freeze({state:'parked',originalEnvelope:Object.freeze({...originalEnvelope}),payloadDigest,attempts,firstAttemptAt,reason});
}
