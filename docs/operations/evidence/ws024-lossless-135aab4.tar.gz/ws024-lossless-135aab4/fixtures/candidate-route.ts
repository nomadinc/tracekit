import {createHash,timingSafeEqual} from 'node:crypto';
import {deliverCore,type SecureConnection} from './core.ts';
import {CONTRACT} from './contracts.ts';
export type RouteDependencies={enabled:boolean;environment:string;open:()=>Promise<SecureConnection & {dispose():Promise<void>}>;authenticateUnversioned:(bearer:string)=>Promise<boolean>;log:(category:string,fields:{code:string;correlationId:string})=>void};
const json=(body:Record<string,unknown>,status:number)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
/** No proof-free write fallback exists. */
export function createModelBRoute(dependencies:RouteDependencies){
 return async(request:Request):Promise<Response>=>{
  const auth=request.headers.get('authorization')??'';
  if(!/^Bearer [!-~]{32,512}$/.test(auth))return json({ok:false,code:'unauthorized'},401);
  let connection:Awaited<ReturnType<RouteDependencies['open']>>|undefined;
  try{
   if(!request.headers.has('TraceKit-Authorization-Contract')){
    // Authentication only: a valid old-format bearer never confers tenant scope.
    if(!await dependencies.authenticateUnversioned(auth.slice(7)))return json({ok:false,code:'unauthorized'},401);
    return json({ok:false,code:'forbidden'},403);
   }
   if(!dependencies.enabled)return json({ok:false,code:'delivery_unavailable'},503);
   if(request.headers.get('TraceKit-Authorization-Contract')!==CONTRACT)return json({ok:false,code:'invalid_delivery'},400);
   connection=await dependencies.open();const result=await deliverCore(request,connection,dependencies.environment,true);
   return json(result.body,result.status);
  }catch{
   dependencies.log('edge_intelligence_v1_delivery_failed',{code:'delivery_unavailable',correlationId:crypto.randomUUID()});
   return json({ok:false,code:'delivery_unavailable'},503);
  }finally{await connection?.dispose().catch(()=>undefined);}
 };
}
export async function authenticateUnversioned(token:string):Promise<boolean>{
 const base=process.env.NEXT_PUBLIC_SUPABASE_URL?.replace(/\/$/,''),key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!base||!key)throw new Error('unavailable');
 const hash=createHash('sha256').update(token).digest('hex');
 const result=await fetch(base+'/rest/v1/edge_intelligence_service_credentials?token_hash=eq.'+hash+'&status=eq.active&select=id,token_hash&limit=2',{cache:'no-store',headers:{apikey:key,Authorization:'Bearer '+key}});
 if(!result.ok)throw new Error('unavailable');const rows=await result.json();
 return Array.isArray(rows)&&rows.length===1&&typeof rows[0]?.token_hash==='string'&&/^[0-9a-f]{64}$/.test(rows[0].token_hash)&&timingSafeEqual(Buffer.from(rows[0].token_hash),Buffer.from(hash));
}
