# WS-001 lossless native timestamp assertion correction

Base: e8d2252637945bb5eea685566585320d376a7c3b.
Scope: test/handoff only; no runtime, prepared SQL or contract changes.

WS-022 accepted the scoped NI-DB-002 correction at the base candidate: the original 32-case helper conformance defect is closed, and tested implemented boundaries are accepted. Full persistence acceptance remains PARTIAL. This records the supplied owner decision; WS-001 does not claim to have independently rerun WS-024's native evidence.

Preserved historical result: WS-024 reported 53 PASS / 1 FAIL. The failure was the test's conversion of PostgreSQL microseconds through JavaScript Date. That result is not rewritten as passing; original evidence remains at its published location. A separate owner-reported lossless check matched all three observation digests.

The regression now selects complete observation record JSON as PostgreSQL text, parses it with parseExact, normalizes the manifest timestamps, and recomputes all three retained observation digests. No PostgreSQL timestamp passes through JS Date; exact JSON numbers also avoid the driver's lossy JSON decoding. A separate database roundtrip exercises microseconds 000001, 123456 and 999999 and verifies that Date would lose precision. The frozen digest vectors and 32 negative expectations remain unchanged.

Local results: focused security 142 PASS / 0 FAIL / 0 SKIP; WS-023 copies 11 PASS / 0 FAIL / 0 SKIP; focused TypeScript PASS. These are PGlite/local results, not native certification. WS-024 must rerun the corrected assertion under native PostgreSQL before reporting an all-pass native suite.

NI-DB-001 stays OPEN: the literal-query timeout behavior is not resolved by a later parameterized-query pass. NI-CRYPTO-001 remains OPEN. Missing provisioning, receipt, quarantine, export and complete S4 outbox/audit-stream writers remain activation blockers. Every newly implemented writer still requires authoritative-path rejection, role-denial and atomic rollback tests.

No production changes, schema/grant mutations, rotations, canary changes, merge, deployment or customer activation. Versioned production writes remain disabled. Production V1 HOLD.
