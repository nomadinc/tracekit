import { ContractError, ExactNumber, normalizeTimestamp, PROFILE, type ExactValue } from './integrity.ts';
const invalid=():never=>{throw new ContractError('MANIFEST');};
export function normalizeRecord(name:string,input:Record<string,ExactValue>):Record<string,ExactValue>{
 const fields=MANIFESTS[name];if(!fields||Object.keys(input).length!==Object.keys(fields).length)invalid();
 const out:Record<string,ExactValue>={};
 for(const [key,spec] of Object.entries(fields)){
  if(!Object.hasOwn(input,key))invalid();const v=input[key],nullable=spec.endsWith('?'),type=spec.replace(/\?$/,'');
  if(v===null){if(!nullable)invalid();out[key]=null;continue;}
  if(type==='J'){out[key]=v;continue;}
  if(['I','Q','V'].includes(type)){
   let n:string;try{n=v instanceof ExactNumber?v.decimal:typeof v==='bigint'?String(v):typeof v==='number'&&Number.isSafeInteger(v)?String(v):invalid();}catch{return invalid();}
   if(!/^\d+$/.test(n))invalid();const b=BigInt(n),max=type==='Q'?BigInt('9223372036854775807'):BigInt('2147483647');if(b>(max)||b<(type==='V'?BigInt(1):BigInt(0)))invalid();out[key]=new ExactNumber(n);continue;
  }
  if(type==='B'){if(typeof v!=='boolean')invalid();out[key]=v;continue;}
  if(typeof v!=='string'||v.includes('\u0000'))return invalid();
  const patterns:Record<string,RegExp>={U:/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/,E:/^[a-z][a-z0-9_-]{0,31}$/,T:/^tenant_[A-Za-z0-9_-]{8,128}$/,H:/^[0-9a-f]{64}$/,K:/^[a-z][a-z0-9_-]{0,62}$/,SIG:/^[0-9a-f]{128}$/};
  if(patterns[type]&&!patterns[type].test(v))invalid();out[key]=type==='TS'?normalizeTimestamp(v):v;
 }
 if('digest_version' in fields&&out.digest_version!==PROFILE)invalid();return out;
}
export const MANIFESTS:Record<string,Record<string,string>> = {
  "observation": {
    "id": "U",
    "organization_id": "U",
    "tenant_ref": "T",
    "observation_id": "S",
    "revision": "V",
    "previous_revision": "V?",
    "schema_version": "S",
    "semantics_version": "S",
    "derivation_rule_version": "S",
    "session_ref": "S",
    "event_ref": "S?",
    "observed_at": "TS",
    "updated_at_source": "TS",
    "completed_at_source": "TS?",
    "status": "S",
    "payload": "J",
    "payload_hash": "H",
    "received_at": "TS",
    "environment": "E",
    "binding_epoch": "U",
    "credential_id": "U",
    "grant_id": "U",
    "delivery_id": "U",
    "digest_version": "S"
  },
  "current_projection": {
    "organization_id": "U",
    "tenant_ref": "T",
    "observation_id": "S",
    "observation_row_id": "U",
    "revision": "V",
    "updated_at": "TS",
    "audit_event_id": "U",
    "digest_version": "S"
  },
  "journey_link": {
    "id": "U",
    "organization_id": "U",
    "observation_row_id": "U",
    "journey_id": "U?",
    "linkage_basis": "S",
    "linkage_evidence": "J",
    "created_at": "TS",
    "updated_at": "TS",
    "audit_event_id": "U",
    "digest_version": "S"
  },
  "credential_authorization": {
    "id": "U",
    "status": "S",
    "label": "S",
    "created_at": "TS",
    "last_used_at": "TS?",
    "revoked_at": "TS?",
    "verifier_algorithm": "S",
    "verifier_commitment": "H",
    "commitment_key_id": "K",
    "commitment_key_version": "V",
    "digest_version": "S"
  },
  "tenant_binding": {
    "tenant_ref": "T",
    "organization_id": "U",
    "status": "S",
    "created_at": "TS",
    "updated_at": "TS",
    "environment": "E",
    "binding_epoch": "U",
    "approval_ref": "S",
    "approved_by": "S",
    "digest_version": "S"
  },
  "credential_grant": {
    "id": "U",
    "credential_id": "U",
    "environment": "E",
    "tenant_ref": "T",
    "organization_id": "U",
    "binding_epoch": "U",
    "status": "S",
    "valid_from": "TS",
    "expires_at": "TS?",
    "approval_ref": "S",
    "approved_by": "S",
    "created_at": "TS",
    "revoked_at": "TS?",
    "revoked_by": "S?",
    "revocation_reason": "S?",
    "digest_version": "S"
  },
  "authorization_audit": {
    "id": "U",
    "stream_id": "U",
    "sequence": "Q",
    "previous_digest": "H",
    "event_type": "S",
    "record_type": "S",
    "record_key": "J",
    "before_state": "J?",
    "after_state": "J?",
    "before_digest": "H?",
    "after_digest": "H?",
    "actor_ref": "S",
    "approval_ref": "S",
    "reason": "S",
    "occurred_at": "TS",
    "correlation_id": "U",
    "digest_version": "S"
  },
  "observation_audit": {
    "id": "U",
    "stream_id": "U",
    "sequence": "Q",
    "previous_digest": "H",
    "event_type": "S",
    "record_type": "S",
    "record_key": "J",
    "before_digest": "H?",
    "after_digest": "H?",
    "authorization_context": "J",
    "before_projection": "J?",
    "after_projection": "J?",
    "before_link": "J?",
    "after_link": "J?",
    "outcome": "S",
    "occurred_at": "TS",
    "correlation_id": "U",
    "digest_version": "S"
  },
  "protected_outbox": {
    "event_id": "U",
    "destination_id": "S",
    "stream_id": "U",
    "sequence": "Q",
    "event_digest": "H",
    "created_at": "TS",
    "digest_version": "S"
  },
  "independent_receipt": {
    "receipt_version": "S",
    "receipt_id": "U",
    "receipt_kind": "S",
    "contract_version": "S",
    "environment": "E",
    "destination_id": "S",
    "stream_id": "U",
    "sequence": "Q",
    "event_digest": "H",
    "previous_receipt_digest": "H",
    "durable_at": "TS",
    "key_id": "K",
    "key_version": "V",
    "signature": "SIG"
  },
  "source_evidence": {
    "environment": "E",
    "organization_id": "U",
    "tenant_ref": "T",
    "binding_epoch": "U",
    "observation_id": "S",
    "revision": "V",
    "previous_revision": "V?",
    "schema_version": "S",
    "semantics_version": "S",
    "derivation_rule_version": "S",
    "session_ref": "S",
    "event_ref": "S?",
    "observed_at": "TS",
    "updated_at_source": "TS",
    "completed_at_source": "TS?",
    "status": "S",
    "payload": "J",
    "digest_version": "S"
  },
  "credential_commitment": {
    "credential_id": "U",
    "verifier_algorithm": "S",
    "verifier_hex": "H",
    "key_id": "K",
    "key_version": "V",
    "digest_version": "S"
  },
  "quarantine_receipt": {
    "receipt_version": "S",
    "receipt_id": "U",
    "destination_id": "S",
    "environment": "E",
    "entry_id": "U",
    "delivery_id": "U",
    "envelope_digest": "H",
    "payload_digest": "H",
    "durable_at": "TS",
    "key_id": "K",
    "key_version": "V",
    "signature": "SIG"
  },
  "audit_stream_state": {
    "stream_id": "U",
    "last_sequence": "Q",
    "last_event_digest": "H",
    "updated_at": "TS",
    "digest_version": "S"
  },
  "export_state": {
    "destination_id": "S",
    "stream_id": "U",
    "acknowledged_sequence": "Q",
    "acknowledged_event_digest": "H",
    "last_receipt_digest": "H",
    "last_checkpoint_at": "TS?",
    "attempt_count": "Q",
    "next_attempt_at": "TS?",
    "last_error_code": "S?",
    "updated_at": "TS",
    "digest_version": "S"
  },
  "delivery_envelope": {
    "TraceKit-Authorization-Contract": "S",
    "TraceKit-Environment": "E",
    "TraceKit-Tenant-Ref": "T",
    "TraceKit-Binding-Epoch": "U",
    "TraceKit-Delivery-Id": "U"
  }
};
