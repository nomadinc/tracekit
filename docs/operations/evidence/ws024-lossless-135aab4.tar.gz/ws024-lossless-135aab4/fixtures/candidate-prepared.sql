-- PROPOSED ENFORCEMENT PATH. Disposable validation only; NOT in migrations.
-- No existing HTTP route invokes this path. No production grants are changed by development.
begin;
create role ni_integrity_writer nologin nobypassrls nosuperuser nocreatedb nocreaterole;
create role ni_controller_writer nologin nobypassrls nosuperuser nocreatedb nocreaterole;
create role ni_delivery_executor nologin nobypassrls nosuperuser nocreatedb nocreaterole;
create role ni_authorization_controller nologin nobypassrls nosuperuser nocreatedb nocreaterole;
create schema ni_security;
revoke all on schema ni_security from public;
grant usage on schema ni_security to ni_integrity_writer,ni_controller_writer,ni_delivery_executor,ni_authorization_controller;
grant usage on schema public to ni_integrity_writer,ni_controller_writer;

alter table public.edge_intelligence_tenant_bindings add column environment text, add column binding_epoch uuid,add column approval_ref text,add column approved_by text;
alter table public.edge_intelligence_observations
 add column environment text,add column binding_epoch uuid,add column credential_id uuid,
 add column grant_id uuid,add column delivery_id uuid,add column digest_version text,
 add column source_digest text,add column record_digest text;
alter table public.edge_intelligence_observations add constraint ni_observation_scoped_id unique(organization_id,tenant_ref,observation_id,revision,id);
alter table public.edge_intelligence_current add constraint ni_current_scope foreign key(organization_id,tenant_ref,observation_id,revision,observation_row_id)
 references public.edge_intelligence_observations(organization_id,tenant_ref,observation_id,revision,id);
alter table public.edge_intelligence_observations add constraint ni_observation_org_id unique(organization_id,id);
alter table public.edge_intelligence_journey_links add constraint ni_link_scope foreign key(organization_id,observation_row_id)
 references public.edge_intelligence_observations(organization_id,id);

alter table public.edge_intelligence_current add column audit_event_id uuid,add column digest_version text;
alter table public.edge_intelligence_journey_links add column updated_at timestamptz,add column audit_event_id uuid,add column digest_version text;
create table ni_security.grants(
 id uuid primary key,credential_id uuid not null references public.edge_intelligence_service_credentials(id) on delete restrict,
 environment text not null check(environment~'^[a-z][a-z0-9_-]{0,31}$'),tenant_ref text not null,
 organization_id uuid not null references public.tracekit_organizations(id) on delete restrict,binding_epoch uuid not null,
 status text not null check(status in('active','revoked')),valid_from timestamptz not null,expires_at timestamptz,
 approval_ref text not null check(length(approval_ref)>0),approved_by text not null check(length(approved_by)>0),
 created_at timestamptz not null default clock_timestamp(),revoked_at timestamptz,revoked_by text,revocation_reason text,digest_version text not null default 'NI-IMM-DIGEST-v1/typed-tree-1',
 check(expires_at is null or expires_at>valid_from)
);
create unique index ni_grants_unambiguous on ni_security.grants(credential_id,environment,tenant_ref) where status='active';
create table ni_security.audit_streams(id uuid primary key,last_sequence bigint not null default 0,last_digest text not null default repeat('0',64));
create table ni_security.audit_events(id uuid primary key,stream_id uuid not null references ni_security.audit_streams(id),sequence bigint not null,
 previous_digest text not null,body jsonb not null,record_digest text not null,unique(stream_id,sequence));
create table ni_security.outbox(event_id uuid primary key references ni_security.audit_events(id) on delete restrict,stream_id uuid not null,sequence bigint not null,event_digest text not null,created_at timestamptz not null default clock_timestamp());
create table ni_security.admission(environment text primary key,stream_id uuid not null references ni_security.audit_streams(id),
 checkpoint_at timestamptz,reconciled boolean not null default false);
create table ni_security.deliveries(environment text not null,delivery_id uuid not null,tenant_ref text not null,binding_epoch uuid not null,source_digest text not null,observation_row_id uuid not null references public.edge_intelligence_observations(id) on delete restrict,primary key(environment,delivery_id));
-- Restricted durable parking metadata. Not an alternate observation/payload store.
create table ni_security.parked_deliveries(id uuid primary key,original_envelope jsonb not null,payload_digest text not null check(payload_digest~'^[0-9a-f]{64}$'),
 attempts integer not null check(attempts between 1 and 8),first_attempt_at timestamptz not null,reason text not null,created_at timestamptz not null default clock_timestamp());
alter table ni_security.parked_deliveries enable row level security;
-- No ingestion/exporter/customer grants. Independent queue integration remains unprovisioned.

-- Every accepted source table is owner-independent from runtime roles. RLS is explicit.
alter table ni_security.grants enable row level security;
alter table ni_security.audit_streams enable row level security;
alter table ni_security.audit_events enable row level security;
alter table ni_security.outbox enable row level security;
alter table ni_security.admission enable row level security;
alter table ni_security.deliveries enable row level security;
grant select on public.edge_intelligence_service_credentials,public.edge_intelligence_tenant_bindings,ni_security.grants to ni_integrity_writer;
grant select,insert on public.edge_intelligence_observations,ni_security.audit_events,ni_security.outbox,ni_security.deliveries to ni_integrity_writer;
grant select,insert,update on public.edge_intelligence_current,ni_security.audit_streams to ni_integrity_writer;
grant select on ni_security.admission to ni_integrity_writer;
grant select,insert on public.edge_intelligence_journey_links to ni_integrity_writer;
create policy ni_cred_read on public.edge_intelligence_service_credentials for select to ni_integrity_writer,ni_controller_writer using(true);
create policy ni_binding_read on public.edge_intelligence_tenant_bindings for select to ni_integrity_writer,ni_controller_writer using(true);
create policy ni_obs_read on public.edge_intelligence_observations for select to ni_integrity_writer using(true);
create policy ni_obs_insert on public.edge_intelligence_observations for insert to ni_integrity_writer with check(true);
create policy ni_current_read on public.edge_intelligence_current for select to ni_integrity_writer using(true);
create policy ni_current_insert on public.edge_intelligence_current for insert to ni_integrity_writer with check(true);
create policy ni_current_update on public.edge_intelligence_current for update to ni_integrity_writer using(true) with check(true);
create policy ni_link_read on public.edge_intelligence_journey_links for select to ni_integrity_writer using(true);
create policy ni_link_insert on public.edge_intelligence_journey_links for insert to ni_integrity_writer with check(journey_id is null and linkage_basis='unresolved');
create policy ni_grants_read on ni_security.grants for select to ni_integrity_writer,ni_controller_writer using(true);
create policy ni_stream_access on ni_security.audit_streams to ni_integrity_writer using(true) with check(true);
create policy ni_audit_access on ni_security.audit_events to ni_integrity_writer using(true) with check(true);
create policy ni_outbox_access on ni_security.outbox to ni_integrity_writer using(true) with check(true);
create policy ni_admission_read on ni_security.admission for select to ni_integrity_writer using(true);
create policy ni_delivery_access on ni_security.deliveries to ni_integrity_writer using(true) with check(true);

create function ni_security.immutable_guard() returns trigger language plpgsql set search_path='' as $$
begin raise exception using errcode='42501',message='historical_mutation_denied';end $$;
create trigger ni_obs_immutable before update or delete on public.edge_intelligence_observations for each row execute function ni_security.immutable_guard();
create trigger ni_obs_truncate before truncate on public.edge_intelligence_observations for each statement execute function ni_security.immutable_guard();
create trigger ni_audit_immutable before update or delete on ni_security.audit_events for each row execute function ni_security.immutable_guard();
create trigger ni_audit_truncate before truncate on ni_security.audit_events for each statement execute function ni_security.immutable_guard();
create trigger ni_outbox_immutable before update or delete on ni_security.outbox for each row execute function ni_security.immutable_guard();
create trigger ni_outbox_truncate before truncate on ni_security.outbox for each statement execute function ni_security.immutable_guard();
create trigger ni_parking_immutable before update or delete on ni_security.parked_deliveries for each row execute function ni_security.immutable_guard();
create trigger ni_parking_truncate before truncate on ni_security.parked_deliveries for each statement execute function ni_security.immutable_guard();
create function ni_security.unresolved_only() returns trigger language plpgsql set search_path='' as $$
begin if new.journey_id is not null then raise exception using errcode='42501',message='journey_authority_unavailable';end if;return new;end $$;
create trigger ni_unresolved_only before insert or update on public.edge_intelligence_journey_links for each row execute function ni_security.unresolved_only();

-- Disabled deletion also catches organization cascades. No GUC/role-based escape hatch.
revoke insert,update,delete,truncate on public.edge_intelligence_observations,public.edge_intelligence_current,public.edge_intelligence_journey_links,
 public.edge_intelligence_service_credentials,public.edge_intelligence_tenant_bindings from service_role;
revoke execute on function public.ingest_edge_intelligence_v1(uuid,jsonb) from service_role,public;

-- Exact typed-tree implementation over PostgreSQL exact-decimal JSONB.
create function ni_security.quote(p text) returns text language plpgsql immutable strict set search_path='' as $$
declare r text='"';c text;n integer;
begin for i in 1..length(p) loop c=substr(p,i,1);n=ascii(c);
 if n=34 then r=r||E'\\"';elsif n=92 then r=r||E'\\\\';elsif n<32 then r=r||E'\\u'||lpad(to_hex(n),4,'0');else r=r||c;end if;
end loop;return r||'"';end $$;
create function ni_security.canonical(p jsonb) returns text language plpgsql immutable strict set search_path='' as $$
declare k text;v jsonb;r text;n text;t text=jsonb_typeof(p);
begin
 if t='null' then return '["z"]';elsif t='boolean' then return '["b",'||p::text||']';
 elsif t='string' then return '["s",'||ni_security.quote(p#>>'{}')||']';
 elsif t='number' then n=p::text;if position('.' in n)>0 then n=rtrim(rtrim(n,'0'),'.');end if;if n::numeric=0 then n='0';end if;if length(n)>4096 then raise exception 'number_limit';end if;return '["n",'||ni_security.quote(n)||']';
 elsif t='array' then select string_agg(ni_security.canonical(value),',' order by ordinality) into r from jsonb_array_elements(p) with ordinality;return '["a",['||coalesce(r,'')||']]';
 elsif t='object' then r='';for k,v in select key,value from jsonb_each(p) order by convert_to(key,'UTF8') loop if r<>'' then r=r||',';end if;r=r||'['||ni_security.quote(k)||','||ni_security.canonical(v)||']';end loop;return '["o",['||r||']]';end if;
 raise exception 'type';end $$;
-- Exact S4 record validation precedes digest framing. Generic typed-tree encoding alone is insufficient.
create function ni_security.record_value(p_type text,p jsonb) returns jsonb language plpgsql immutable set search_path='' as $$
declare manifests constant jsonb='{"observation":{"id":"U","organization_id":"U","tenant_ref":"T","observation_id":"S","revision":"V","previous_revision":"V?","schema_version":"S","semantics_version":"S","derivation_rule_version":"S","session_ref":"S","event_ref":"S?","observed_at":"TS","updated_at_source":"TS","completed_at_source":"TS?","status":"S","payload":"J","payload_hash":"H","received_at":"TS","environment":"E","binding_epoch":"U","credential_id":"U","grant_id":"U","delivery_id":"U","digest_version":"S"},"current_projection":{"organization_id":"U","tenant_ref":"T","observation_id":"S","observation_row_id":"U","revision":"V","updated_at":"TS","audit_event_id":"U","digest_version":"S"},"journey_link":{"id":"U","organization_id":"U","observation_row_id":"U","journey_id":"U?","linkage_basis":"S","linkage_evidence":"J","created_at":"TS","updated_at":"TS","audit_event_id":"U","digest_version":"S"},"credential_authorization":{"id":"U","status":"S","label":"S","created_at":"TS","last_used_at":"TS?","revoked_at":"TS?","verifier_algorithm":"S","verifier_commitment":"H","commitment_key_id":"K","commitment_key_version":"V","digest_version":"S"},"tenant_binding":{"tenant_ref":"T","organization_id":"U","status":"S","created_at":"TS","updated_at":"TS","environment":"E","binding_epoch":"U","approval_ref":"S","approved_by":"S","digest_version":"S"},"credential_grant":{"id":"U","credential_id":"U","environment":"E","tenant_ref":"T","organization_id":"U","binding_epoch":"U","status":"S","valid_from":"TS","expires_at":"TS?","approval_ref":"S","approved_by":"S","created_at":"TS","revoked_at":"TS?","revoked_by":"S?","revocation_reason":"S?","digest_version":"S"},"authorization_audit":{"id":"U","stream_id":"U","sequence":"Q","previous_digest":"H","event_type":"S","record_type":"S","record_key":"J","before_state":"J?","after_state":"J?","before_digest":"H?","after_digest":"H?","actor_ref":"S","approval_ref":"S","reason":"S","occurred_at":"TS","correlation_id":"U","digest_version":"S"},"observation_audit":{"id":"U","stream_id":"U","sequence":"Q","previous_digest":"H","event_type":"S","record_type":"S","record_key":"J","before_digest":"H?","after_digest":"H?","authorization_context":"J","before_projection":"J?","after_projection":"J?","before_link":"J?","after_link":"J?","outcome":"S","occurred_at":"TS","correlation_id":"U","digest_version":"S"},"protected_outbox":{"event_id":"U","destination_id":"S","stream_id":"U","sequence":"Q","event_digest":"H","created_at":"TS","digest_version":"S"},"independent_receipt":{"receipt_version":"S","receipt_id":"U","receipt_kind":"S","contract_version":"S","environment":"E","destination_id":"S","stream_id":"U","sequence":"Q","event_digest":"H","previous_receipt_digest":"H","durable_at":"TS","key_id":"K","key_version":"V","signature":"SIG"},"source_evidence":{"environment":"E","organization_id":"U","tenant_ref":"T","binding_epoch":"U","observation_id":"S","revision":"V","previous_revision":"V?","schema_version":"S","semantics_version":"S","derivation_rule_version":"S","session_ref":"S","event_ref":"S?","observed_at":"TS","updated_at_source":"TS","completed_at_source":"TS?","status":"S","payload":"J","digest_version":"S"},"credential_commitment":{"credential_id":"U","verifier_algorithm":"S","verifier_hex":"H","key_id":"K","key_version":"V","digest_version":"S"},"quarantine_receipt":{"receipt_version":"S","receipt_id":"U","destination_id":"S","environment":"E","entry_id":"U","delivery_id":"U","envelope_digest":"H","payload_digest":"H","durable_at":"TS","key_id":"K","key_version":"V","signature":"SIG"},"audit_stream_state":{"stream_id":"U","last_sequence":"Q","last_event_digest":"H","updated_at":"TS","digest_version":"S"},"export_state":{"destination_id":"S","stream_id":"U","acknowledged_sequence":"Q","acknowledged_event_digest":"H","last_receipt_digest":"H","last_checkpoint_at":"TS?","attempt_count":"Q","next_attempt_at":"TS?","last_error_code":"S?","updated_at":"TS","digest_version":"S"},"delivery_envelope":{"TraceKit-Authorization-Contract":"S","TraceKit-Environment":"E","TraceKit-Tenant-Ref":"T","TraceKit-Binding-Epoch":"U","TraceKit-Delivery-Id":"U"}}'::jsonb;fields jsonb;result jsonb=p;k text;spec text;t text;v jsonb;n numeric;pattern text;
begin
 fields=manifests->p_type;
 if fields is null then
 if p_type in ('encoding_test','timestamp_test','quarantine_payload') and p is not null then return p;end if;
 raise exception using errcode='22023',message='invalid_record';end if;
 if p is null or jsonb_typeof(p)<>'object' then raise exception using errcode='22023',message='invalid_record';end if;
 if (select count(*) from jsonb_object_keys(p))<>(select count(*) from jsonb_object_keys(fields)) or exists(select 1 from jsonb_object_keys(p) key where not fields?key) then raise exception using errcode='22023',message='invalid_record';end if;
 for k,spec in select key,value#>>'{}' from jsonb_each(fields) loop
 if not p?k then raise exception using errcode='22023',message='invalid_record';end if;
 v=p->k;t=rtrim(spec,'?');
 if v='null'::jsonb then
 if right(spec,1)<>'?' then raise exception using errcode='22023',message='invalid_record';end if;continue;end if;
 if t='J' then continue;end if;
 if t in ('I','Q','V') then
 if jsonb_typeof(v)<>'number' then raise exception using errcode='22023',message='invalid_record';end if;
 n=(v#>>'{}')::numeric;
 if n<>trunc(n) or n<(case when t='V' then 1 else 0 end) or n>(case when t='Q' then 9223372036854775807::numeric else 2147483647::numeric end) then raise exception using errcode='22023',message='invalid_record';end if;continue;end if;
 if t='B' then if jsonb_typeof(v)<>'boolean' then raise exception using errcode='22023',message='invalid_record';end if;continue;end if;
 if jsonb_typeof(v)<>'string' then raise exception using errcode='22023',message='invalid_record';end if;
 pattern=case t when 'U' then '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' when 'E' then '^[a-z][a-z0-9_-]{0,31}$' when 'T' then '^tenant_[A-Za-z0-9_-]{8,128}$' when 'H' then '^[0-9a-f]{64}$' when 'K' then '^[a-z][a-z0-9_-]{0,62}$' when 'SIG' then '^[0-9a-f]{128}$' else null end;
 if pattern is not null and (v#>>'{}')!~pattern then raise exception using errcode='22023',message='invalid_record';end if;
 if t='TS' then result=jsonb_set(result,array[k],to_jsonb(ni_security.timestamp_text(v#>>'{}')));end if;
 end loop;
 if fields?'digest_version' and result->>'digest_version'<>'NI-IMM-DIGEST-v1/typed-tree-1' then raise exception using errcode='22023',message='invalid_record';end if;
 if p_type='authorization_audit' then
 if result->>'record_type' not in ('credential_authorization','tenant_binding','credential_grant') then raise exception using errcode='22023',message='invalid_record';end if;
 foreach k in array array['before_state','after_state'] loop
 if result->k<>'null'::jsonb then result=jsonb_set(result,array[k],ni_security.record_value(result->>'record_type',result->k));end if;end loop;
 elsif p_type='observation_audit' then
 foreach k in array array['before_projection','after_projection','before_link','after_link'] loop
 if result->k<>'null'::jsonb then result=jsonb_set(result,array[k],ni_security.record_value(case when k like '%projection' then 'current_projection' else 'journey_link' end,result->k));end if;end loop;
 end if;
 return result;
exception when datetime_field_overflow or invalid_datetime_format then raise exception using errcode='22023',message='invalid_record';
end $$;
create function ni_security.digest(p_type text,p jsonb) returns text language sql immutable set search_path='' as $$
 select encode(sha256(convert_to('NI-IMM-DIGEST-v1'||chr(10)||p_type||chr(10)||ni_security.canonical(ni_security.record_value(p_type,p)),'UTF8')),'hex') $$;
-- S4 timestamp grammar; parse components before conversion to avoid rounding or normalization.
create function ni_security.timestamp_text(p text) returns text language plpgsql immutable set search_path='' as $$
declare m text[];y int;mo int;d int;h int;mi int;sec int;oh int;om int;v timestamp;offset_minutes int=0;
begin
 m=regexp_match(p,'^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,6}))?(Z|[+-][0-9]{2}:[0-9]{2})$');
 if m is null then raise exception using errcode='22023',message='invalid_timestamp';end if;
 y=m[1]::int;mo=m[2]::int;d=m[3]::int;h=m[4]::int;mi=m[5]::int;sec=m[6]::int;
 if y<1 or h>23 or mi>59 or sec>59 then raise exception using errcode='22023',message='invalid_timestamp';end if;
 if m[8]<>'Z' then oh=substr(m[8],2,2)::int;om=substr(m[8],5,2)::int;
 if oh>14 or om>59 or (oh=14 and om<>0) then raise exception using errcode='22023',message='invalid_timestamp';end if;
 offset_minutes=(oh*60+om)*case when left(m[8],1)='-' then -1 else 1 end;end if;
 v=make_timestamp(y,mo,d,h,mi,sec)+rpad(coalesce(m[7],''),6,'0')::int*interval '1 microsecond'-offset_minutes*interval '1 minute';
 if extract(year from v)<1 or extract(year from v)>9999 then raise exception using errcode='22023',message='invalid_timestamp';end if;
 return to_char(v,'YYYY-MM-DD"T"HH24:MI:SS.US"Z"');
end $$;
create function ni_security.normalize_state(p jsonb) returns jsonb language plpgsql immutable set search_path='' as $$
declare r jsonb=p;k text;
begin if p is null or p='null'::jsonb then return null;end if;
 foreach k in array array['created_at','updated_at','valid_from','expires_at','revoked_at','received_at','observed_at','updated_at_source','completed_at_source'] loop
 if r?k and r->>k is not null then if jsonb_typeof(r->k)<>'string' then raise exception using errcode='22023',message='invalid_timestamp';end if;r=jsonb_set(r,array[k],to_jsonb(ni_security.timestamp_text(r->>k)));end if;end loop;return r||jsonb_build_object('digest_version','NI-IMM-DIGEST-v1/typed-tree-1');end $$;
create function ni_security.audit(p_stream uuid,p_body jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare s ni_security.audit_streams%rowtype;e uuid=coalesce((p_body->>'id')::uuid,gen_random_uuid());b jsonb;h text;rt text;before_state jsonb;after_state jsonb;
begin
 select * into strict s from ni_security.audit_streams where id=p_stream for update;
 if p_body->>'event_type' in('grant_created','grant_revoked','binding_disabled') then
 rt=case when p_body->>'event_type'='binding_disabled' then 'tenant_binding' else 'credential_grant' end;
 before_state=ni_security.normalize_state(p_body->'before');after_state=ni_security.normalize_state(p_body->'after');
 b=jsonb_build_object('event_type',p_body->>'event_type','record_type',rt,'record_key',case when rt='credential_grant' then jsonb_build_object('id',p_body->'grant_id') else jsonb_build_object('tenant_ref',p_body->'tenant_ref') end,
 'before_state',before_state,'after_state',after_state,'before_digest',case when before_state is not null then ni_security.digest(rt,before_state) end,'after_digest',case when after_state is not null then ni_security.digest(rt,after_state) end,
 'actor_ref',p_body->>'actor','approval_ref',coalesce(p_body->>'approval_ref',after_state->>'approval_ref',before_state->>'approval_ref'),'reason',coalesce(p_body->>'reason','approved_grant_creation'));
 else
 b=jsonb_build_object('event_type',p_body->>'event_type','record_type',p_body->>'record_type','record_key',p_body->'record_key','before_digest',p_body->'before_digest','after_digest',p_body->'after_digest',
 'authorization_context',p_body->'authorization_context','before_projection',p_body->'before_projection','after_projection',p_body->'after_projection','before_link',p_body->'before_link','after_link',p_body->'after_link','outcome',p_body->>'outcome');
 end if;
 b=b||jsonb_build_object('id',e,'stream_id',p_stream,'sequence',s.last_sequence+1,'previous_digest',s.last_digest,'occurred_at',to_char(clock_timestamp() at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'correlation_id',gen_random_uuid(),'digest_version','NI-IMM-DIGEST-v1/typed-tree-1');
 h=ni_security.digest(case when b?'actor_ref' then 'authorization_audit' else 'observation_audit' end,b);
 insert into ni_security.audit_events values(e,p_stream,s.last_sequence+1,s.last_digest,b,h);
 insert into ni_security.outbox(event_id,stream_id,sequence,event_digest) values(e,p_stream,s.last_sequence+1,h);
 update ni_security.audit_streams set last_sequence=s.last_sequence+1,last_digest=h where id=p_stream;
 return e;
end $$;
alter function ni_security.audit(uuid,jsonb) owner to ni_integrity_writer;
revoke all on function ni_security.audit(uuid,jsonb) from public;

create function ni_security.raw_json_valid(p_raw text) returns boolean language plpgsql immutable set search_path='' as $$
declare node record;token text;
begin
 if p_raw is null or octet_length(p_raw)>1048576 then return false;end if;
 for node in with recursive nodes(v,d) as(select p_raw::json,0 union all select child,n.d+1 from nodes n cross join lateral(select value child from json_each(case when json_typeof(n.v)='object' then n.v else '{}'::json end) union all select value from json_array_elements(case when json_typeof(n.v)='array' then n.v else '[]'::json end)) c where n.d<65) select * from nodes loop
 if node.d>64 then return false;end if;
 if json_typeof(node.v)='object' and (select count(*)<>count(distinct key) from json_each(node.v)) then return false;end if;
 if json_typeof(node.v)='number' then token=node.v::text;if length(token)>4096 or coalesce(abs(substring(token from '[eE]([+-]?[0-9]+)$')::numeric),0)>4096 then return false;end if;end if;
 end loop;perform ni_security.canonical(p_raw::jsonb);return true;exception when others then return false;end $$;
create function ni_security.payload_valid(p jsonb) returns boolean language plpgsql immutable set search_path='' as $$
declare e jsonb;a jsonb;item record;ids text[];txt text=p::text;
begin
 if jsonb_typeof(p)<>'object' or p->>'schemaVersion' is distinct from '1.0' or not(p?&array['observationId','tenantRef','sessionRef','revision','semanticsVersion','derivationRuleVersion','observedAt','updatedAt','status','completedStages','pendingStages','intelligence','evidence','conflicts','explanations','errors']) then return false;end if;
 if coalesce(p->>'status','') not in('COMPLETE','PARTIAL','OWNED_ONLY','PROVIDER_UNAVAILABLE','EXPIRED','UNKNOWN') or jsonb_typeof(p->'intelligence')<>'object' or coalesce(length(p->>'semanticsVersion'),0)=0 or coalesce(length(p->>'derivationRuleVersion'),0)=0 then return false;end if;
 foreach txt in array array['completedStages','pendingStages','evidence','conflicts','explanations','errors'] loop if jsonb_typeof(p->txt)<>'array' then return false;end if;end loop;
 foreach txt in array array['completedStages','pendingStages'] loop
 if exists(select 1 from jsonb_array_elements_text(p->txt) x where x not in('OWNED','NETWORK_LOCAL','NETWORK_LIVE','BROWSER','AUTOMATION','BEHAVIORAL','DERIVATION','UNKNOWN')) or (select count(*)<>count(distinct value) from jsonb_array_elements(p->txt)) then return false;end if;end loop;
 ids='{}';for e in select value from jsonb_array_elements(p->'evidence') loop
 if jsonb_typeof(e)<>'object' or coalesce(length(e->>'id'),0)=0 or e->>'id'=any(ids) or coalesce(length(e->>'provider'),0)=0 or coalesce(e->>'sourceClass','') not in('OWNED_AUTHORITATIVE','OWNED_OBSERVATION','LOCAL_SNAPSHOT','LOCAL_STALE','LIVE_PROVIDER','DERIVED','UNKNOWN') or coalesce(e->>'freshness','') not in('CURRENT','AGING','STALE','UNKNOWN') or not(e?'observedAt') then return false;end if;
 if jsonb_typeof(e->'observedAt') is distinct from 'string' then return false;end if;perform ni_security.timestamp_text(e->>'observedAt');ids=array_append(ids,e->>'id');end loop;
 foreach txt in array array['observationId','tenantRef','sessionRef','status','semanticsVersion','derivationRuleVersion','observedAt','updatedAt'] loop if jsonb_typeof(p->txt) is distinct from 'string' then return false;end if;end loop;
 foreach txt in array array['observedAt','updatedAt','completedAt'] loop if p?txt then if p->>txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?(Z|[+-][0-9]{2}:[0-9]{2})$' then return false;end if;if jsonb_typeof(p->txt) is distinct from 'string' then return false;end if;perform ni_security.timestamp_text(p->>txt);end if;end loop;
 if p?'eventRef' and p->>'eventRef' !~ '^event_[A-Za-z0-9_-]{8,128}$' then return false;end if;
 txt=p::text;
 if txt~'\m([0-9]{1,3}\.){3}[0-9]{1,3}\M' or txt~*'([0-9a-f]{1,4}:){4,}[0-9a-f:]+' or txt~*'ipref:|m25/(vault|provider-observations|derived|jobs)/|SPUR_TOKEN|BEGIN PRIVATE KEY|sk_live_' then return false;end if;
 if exists(with recursive nodes(v) as(select p union all select child from nodes n cross join lateral(select value child from jsonb_each(case when jsonb_typeof(n.v)='object' then n.v else '{}' end) union all select value from jsonb_array_elements(case when jsonb_typeof(n.v)='array' then n.v else '[]' end)) c)
 select 1 from nodes n cross join lateral jsonb_object_keys(case when jsonb_typeof(n.v)='object' then n.v else '{}' end) k where k=any(array['ip','rawIp','encryptedIp','ciphertext','vaultRef','protectedIpRef','networkObservationKey','networkDigest','r2Key','storageKey','cacheKey','queuePayload','rawProviderResponse','rawFingerprint','jobId','internalId','providerObservationId','sessionAssociationKey','freshnessEpoch','datasetPath','email','phone','customerName','fullName','postalAddress','paymentData','destination','redirect','redirectUrl','moneyPage','safePage','route','routingDecision','policyDecision','allow','block','challenge','offer','landingPage','campaignDestination','decisionDestination'])) then return false;end if;
 if p->'intelligence'?'network' then
 if jsonb_typeof(p->'intelligence'->'network')<>'object' then return false;end if;
 for item in select key,value from jsonb_each(p->'intelligence'->'network') where key<>'serviceOperators' loop
 a=item.value;if coalesce(a->>'state','') not in('TRUE','FALSE','UNKNOWN','KNOWN') or coalesce(a->>'freshness','') not in('CURRENT','AGING','STALE','UNKNOWN') then return false;end if;
 if a?'evidenceRefs' and (jsonb_typeof(a->'evidenceRefs')<>'array' or exists(select 1 from jsonb_array_elements_text(a->'evidenceRefs') x where not(x=any(ids)))) then return false;end if;end loop;end if;
 return true;exception when others then return false;end $$;
create function ni_security.ingest(p_bearer text,p_environment text,p_tenant text,p_epoch uuid,p_delivery uuid,p_raw text)
-- statement_timeout must be armed BEFORE the top-level statement begins.
-- A function SET clause cannot arm that statement's cancellation timer.
returns jsonb language plpgsql security definer set search_path='' set lock_timeout='2s' as $$
declare p_payload jsonb;c public.edge_intelligence_service_credentials%rowtype;g ni_security.grants%rowtype;b public.edge_intelligence_tenant_bindings%rowtype;
 old public.edge_intelligence_observations%rowtype;cur public.edge_intelligence_current%rowtype;a ni_security.admission%rowtype;
 src jsonb;o jsonb;context jsonb;cp jsonb;ln jsonb;before_cp jsonb;oe uuid=gen_random_uuid();pe uuid=gen_random_uuid();le uuid=gen_random_uuid();linkid uuid=gen_random_uuid();received timestamptz=clock_timestamp();h text;rowid uuid=gen_random_uuid();n integer;rev integer;result text;cnt bigint;oldest timestamptz;
begin
 -- Deny direct callers without a pre-armed bounded statement timeout.
 -- Core uses SET LOCAL in a separate protocol command before this SELECT.
 if current_setting('statement_timeout')::interval<=interval '0' or current_setting('statement_timeout')::interval>interval '8 seconds' then
 raise exception using errcode='55000',message='deadline_not_armed';end if;
 if not ni_security.raw_json_valid(p_raw) then raise exception using errcode='22023',message='invalid_payload';end if;p_payload=p_raw::jsonb;
 if not ni_security.payload_valid(p_payload) then raise exception using errcode='22023',message='invalid_payload';end if;
 if p_bearer is null or length(p_bearer)<32 or length(p_bearer)>512 or p_bearer !~ '^[!-~]+$' then raise exception using errcode='28000',message='unauthorized';end if;
 select * into c from public.edge_intelligence_service_credentials where token_hash=encode(sha256(convert_to(p_bearer,'UTF8')),'hex');
 if c.id is null or c.status<>'active' then raise exception using errcode='28000',message='unauthorized';end if;
 perform ni_security.lock_authorization(c.id,p_environment,p_tenant);
 select * into c from public.edge_intelligence_service_credentials where id=c.id;
 if c.id is null or c.status<>'active' then raise exception using errcode='28000',message='unauthorized';end if;
 select count(*) into n from ni_security.grants where credential_id=c.id and environment=p_environment and tenant_ref=p_tenant and status='active';
 if n<>1 then raise exception using errcode='42501',message='forbidden';end if;
 select * into g from ni_security.grants where credential_id=c.id and environment=p_environment and tenant_ref=p_tenant and status='active' order by id;
 select * into b from public.edge_intelligence_tenant_bindings where tenant_ref=p_tenant;
 if b.status is distinct from 'active' or b.environment is distinct from p_environment or b.binding_epoch is distinct from p_epoch
 or g.binding_epoch<>p_epoch or g.organization_id<>b.organization_id or g.valid_from>clock_timestamp() or g.expires_at<=clock_timestamp()
 then raise exception using errcode='42501',message='forbidden';end if;
 if p_payload->>'tenantRef' is distinct from p_tenant or p_payload->>'schemaVersion' is distinct from '1.0'
 or p_payload->>'observationId' !~ '^obs_[A-Za-z0-9_-]{8,128}$' or p_payload->>'sessionRef' !~ '^session_[A-Za-z0-9_-]{8,128}$'
 or not(p_payload ?& array['observationId','revision','sessionRef','status','observedAt','updatedAt','semanticsVersion','derivationRuleVersion'])
 then raise exception using errcode='22023',message='invalid_payload';end if;
 if jsonb_typeof(p_payload->'revision') is distinct from 'number' or (p_payload->>'revision')::numeric<>trunc((p_payload->>'revision')::numeric) then raise exception using errcode='22023',message='invalid_revision';end if;rev=(p_payload->>'revision')::numeric::integer;
 if rev<1 or (rev=1 and p_payload?'previousRevision') or (rev>1 and (p_payload->>'previousRevision')::integer is distinct from rev-1) then raise exception using errcode='22023',message='invalid_revision';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_environment||':'||b.organization_id||':'||p_tenant||':'||(p_payload->>'observationId'),0));
 src=jsonb_build_object('environment',p_environment,'organization_id',b.organization_id,'tenant_ref',p_tenant,'binding_epoch',p_epoch,
 'observation_id',p_payload->>'observationId','revision',rev,'previous_revision',p_payload->'previousRevision','schema_version',p_payload->>'schemaVersion',
 'semantics_version',p_payload->>'semanticsVersion','derivation_rule_version',p_payload->>'derivationRuleVersion','session_ref',p_payload->>'sessionRef',
 'event_ref',p_payload->'eventRef','observed_at',to_char((p_payload->>'observedAt')::timestamptz at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
 'updated_at_source',to_char((p_payload->>'updatedAt')::timestamptz at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
 'completed_at_source',case when p_payload?'completedAt' then to_jsonb(to_char((p_payload->>'completedAt')::timestamptz at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) else 'null'::jsonb end,
 'status',p_payload->>'status','payload',p_payload,'digest_version','NI-IMM-DIGEST-v1/typed-tree-1');
 h=ni_security.digest('source_evidence',src);
 if exists(select 1 from ni_security.deliveries where environment=p_environment and delivery_id=p_delivery and (source_digest<>h or tenant_ref<>p_tenant or binding_epoch<>p_epoch)) then raise exception using errcode='23505',message='conflict';end if;
 select * into old from public.edge_intelligence_observations where organization_id=b.organization_id and tenant_ref=p_tenant and observation_id=p_payload->>'observationId' and revision=rev;
 if old.id is not null and (old.source_digest is distinct from h or old.binding_epoch is distinct from p_epoch or old.payload is distinct from p_payload) then raise exception using errcode='23505',message='conflict';end if;
 select * into cur from public.edge_intelligence_current where organization_id=b.organization_id and tenant_ref=p_tenant and observation_id=p_payload->>'observationId' for update;
 -- Environment admission lock is the final audit-stream lock. Serializes capacity reservation.
 select * into a from ni_security.admission where environment=p_environment;
 if a.stream_id is null then raise exception using errcode='55000',message='audit_unavailable';end if;
 perform 1 from ni_security.audit_streams where id=a.stream_id for update;
 select count(*),min(created_at) into cnt,oldest from ni_security.outbox where stream_id=a.stream_id;
 if not a.reconciled or a.checkpoint_at is null or a.checkpoint_at<=clock_timestamp()-interval '15 minutes' or cnt+3>100000 or oldest<=clock_timestamp()-interval '15 minutes' then raise exception using errcode='55000',message='audit_unavailable';end if;
 if old.id is not null then
 if not exists(select 1 from ni_security.audit_events where body->'record_key'->>'id'=old.id::text and body->>'event_type'='observation_retained') then raise exception using errcode='55000',message='audit_unavailable';end if;
 if not exists(select 1 from ni_security.deliveries where environment=p_environment and delivery_id=p_delivery) then
 insert into ni_security.deliveries values(p_environment,p_delivery,p_tenant,p_epoch,h,old.id);
 perform ni_security.audit(a.stream_id,jsonb_build_object('event_type','delivery_replay','record_type','observation','record_key',jsonb_build_object('id',old.id),'before_digest',old.record_digest,'after_digest',old.record_digest,'outcome','duplicate','authorization_context',jsonb_build_object('credential_id',c.id,'grant_id',g.id,'environment',p_environment,'tenant_ref',p_tenant,'organization_id',b.organization_id,'binding_epoch',p_epoch,'delivery_id',p_delivery)));
 end if;
 -- Final wall-clock expiry check applies to every successful replay.
 if g.expires_at<=clock_timestamp() then raise exception using errcode='42501',message='forbidden';end if;
 return jsonb_build_object('outcome','duplicate','observationId',old.observation_id,'revision',rev,'deliveryId',p_delivery);end if;
 context=jsonb_build_object('credential_id',c.id,'grant_id',g.id,'environment',p_environment,'tenant_ref',p_tenant,'organization_id',b.organization_id,'binding_epoch',p_epoch,'delivery_id',p_delivery);
 o=src||jsonb_build_object('id',rowid,'payload_hash',encode(sha256(convert_to(p_payload::text,'UTF8')),'hex'),'received_at',to_char(received at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'credential_id',c.id,'grant_id',g.id,'delivery_id',p_delivery);
 before_cp=case when cur.organization_id is not null then ni_security.normalize_state(to_jsonb(cur)) end;
 result=case when cur.revision is null or rev>cur.revision then 'accepted' else 'stale' end;
 insert into public.edge_intelligence_observations(id,organization_id,tenant_ref,observation_id,revision,previous_revision,schema_version,semantics_version,derivation_rule_version,session_ref,event_ref,observed_at,updated_at_source,completed_at_source,status,payload,payload_hash,
 environment,binding_epoch,credential_id,grant_id,delivery_id,digest_version,source_digest,record_digest,received_at)
 values(rowid,b.organization_id,p_tenant,p_payload->>'observationId',rev,case when rev>1 then rev-1 else null end,p_payload->>'schemaVersion',p_payload->>'semanticsVersion',p_payload->>'derivationRuleVersion',p_payload->>'sessionRef',p_payload->>'eventRef',(p_payload->>'observedAt')::timestamptz,(p_payload->>'updatedAt')::timestamptz,(p_payload->>'completedAt')::timestamptz,p_payload->>'status',p_payload,encode(sha256(convert_to(p_payload::text,'UTF8')),'hex'),
 p_environment,p_epoch,c.id,g.id,p_delivery,'NI-IMM-DIGEST-v1/typed-tree-1',h,ni_security.digest('observation',o),received);
 if result='accepted' then
 insert into public.edge_intelligence_current(organization_id,tenant_ref,observation_id,observation_row_id,revision,audit_event_id,digest_version) values(b.organization_id,p_tenant,p_payload->>'observationId',rowid,rev,pe,'NI-IMM-DIGEST-v1/typed-tree-1')
 on conflict(organization_id,tenant_ref,observation_id) do update set observation_row_id=excluded.observation_row_id,revision=excluded.revision,updated_at=clock_timestamp(),audit_event_id=pe,digest_version='NI-IMM-DIGEST-v1/typed-tree-1';end if;
 insert into public.edge_intelligence_journey_links(id,organization_id,observation_row_id,journey_id,linkage_basis,linkage_evidence,created_at,updated_at,audit_event_id,digest_version) values(linkid,b.organization_id,rowid,null,'unresolved','{}',received,received,le,'NI-IMM-DIGEST-v1/typed-tree-1');
 insert into ni_security.deliveries values(p_environment,p_delivery,p_tenant,p_epoch,h,rowid);
 select ni_security.normalize_state(to_jsonb(x)) into cp from public.edge_intelligence_current x where organization_id=b.organization_id and tenant_ref=p_tenant and observation_id=p_payload->>'observationId';
 select ni_security.normalize_state(to_jsonb(x)) into ln from public.edge_intelligence_journey_links x where id=linkid;
 perform ni_security.audit(a.stream_id,jsonb_build_object('id',oe,'event_type','observation_retained','record_type','observation','record_key',jsonb_build_object('id',rowid),'after_digest',ni_security.digest('observation',o),'authorization_context',context,'outcome',result));
 if result='accepted' then perform ni_security.audit(a.stream_id,jsonb_build_object('id',pe,'event_type','projection_changed','record_type','current_projection','record_key',jsonb_build_object('organization_id',b.organization_id,'tenant_ref',p_tenant,'observation_id',p_payload->>'observationId'),'before_digest',case when before_cp is not null then ni_security.digest('current_projection',before_cp) end,'after_digest',ni_security.digest('current_projection',cp),'authorization_context',context,'before_projection',before_cp,'after_projection',cp,'outcome',result));end if;
 perform ni_security.audit(a.stream_id,jsonb_build_object('id',le,'event_type','link_changed','record_type','journey_link','record_key',jsonb_build_object('id',linkid),'after_digest',ni_security.digest('journey_link',ln),'authorization_context',context,'after_link',ln,'outcome','unresolved'));
 if g.expires_at<=clock_timestamp() then raise exception using errcode='42501',message='forbidden';end if;
 return jsonb_build_object('outcome',result,'observationId',p_payload->>'observationId','revision',rev,'deliveryId',p_delivery);
end $$;
alter function ni_security.ingest(text,text,text,uuid,uuid,text) owner to ni_integrity_writer;
revoke all on all functions in schema ni_security from public;
grant execute on function ni_security.record_value(text,jsonb),ni_security.timestamp_text(text),ni_security.quote(text),ni_security.canonical(jsonb),ni_security.digest(text,jsonb),ni_security.normalize_state(jsonb),ni_security.payload_valid(jsonb),ni_security.raw_json_valid(text) to ni_integrity_writer;
grant execute on function ni_security.ingest(text,text,text,uuid,uuid,text) to ni_delivery_executor;
grant select,update on public.edge_intelligence_service_credentials,public.edge_intelligence_tenant_bindings to ni_controller_writer;
grant select,insert,update on ni_security.grants to ni_controller_writer;
grant select on ni_security.admission to ni_controller_writer;
grant execute on function ni_security.audit(uuid,jsonb) to ni_controller_writer;
create policy ni_grant_controller_insert on ni_security.grants for insert to ni_controller_writer with check(true);
create policy ni_grant_controller_update on ni_security.grants for update to ni_controller_writer using(true) with check(true);
create policy ni_credential_controller on public.edge_intelligence_service_credentials for update to ni_controller_writer using(true) with check(true);
create policy ni_binding_controller on public.edge_intelligence_tenant_bindings for update to ni_controller_writer using(true) with check(true);
create policy ni_controller_admission_read on ni_security.admission for select to ni_controller_writer using(true);
-- PostgreSQL row-locks require UPDATE privilege. Keep that privilege out of ingestion writer;
-- a private controller-owned lock helper has no application execution grant and no mutation body.
create function ni_security.lock_authorization(p_credential uuid,p_environment text,p_tenant text) returns void language plpgsql security definer set search_path='' as $$
begin
 perform 1 from public.edge_intelligence_service_credentials where id=p_credential for update;
 perform 1 from ni_security.grants where credential_id=p_credential and environment=p_environment and tenant_ref=p_tenant order by id for update;
 perform 1 from public.edge_intelligence_tenant_bindings where tenant_ref=p_tenant for update;
end $$;
alter function ni_security.lock_authorization(uuid,text,text) owner to ni_controller_writer;
revoke all on function ni_security.lock_authorization(uuid,text,text) from public;
grant execute on function ni_security.lock_authorization(uuid,text,text) to ni_integrity_writer;
create function ni_security.revoke_grant(p_grant uuid,p_actor text,p_reason text) returns void language plpgsql security definer set search_path='' set lock_timeout='2s' set statement_timeout='10s' as $$
declare g ni_security.grants%rowtype;s uuid;
begin
 if coalesce(length(p_actor),0)=0 or coalesce(length(p_reason),0)=0 then raise exception 'approval_required';end if;
 select * into strict g from ni_security.grants where id=p_grant;
 perform 1 from public.edge_intelligence_service_credentials where id=g.credential_id for update;
 select * into strict g from ni_security.grants where id=p_grant for update;
 perform 1 from public.edge_intelligence_tenant_bindings where tenant_ref=g.tenant_ref for update;
 if g.status='revoked' then return;end if;
 update ni_security.grants set status='revoked',revoked_at=clock_timestamp(),revoked_by=p_actor,revocation_reason=p_reason where id=p_grant;
 select stream_id into strict s from ni_security.admission where environment=g.environment;
 perform ni_security.audit(s,jsonb_build_object('event_type','grant_revoked','grant_id',p_grant,'actor',p_actor,'reason',p_reason,'before',to_jsonb(g),'after',(select to_jsonb(x) from ni_security.grants x where id=p_grant)));
end $$;
alter function ni_security.revoke_grant(uuid,text,text) owner to ni_controller_writer;
revoke all on function ni_security.revoke_grant(uuid,text,text) from public;
grant execute on function ni_security.revoke_grant(uuid,text,text) to ni_authorization_controller;
create function ni_security.create_grant(p_id uuid,p_credential uuid,p_environment text,p_tenant text,p_organization uuid,p_epoch uuid,p_expires timestamptz,p_actor text,p_approval text) returns void language plpgsql security definer set search_path='' set lock_timeout='2s' set statement_timeout='10s' as $$
declare b public.edge_intelligence_tenant_bindings%rowtype;s uuid;
begin
 if coalesce(length(p_actor),0)=0 or coalesce(length(p_approval),0)=0 or p_expires is null or p_expires<=clock_timestamp() then raise exception 'approval_required';end if;
 perform ni_security.lock_authorization(p_credential,p_environment,p_tenant);
 select * into strict b from public.edge_intelligence_tenant_bindings where tenant_ref=p_tenant;
 if not exists(select 1 from public.edge_intelligence_service_credentials where id=p_credential and status='active') or b.status<>'active' or b.organization_id<>p_organization or b.environment is distinct from p_environment or b.binding_epoch is distinct from p_epoch then raise exception using errcode='42501',message='forbidden';end if;
 insert into ni_security.grants(id,credential_id,environment,tenant_ref,organization_id,binding_epoch,status,valid_from,expires_at,approval_ref,approved_by) values(p_id,p_credential,p_environment,p_tenant,p_organization,p_epoch,'active',clock_timestamp(),p_expires,p_approval,p_actor);
 select stream_id into strict s from ni_security.admission where environment=p_environment;
 perform ni_security.audit(s,jsonb_build_object('event_type','grant_created','grant_id',p_id,'actor',p_actor,'approval_ref',p_approval,'after',(select to_jsonb(x) from ni_security.grants x where id=p_id)));
end $$;
alter function ni_security.create_grant(uuid,uuid,text,text,uuid,uuid,timestamptz,text,text) owner to ni_controller_writer;
revoke all on function ni_security.create_grant(uuid,uuid,text,text,uuid,uuid,timestamptz,text,text) from public;
grant execute on function ni_security.create_grant(uuid,uuid,text,text,uuid,uuid,timestamptz,text,text) to ni_authorization_controller;
create function ni_security.disable_binding(p_tenant text,p_actor text,p_reason text) returns void language plpgsql security definer set search_path='' set lock_timeout='2s' set statement_timeout='10s' as $$
declare ids uuid[];fresh uuid[];b public.edge_intelligence_tenant_bindings%rowtype;s uuid;g ni_security.grants%rowtype;
begin
 if coalesce(length(p_actor),0)=0 or coalesce(length(p_reason),0)=0 then raise exception 'approval_required';end if;
 select coalesce(array_agg(id order by id),'{}') into ids from ni_security.grants where tenant_ref=p_tenant and status='active';
 if cardinality(ids)>100 then raise exception 'batch_limit';end if;
 perform 1 from public.edge_intelligence_service_credentials where id in(select credential_id from ni_security.grants where id=any(ids)) order by id for update;
 perform 1 from ni_security.grants where id=any(ids) order by id for update;
 select * into strict b from public.edge_intelligence_tenant_bindings where tenant_ref=p_tenant for update;
 select coalesce(array_agg(id order by id),'{}') into fresh from ni_security.grants where tenant_ref=p_tenant and status='active';
 if fresh<>ids then raise exception using errcode='40001',message='scope_changed';end if;
 update public.edge_intelligence_tenant_bindings set status='disabled',updated_at=clock_timestamp() where tenant_ref=p_tenant;
 select stream_id into strict s from ni_security.admission where environment=b.environment;
 for g in select * from ni_security.grants where id=any(ids) order by id loop
 update ni_security.grants set status='revoked',revoked_at=clock_timestamp(),revoked_by=p_actor,revocation_reason=p_reason where id=g.id;
 perform ni_security.audit(s,jsonb_build_object('event_type','grant_revoked','grant_id',g.id,'actor',p_actor,'reason',p_reason,'before',to_jsonb(g),'after',(select to_jsonb(x) from ni_security.grants x where id=g.id)));
 end loop;
 perform ni_security.audit(s,jsonb_build_object('event_type','binding_disabled','tenant_ref',p_tenant,'actor',p_actor,'reason',p_reason,'before',to_jsonb(b),'after',(select to_jsonb(x) from public.edge_intelligence_tenant_bindings x where tenant_ref=p_tenant)));
end $$;
alter function ni_security.disable_binding(text,text,text) owner to ni_controller_writer;
revoke all on function ni_security.disable_binding(text,text,text) from public;
grant execute on function ni_security.disable_binding(text,text,text) to ni_authorization_controller;
-- No independent receipt destination is provisioned. There is deliberately NO acknowledgement or recovery RPC.
-- No grant to service_role; no production route import; no production cutover here.
-- Persisted row boundaries validate complete final records, independently of caller-side hashing.
create function ni_security.record_boundary() returns trigger language plpgsql set search_path='' as $$
declare r jsonb=to_jsonb(new);kind text;body jsonb;
begin
 if tg_table_name='edge_intelligence_observations' then
 body=ni_security.record_value('observation',r-'source_digest'-'record_digest');
 if new.source_digest is distinct from ni_security.digest('source_evidence',body-array['id','payload_hash','received_at','credential_id','grant_id','delivery_id']) or new.record_digest is distinct from ni_security.digest('observation',body) then raise exception using errcode='22023',message='invalid_record';end if;
 elsif tg_table_name in ('edge_intelligence_current','edge_intelligence_journey_links') then
 perform ni_security.record_value(case when tg_table_name='edge_intelligence_current' then 'current_projection' else 'journey_link' end,r);
 elsif tg_table_name='grants' then perform ni_security.record_value('credential_grant',r);
 elsif tg_table_name='edge_intelligence_tenant_bindings' then perform ni_security.record_value('tenant_binding',ni_security.normalize_state(r));
 elsif tg_table_name='audit_events' then
 kind=case when new.body?'actor_ref' then 'authorization_audit' else 'observation_audit' end;
 body=ni_security.record_value(kind,new.body);
 if new.record_digest is distinct from ni_security.digest(kind,body) or new.id::text is distinct from body->>'id' or new.stream_id::text is distinct from body->>'stream_id' or new.sequence is distinct from (body->>'sequence')::bigint or new.previous_digest is distinct from body->>'previous_digest' then raise exception using errcode='22023',message='invalid_record';end if;
 elsif tg_table_name='outbox' then
 if not exists(select 1 from ni_security.audit_events a where a.id=new.event_id and a.stream_id=new.stream_id and a.sequence=new.sequence and a.record_digest=new.event_digest) then raise exception using errcode='22023',message='invalid_record';end if;
 end if;
 return new;
end $$;
revoke all on function ni_security.record_boundary() from public;
grant execute on function ni_security.record_boundary() to ni_integrity_writer,ni_controller_writer;
grant execute on function ni_security.record_value(text,jsonb),ni_security.timestamp_text(text),ni_security.normalize_state(jsonb) to ni_controller_writer;
create trigger zz_ni_record_boundary before insert on public.edge_intelligence_observations for each row execute function ni_security.record_boundary();
create trigger zz_ni_record_boundary before insert or update on public.edge_intelligence_current for each row execute function ni_security.record_boundary();
create trigger zz_ni_record_boundary before insert on public.edge_intelligence_journey_links for each row execute function ni_security.record_boundary();
create trigger zz_ni_record_boundary before insert or update on ni_security.grants for each row execute function ni_security.record_boundary();
create trigger zz_ni_record_boundary before insert or update on public.edge_intelligence_tenant_bindings for each row execute function ni_security.record_boundary();
create trigger zz_ni_record_boundary before insert on ni_security.audit_events for each row execute function ni_security.record_boundary();
create trigger zz_ni_record_boundary before insert on ni_security.outbox for each row execute function ni_security.record_boundary();
commit;
