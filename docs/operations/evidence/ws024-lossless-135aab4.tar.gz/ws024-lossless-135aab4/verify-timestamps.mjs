import pg from '/private/tmp/ws024-timestamp-candidate/ui/node_modules/pg/lib/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {parseExact,normalizeTimestamp,digest} from '/private/tmp/ws024-timestamp-candidate/ui/lib/edge/security/integrity.ts';
import {normalizeRecord} from '/private/tmp/ws024-timestamp-candidate/ui/lib/edge/security/manifests.ts';
const client=new pg.Client({host:'127.0.0.1',port:56862,user:'postgres',database:'ni_disposable_lossless_suite'});await client.connect();
const evidence={candidate:'135aab4467ab8b4d48f73695d6b88af6802db69f',observations:[],boundaries:[]};
try{
 await client.query('begin read only');await client.query("set local statement_timeout='8s'");
 evidence.metadata=(await client.query('select version(),current_database(),clock_timestamp()')).rows[0];
 const query="select (to_jsonb(o)-'source_digest'-'record_digest')::text record_json,record_digest from edge_intelligence_observations o order by revision";
 evidence.observation_query=query;
 const rows=(await client.query(query)).rows;assert.equal(rows.length,3);
 for(const row of rows){const exact=parseExact(row.record_json);const normalized=normalizeRecord('observation',exact);const actual=digest('observation',normalized);const result={record_json:row.record_json,received_at_exact:exact.received_at,received_at_normalized:normalized.received_at,stored_digest:row.record_digest,recomputed_digest:actual,pass:actual===row.record_digest};evidence.observations.push(result);console.log(JSON.stringify(result));assert.equal(actual,row.record_digest);}
 for(const fraction of ['000001','123456','999999']){
  const expected='2026-10-17T00:00:00.'+fraction+'Z';const query="select jsonb_build_object('value',$1::timestamptz)::text value_json";const row=(await client.query(query,[expected])).rows[0];const value=parseExact(row.value_json).value;const normalized=normalizeTimestamp(value);
  const lossyNegativeControl=normalizeTimestamp(new Date(value).toISOString());
  const result={fraction,query,input:expected,value_json:row.value_json,extracted_exact:value,normalized,lossy_Date_negative_control:lossyNegativeControl,pass:normalized===expected&&lossyNegativeControl!==expected};evidence.boundaries.push(result);console.log(JSON.stringify(result));assert.equal(normalized,expected);assert.notEqual(lossyNegativeControl,expected);
 }
 evidence.assertion_strength={retained_count_exactly_three:true,stored_expected_digests_unchanged:true,all_three_recomputed:true,postgres_json_text_not_json_decoder:true,parseExact_used:true,Date_used_only_as_negative_control:true};
}finally{await client.query('rollback').catch(()=>{});await client.end();writeFileSync(new URL('timestamp-results.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');}
