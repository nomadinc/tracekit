import pg from '/private/tmp/ws024-timestamp-candidate/ui/node_modules/pg/lib/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
const literal=readFileSync(new URL('literal-query.original.sql',import.meta.url),'utf8').trim();
const match=literal.match(/ni_security\.canonical\('((?:[^']|'')*)'::jsonb\)/);if(!match)throw Error('original literal missing');
const raw=match[1].replaceAll("''","'");const inputLiteral="'"+match[1]+"'::jsonb";const parameterized=literal.replaceAll(inputLiteral,'$1::jsonb');
const client=new pg.Client({host:'127.0.0.1',port:56862,user:'postgres',database:'ni_disposable_lossless_suite'});await client.connect();
const results=[];
async function probe(id,text,values=[],{generic=false,timeout='8s',expectPlan=false}={}){
 await client.query('begin read only');await client.query('set local role ni_integrity_writer');await client.query("set local statement_timeout='"+timeout+"'");
 if(generic)await client.query("set local plan_cache_mode='force_generic_plan'");
 const start=performance.now();let result,error,aborted;
 try{result=await client.query(generic?{name:'ws024_generic_'+id,text,values}:values.length?{text,values}:text);}catch(e){error=e;}
 const elapsed=performance.now()-start;
 if(error){try{await client.query('select 1');}catch(e){aborted=e.code;}}
 await client.query('rollback');
 const row={id,text,values,generic_plan:generic,statement_timeout:timeout,elapsed_ms:elapsed,sqlstate:error?.code??'00000',error:error?{message:error.message,where:error.where,detail:error.detail,routine:error.routine,severity:error.severity}:null,aborted_sqlstate:aborted,rows:result?.rows??null,explain_without_analyze:expectPlan};results.push(row);console.log(JSON.stringify(row));return row;
}
const tables=['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams','ni_security.grants','edge_intelligence_tenant_bindings','edge_intelligence_service_credentials'];
async function snapshot(){const out={};for(const t of tables)out[t]=(await client.query("select count(*)::int rows,encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),'[]'::jsonb)::text,'UTF8')),'hex') sha256 from "+t+' x')).rows[0];return out;}
const before=await snapshot();
try{
 console.log(JSON.stringify({metadata:(await client.query("select version(),current_database(),pg_backend_pid(),clock_timestamp(),(select proconfig from pg_proc where oid='ni_security.ingest(text,text,text,uuid,uuid,text)'::regprocedure) ingest_function_settings")).rows[0]}));
 await probe('literal-original-cold',literal);
 await probe('literal-explain-no-analyze','EXPLAIN (VERBOSE, FORMAT JSON) '+literal,[],{expectPlan:true});
 await probe('parameterized-identical-shape',parameterized,[raw]);
 await probe('parameterized-generic-identical-shape',parameterized,[raw],{generic:true});
 await probe('parameterized-generic-explain','EXPLAIN (VERBOSE, FORMAT JSON) '+parameterized,[raw],{generic:true,expectPlan:true});
 await probe('parameterized-direct-digest','select ni_security.digest($1,$2::jsonb) digest',['authorization_audit',raw]);
 await probe('literal-original-warm',literal);
 await probe('prearmed-read-only-control','select pg_sleep(9)');
 await probe('same-command-read-only-setting',"with armed as materialized (select set_config('statement_timeout','8s',true)) select pg_sleep(9) from armed",[],{timeout:'0'});
}finally{const after=await snapshot();const evidence={candidate:'135aab4467ab8b4d48f73695d6b88af6802db69f',results,before,after,unchanged:JSON.stringify(before)===JSON.stringify(after),scope:'Read-only helper/planning/timer controls; no ingestion or real Core adapter request executed by this investigation'};writeFileSync(new URL('timeout-results.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({ten_tables_unchanged:evidence.unchanged}));await client.end();}
