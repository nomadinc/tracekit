# Reproduce the exact NI DB 002 failures

Run from the extracted archive root. Python 3 and PostgreSQL 17 `psql` are required. No Node dependencies, production credentials or remote service are needed for the handoff replay. The historical runners in `scripts/*.original.*` are preserved verbatim for inspection; their original absolute paths are not the portable reproduction entry point.

Verify the downloaded archive against its published SHA-256 sidecar before extraction, then verify every package file:

```sh
python3 scripts/verify_package.py
```

The exact executed command used the existing isolated loopback cluster and populated synthetic database:

```sh
NI_NATIVE_DISPOSABLE=synthetic-only \
PGHOST=127.0.0.1 PGPORT=56832 PGDATABASE=ni_disposable_suite PGUSER=postgres \
python3 scripts/reproduce.py --output /private/tmp/ws024-ni-db002-handoff-replay
```

For another replay, choose a NEW output directory; the runner refuses to overwrite evidence. Output must be outside the sealed package. Unset `PGPASSWORD`, `PGSERVICE`, `PGHOSTADDR` and `PGOPTIONS`. The runner never prints a credential and disables password prompting. All statements run in one `BEGIN READ ONLY` transaction, with a savepoint and exact before/after full-table content hashes for each case, followed by `ROLLBACK`. SQLSTATE comes from psql's `:SQLSTATE` immediately after the original SELECT.

Expected result against the exact reviewed implementation: `replay_complete: true`, `failure_count: 32`, Python exit **1**. This means 32 unchanged rejection assertions failed, not a successful conformance test. psql itself returns 0 because each SELECT returned a digest. Exit 2 means the expected complete 32-failure replay was not established; inspect its logs. Capture stderr and exit status. The captured run has a harmless `/dev/null` password-file warning; no password was supplied.

## Optional fresh disposable environment

These setup commands are supplied for recipients without the retained environment. They were **not newly executed** during this bounded handoff. The structural source files are byte-for-byte copies from the reviewed candidate. Use a NEW isolated local cluster with no existing NI/Supabase test roles and an EMPTY `ni_disposable_*` database. Do not run setup on an existing database, production service or shared cluster. No grants or migrations are installed by `reproduce.py` itself.

```sh
docker run --name ws024-ni-db002-evidence \
  -e POSTGRES_HOST_AUTH_METHOD=trust -p 127.0.0.1:56842:5432 -d postgres:17.11
# Wait for this exact new cluster's readiness before proceeding:
docker exec ws024-ni-db002-evidence pg_isready -U postgres
docker exec ws024-ni-db002-evidence createdb -U postgres ni_disposable_exact_failures
export PGHOST=127.0.0.1 PGPORT=56842 PGUSER=postgres PGDATABASE=ni_disposable_exact_failures
psql -X --no-password -v ON_ERROR_STOP=1 \
  -f fixtures/synthetic-baseline.sql \
  -f fixtures/20261004204330_edge_intelligence_v1_ingestion.sql \
  -f fixtures/20261004204342_edge_intelligence_multitenant_delivery.sql \
  -f fixtures/network-intelligence-security.sql
NI_NATIVE_DISPOSABLE=synthetic-only \
python3 scripts/reproduce.py --output ../ws024-exact-failures-new-replay
```

The source migrations/prepared SQL are reviewed fixture installation material, not a production migration request. Empty structural tables suffice to evaluate these generic digest helper cases; they do not constitute valid delivery fixtures or authoritative writer tests. The observed handoff run instead used the previously populated `ni_disposable_suite`, whose per-case row counts and hashes are in `logs/handoff-replay-results.json`.

Keep new output separate. None of the helper replays establishes rejection or acceptance through an authoritative internal record writer. Resolve that mapping and security impact independently with WS-001 and WS-022. Production V1 remains HOLD.
