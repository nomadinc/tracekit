#!/usr/bin/env python3
"""Replay exact preserved helper statements, read-only, using Python and psql.
No schema installation, role/grant change or network destination discovery.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

PACKAGE = Path(__file__).resolve().parents[1]
TABLES = ['public.edge_intelligence_observations', 'public.edge_intelligence_current',
          'public.edge_intelligence_journey_links', 'ni_security.deliveries',
          'ni_security.audit_events', 'ni_security.outbox', 'ni_security.audit_streams']


def snapshot_sql(case_id, phase):
    entries = []
    for table in TABLES:
        entries += ["'" + table + "'", "(select jsonb_build_object('rows',count(*),'full_rows_sha256',"
                    "encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),"
                    "'[]'::jsonb)::text,'UTF8')),'hex')) from " + table + " x)"]
    return ("select json_build_object('evidence_kind','snapshot','case_id','" + case_id +
            "','phase','" + phase + "','tables',jsonb_build_object(" + ','.join(entries) + "));\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path,
                        help='NEW output directory outside the sealed evidence package')
    args = parser.parse_args()
    output = args.output.resolve()
    if output == PACKAGE or PACKAGE in output.parents:
        raise SystemExit('replay output must be outside the sealed package')
    if output.exists():
        raise SystemExit('output directory must not exist; never overwrite original logs')
    if os.environ.get('NI_NATIVE_DISPOSABLE') != 'synthetic-only':
        raise SystemExit('NI_NATIVE_DISPOSABLE=synthetic-only required')
    host = os.environ.get('PGHOST', '')
    database = os.environ.get('PGDATABASE', '')
    port = os.environ.get('PGPORT', '')
    user = os.environ.get('PGUSER', '')
    if host not in ('127.0.0.1', 'localhost', '::1'):
        raise SystemExit('explicit loopback PGHOST required')
    if not re.fullmatch(r'ni_disposable_[a-z0-9_]+', database):
        raise SystemExit('explicit ni_disposable_* PGDATABASE required')
    if not port.isdigit() or not 1 <= int(port) <= 65535 or not re.fullmatch(r'[a-z][a-z0-9_]*', user):
        raise SystemExit('explicit PGPORT and PGUSER required')
    # Refuse implicit service routing/options. This synthetic replay uses local
    # trust or an explicitly provisioned test login, never a production password.
    if any(os.environ.get(k) for k in ('PGSERVICE', 'PGHOSTADDR', 'PGOPTIONS', 'PGPASSWORD')):
        raise SystemExit('unset PGSERVICE/PGHOSTADDR/PGOPTIONS/PGPASSWORD for synthetic replay')
    env = os.environ.copy()
    env['PGPASSFILE'] = os.devnull
    statements = (PACKAGE / 'fixtures/negative-statements.exact.sql').read_bytes().splitlines(keepends=True)
    if len(statements) != 32:
        raise SystemExit('expected exactly 32 unchanged statements')
    sql = [b'\\set VERBOSITY verbose\n', b'BEGIN READ ONLY;\n', b"SET LOCAL statement_timeout='8s';\n",
           b"select json_build_object('evidence_kind','metadata','version',version(),'database',current_database(),'transaction_read_only',current_setting('transaction_read_only'),'identity',current_user);\n",
           b"select json_build_object('evidence_kind','function_definition','signature',p.oid::regprocedure::text,'definition',pg_get_functiondef(p.oid)) from pg_proc p where p.oid in ('ni_security.digest(text,jsonb)'::regprocedure,'ni_security.canonical(jsonb)'::regprocedure);\n"]
    ids = []
    for statement in statements:
        match = re.search(rb"'negative','([^']+)'", statement)
        if not match:
            raise SystemExit('malformed original statement')
        case_id = match.group(1).decode('ascii')
        ids.append(case_id)
        sql += [snapshot_sql(case_id, 'before').encode(), b'SAVEPOINT negative_case;\n', statement]
        if not statement.endswith(b'\n'):
            sql.append(b'\n')
        sql += [('\\echo WS024_SQLSTATE ' + case_id + ' :SQLSTATE\n').encode(),
                b'ROLLBACK TO SAVEPOINT negative_case;\n', b'RELEASE SAVEPOINT negative_case;\n',
                snapshot_sql(case_id, 'after').encode()]
    sql.append(b'ROLLBACK;\n')
    sql_bytes = b''.join(sql)
    output.mkdir(parents=True)
    (output / 'replay.executed.sql').write_bytes(sql_bytes)
    command = ['psql', '-X', '-A', '-t', '--no-password', '-h', host, '-p', port,
               '-U', user, '-d', database, '-v', 'ON_ERROR_STOP=0']
    result = subprocess.run(command, input=sql_bytes, capture_output=True, env=env, timeout=120)
    (output / 'psql.stdout.log').write_bytes(result.stdout)
    (output / 'psql.stderr.log').write_bytes(result.stderr)
    records = []
    states = {}
    for line in result.stdout.decode().splitlines():
        if line.startswith('{'):
            records.append(json.loads(line))
        elif line.startswith('WS024_SQLSTATE '):
            _, case_id, state = line.split()
            states[case_id] = state
    metadata = [r for r in records if r.get('evidence_kind') == 'metadata']
    definitions = [r for r in records if r.get('evidence_kind') == 'function_definition']
    actual = {r['negative']: r for r in records if 'negative' in r}
    snapshots = {(r['case_id'], r['phase']): r['tables'] for r in records if r.get('evidence_kind') == 'snapshot'}
    cases = []
    for case_id in ids:
        before = snapshots.get((case_id, 'before'))
        after = snapshots.get((case_id, 'after'))
        cases.append({'id':case_id, 'expected':'REJECT', 'actual':actual.get(case_id),
                      'sqlstate':states.get(case_id), 'sqlstate_source':'psql :SQLSTATE immediately after original SELECT',
                      'helper_assertion':'FAIL' if case_id in actual else 'UNRESOLVED',
                      'before':before, 'after':after,
                      'observed_zero_row_change':before is not None and after is not None and before == after,
                      'authoritative_internal_persistence':'NOT TESTED'})
    valid = (result.returncode == 0 and len(metadata) == 1 and metadata[0]['transaction_read_only'] == 'on'
             and len(definitions) == 2 and len(actual) == 32 and len(states) == 32
             and len(snapshots) == 64 and all(c['sqlstate'] == '00000' and c['observed_zero_row_change'] for c in cases))
    summary = {'metadata':metadata, 'function_definitions':definitions,
               'executed_sql_sha256':hashlib.sha256(sql_bytes).hexdigest(),
               'psql_returncode':result.returncode, 'replay_complete':valid,
               'failure_count':sum(c['helper_assertion'] == 'FAIL' for c in cases), 'cases':cases,
               'scope':'read-only helper acceptance and observed no row changes; no authoritative writer execution'}
    (output / 'replay-results.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'replay_complete':valid,'failure_count':summary['failure_count'],
                      'output':str(output),'exit_code':1 if valid else 2}))
    # Exit 1 means the original rejection assertion failed for all 32 cases.
    # Exit 2 means incomplete/invalid execution evidence. Neither is a PASS.
    return 1 if valid else 2


if __name__ == '__main__':
    sys.exit(main())
