import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {checkCandidate} from './check-candidate.mjs';
const checked = checkCandidate();
const require = createRequire(checked.candidate+'/ui/package.json');
const {Client} = require('pg');
const client = new Client({connectionString:checked.databaseUrl.toString()});
const originalSql = readFileSync(new URL('../../docs/operations/evidence/ws024-native-completion/digest-vectors.sql',import.meta.url),'utf8')
 .split('\n').filter(line => line.includes("'negative'"));
assert.equal(originalSql.length,32);
const results=[];
async function probe(id,sql,values,kind) {
 await client.query('savepoint negative_probe');
 let error, rows;
 try {rows = (await client.query(sql,values)).rows;} catch (caught) {error=caught;}
 finally {await client.query('rollback to savepoint negative_probe');await client.query('release savepoint negative_probe');}
 const rejected = kind === 'boolean' ? !error && rows[0].valid === false :
  !!error && ['22023','22007','22008','22003'].includes(error.code);
 results.push({id,expected:'REJECT',status:rejected?'PASS':'FAIL',
  boundary:'helper-only; authoritative persisted-boundary acceptance not established',
  sql,values,sqlstate:error?.code??'00000',actual:rows??null,message:error?.message??null});
}
await client.connect();
try {
 await client.query('begin read only');
 await client.query("set local statement_timeout='8s'");
 const required=['ni_security.digest(text,jsonb)','ni_security.normalize_state(jsonb)','ni_security.raw_json_valid(text)'];
 for(const signature of required)assert((await client.query('select to_regprocedure($1) f',[signature])).rows[0].f,'missing entry point '+signature);
 for(const sql of originalSql)await probe(sql.match(/'negative','([^']+)'/)[1],sql,[],'exception');
 for(const vector of checked.vectors.invalid.filter(v=>v.id.startsWith('timestamp-invalid')))
  await probe(vector.id,"select ni_security.normalize_state(jsonb_build_object('updated_at',$1::text))",[vector.input],'exception');
 for(const vector of checked.vectors.invalid.filter(v=>'input_json'in v))
  await probe(vector.id,'select ni_security.raw_json_valid($1) valid',[vector.input_json],'boolean');
 await probe('SQL-NULL','select ni_security.raw_json_valid(null) valid',[],'boolean');
 console.log(JSON.stringify({sha:checked.sha,contractHash:checked.contractHash,vectorHash:checked.vectorHash,
  results,summary:{PASS:results.filter(r=>r.status==='PASS').length,FAIL:results.filter(r=>r.status==='FAIL').length},
  authoritativePersistedBoundary:'NOT IMPLEMENTED in this read-only helper runner; requires candidate-specific internal writer/validator mapping for all 32 record vectors'},null,2));
 process.exitCode=results.some(r=>r.status==='FAIL')?1:0;
} finally {await client.query('rollback').catch(()=>{});await client.end();}
