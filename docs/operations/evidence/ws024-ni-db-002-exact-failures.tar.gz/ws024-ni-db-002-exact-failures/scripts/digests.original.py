from pathlib import Path
import json,re,subprocess,os,hashlib
root=Path.cwd();out=Path('/tmp/ws024-modelb-native/completion')
env=json.loads(subprocess.check_output(['docker','inspect','ws024-modelb-postgres'],text=True))[0]['Config']['Env']
for x in env:
 if x.startswith('POSTGRES_PASSWORD='):os.environ['PGPASSWORD']=x.split('=',1)[1]
cmd=['psql','-h','127.0.0.1','-p','56822','-U','postgres','-d','ws024_modelb_ordering2','-X','-At']
def q(x):return "'"+str(x).replace("'","''")+"'"
def encode(x):
 if isinstance(x,dict) and set(x)=={'exact_json_number_token'}:return x['exact_json_number_token']
 if isinstance(x,dict):return '{'+','.join(json.dumps(k)+':'+encode(v) for k,v in x.items())+'}'
 if isinstance(x,list):return '['+','.join(map(encode,x))+']'
 return json.dumps(x,ensure_ascii=False)
v=json.loads((root/'ui/tests/fixtures/network-security/vectors.json').read_text());spec=(root/'docs/operations/NI-AUTH-001-Model-B-v1-Technical-Specification.md').read_text()
log=[];sql=['\\set VERBOSITY verbose']
for r in v['records']:
 assert r['canonical_hex'] in spec and r['sha256'] in spec,r['id']
 if 'normalized' in r:
  expr="jsonb_build_object('timestamp',to_char(%s::timestamptz at time zone 'UTC','YYYY-MM-DD\"T\"HH24:MI:SS.US\"Z\"'))"%q(r['input'])
 else:expr=q(encode(r['input']))+'::jsonb'
 sql.append("select json_build_object('id',%s,'canonical_pass',encode(convert_to(ni_security.canonical(%s),'UTF8'),'hex')=%s,'digest_pass',ni_security.digest(%s,%s)=%s);"%(q(r['id']),expr,q(r['canonical_hex']),q(r['record_type']),expr,q(r['sha256'])))
for r in v['invalid']:
 if 'input' in r and 'record_type' in r:
  sql.append("select json_build_object('negative',%s,'expected','REJECT','actual_digest',ni_security.digest(%s,%s::jsonb));"%(q(r['id']),q(r['record_type']),q(encode(r['input']))))
 else:log.append({'id':r['id'],'classification':'NOT IMPLEMENTED','reason':'No native manifest/normalization/crypto verification entry point for this vector; not counted as PASS'})
(out/'digest-vectors.sql').write_text('\n'.join(sql))
p=subprocess.run(cmd,input='\n'.join(sql),text=True,capture_output=True)
(out/'digest-native.log').write_text(p.stdout+p.stderr)
rows=[json.loads(x) for x in p.stdout.splitlines() if x.startswith('{')]
summary={'positive_pass':sum(x.get('canonical_pass',False) and x.get('digest_pass',False) for x in rows),'positive_total':len(v['records']),'negative_unexpected_accept':sum('actual_digest' in x for x in rows),'negative_unimplemented':log,'contract_sha256':hashlib.sha256(spec.encode()).hexdigest()}
(out/'digest-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
