import pg from '/private/tmp/ws024-corrected-candidate/ui/node_modules/pg/lib/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {openSecureConnection} from '/private/tmp/ws024-corrected-candidate/ui/lib/edge/security/connection.ts';
import {createModelBRoute} from '/private/tmp/ws024-corrected-candidate/ui/lib/edge/security/route.ts';
const file=p=>{let s=readFileSync('/private/tmp/ws024-corrected-candidate/'+p,'utf8');return p.endsWith('network-intelligence-security.sql')?s.replace(/^create role .*;$/gm,''):s;};
const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const token='PUBLIC-SYNTHETIC-BEARER-0000000000000001';
const admin=new pg.Client({host:'127.0.0.1',port:56832,user:'postgres',database:'postgres'});await admin.connect();
await admin.query('create database ni_disposable_supplement');await admin.end();
const client=new pg.Client({host:'127.0.0.1',port:56832,user:'postgres',database:'ni_disposable_supplement'});await client.connect();
const db={exec:sql=>client.query(sql),query:(s,v)=>client.query(s,v)};
 await db.exec(`create table public.tracekit_organizations(id uuid primary key);`);
 await db.exec(file('supabase/migrations/20261004204330_edge_intelligence_v1_ingestion.sql'));
 await db.exec(file('supabase/migrations/20261004204342_edge_intelligence_multitenant_delivery.sql'));
 await db.exec(file('docs/operations/prepared/network-intelligence-security.sql'));
 // Separate command: the function-local SET clause is not a statement timer.
 await db.exec("set statement_timeout='8s';set lock_timeout='2s';set idle_in_transaction_session_timeout='10s'");
 await db.exec(`insert into tracekit_organizations values('${id(2)}'),('${id(22)}');
 insert into edge_intelligence_service_credentials(id,label,token_hash) values('${id(4)}','synthetic',encode(sha256(convert_to('${token}','UTF8')),'hex'));
 insert into edge_intelligence_tenant_bindings(tenant_ref,organization_id,environment,binding_epoch,approval_ref,approved_by) values('tenant_test0001','${id(2)}','test','${id(3)}','synthetic','controller');
 insert into ni_security.grants(id,credential_id,environment,tenant_ref,organization_id,binding_epoch,status,valid_from,approval_ref,approved_by) values('${id(5)}','${id(4)}','test','tenant_test0001','${id(2)}','${id(3)}','active','2020-01-01Z','synthetic','controller');
 insert into ni_security.audit_streams(id) values('${id(15)}');insert into ni_security.admission values('test','${id(15)}',clock_timestamp(),true);`);
const payload=(revision=1)=>({schemaVersion:'1.0',observationId:'obs_test0001',tenantRef:'tenant_test0001',revision,...(revision>1?{previousRevision:revision-1}:{}),semanticsVersion:'m23-v1',derivationRuleVersion:'hybrid-derived-v1',sessionRef:'session_test0001',observedAt:'2026-10-17T00:00:00.000000Z',updatedAt:'2026-10-17T00:00:00.000000Z',status:'PARTIAL',completedStages:[],pendingStages:[],intelligence:{},evidence:[],conflicts:[],explanations:[],errors:[]});
async function ingest(p=payload(),overrides={}){
 await db.exec('set role ni_delivery_executor');try{return (await db.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text) as result',[overrides.token??token,overrides.environment??'test',overrides.tenant??'tenant_test0001',overrides.epoch??id(3),overrides.delivery??id(6+p.revision),JSON.stringify(p)])).rows[0].result;}finally{await db.exec('reset role');}
}
const results=[];const check=(name,ok,detail={})=>{const r={name,status:ok?'PASS':'FAIL',...detail};results.push(r);console.log(JSON.stringify(r));};
const tables=['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams'];
async function snapshot(){let s={};for(const t of tables)s[t]=(await client.query('select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),\'[]\'::jsonb) s from '+t+' x')).rows[0].s;return JSON.stringify(s);}
async function attempt(name,fn,expected){let e;try{await fn();}catch(x){e=x;}check(name,!!e&&(!expected||e.code===expected),{sqlstate:e?.code??'00000',message:e?.message??'accepted'});}


const original='/Users/nomadm/Projects/tracekit-ws024-security-review/docs/operations/evidence/ws024-native-completion/';
const vectors=JSON.parse(readFileSync(original+'vectors.json','utf8'));
function encode(x){if(x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===1&&x.exact_json_number_token)return x.exact_json_number_token;if(Array.isArray(x))return '['+x.map(encode).join(',')+']';if(x&&typeof x==='object')return '{'+Object.entries(x).map(([k,v])=>JSON.stringify(k)+':'+encode(v)).join(',')+'}';return JSON.stringify(x);}
let before=await snapshot();for(const v of vectors.invalid.filter(x=>x.record_type&&'input'in x)){await client.query('set role ni_delivery_executor');await attempt('original record as raw RPC '+v.id,()=>client.query('select ni_security.ingest($1,$2,$3,$4,$5,$6)',[token,'test','tenant_test0001',id(3),id(95),encode(v.input)]),'22023');await client.query('reset role');}check('32 raw RPC record shapes zero writes',before===await snapshot());
await client.query('create function public.supp_delay() returns trigger language plpgsql as $$begin perform pg_sleep(9);return new;end$$;create trigger supp_delay before insert on ni_security.outbox for each row execute function public.supp_delay()');
for(let n=0;n<2;n++){before=await snapshot();await client.query('begin');await client.query("set local statement_timeout='8s'");await client.query('set local role ni_delivery_executor');let t=performance.now();await attempt('explicit transaction cancellation '+n,()=>client.query('select ni_security.ingest($1,$2,$3,$4,$5,$6)',[token,'test','tenant_test0001',id(3),id(96),JSON.stringify(payload())]),'57014');const elapsed=performance.now()-t;check('explicit transaction 7-9s window '+n,elapsed>=7000&&elapsed<9000,{elapsed_ms:elapsed});await attempt('transaction remains aborted '+n,()=>client.query('select 1'),'25P02');await client.query('rollback');check('explicit cancellation full rollback '+n,before===await snapshot());}
await client.query('drop trigger supp_delay on ni_security.outbox');
const config={host:'localhost',port:56832,database:'ni_disposable_supplement',user:'ws024_native_executor',password:'PUBLIC-SYNTHETIC-LOCAL-ONLY',ca:readFileSync('/private/tmp/ws024-native-server.crt','utf8'),environment:'test',telemetryApprovalRef:'synthetic-independent'};
before=await snapshot();const conn=await openSecureConnection(config);await conn.query('begin',[]);await conn.query("set local statement_timeout='8s'",[]);await conn.query('select ni_security.ingest($1,$2,$3,$4,$5,$6)',[token,'test','tenant_test0001',id(3),id(97),JSON.stringify(payload())]);let t=performance.now();await conn.query('select pg_sleep(4)',[]);await conn.query('select pg_sleep(4)',[]);await attempt('default real adapter 10s watchdog',()=>conn.query('select pg_sleep(4)',[]),'TRANSPORT');check('default watchdog wall-clock bound',performance.now()-t>=8500&&performance.now()-t<11000,{elapsed_ms:performance.now()-t});await new Promise(r=>setTimeout(r,300));check('default watchdog rolls back accepted uncommitted ingestion',before===await snapshot());await attempt('default watchdog disposes connection',()=>conn.query('select 1',[]),'CONNECTION_CLOSED');await conn.dispose();
writeFileSync(new URL('supplement-results.json',import.meta.url),JSON.stringify(results,null,2));await client.end();
