#!/usr/bin/env python3
"""Verify package hashes and cross-check all 32 unchanged negative cases."""
from pathlib import Path
import csv
import hashlib
import json
import re

root = Path(__file__).resolve().parents[1]
manifest = root / 'SHA256SUMS.txt'
listed = set()
for line in manifest.read_text().splitlines():
    expected, name = line.split('  ', 1)
    path = (root / name).resolve()
    assert root in path.parents and path.is_file(), name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    listed.add(name)
actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p != manifest}
assert actual == listed, (actual-listed, listed-actual)
cases = json.loads((root / 'cases.json').read_text())['cases']
assert len(cases) == 32 and len({c['test_id'] for c in cases}) == 32
sql = (root / 'fixtures/negative-statements.exact.sql').read_bytes()
original = (root / 'fixtures/digest-vectors.original.sql').read_bytes()
assert sql == b''.join(line + b'\n' for line in original.splitlines() if b"'negative'" in line)
for case in cases:
    assert case['expected_result'] == 'REJECT'
    assert "'expected','REJECT'" in case['original_sql']
    raw = (root / case['exact_input_file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == case['exact_input_sha256']
    assert case['original_sql'].encode() + b'\n' in sql
    match = re.search(r"ni_security.digest\('[^']+',\s*'((?:[^']|'')*)'::jsonb\)",case['original_sql'])
    assert match.group(1).replace("''", "'").encode() == raw
    assert case['sqlstate'] == '00000' and case['boundary_classification'] == 'HELPER_ONLY'
    assert re.fullmatch('[a-f0-9]{64}',case['actual_digest'])
    assert case['handoff_replay']['observed_zero_row_change'] is True
    assert case['authoritative_internal_persistence_tested'] is False
with (root / 'cases.csv').open(newline='') as f:
    csv_rows = list(csv.DictReader(f))
assert [c['test_id'] for c in cases] == [c['test_id'] for c in csv_rows]
assert [c['actual_digest'] for c in cases] == [c['actual_digest'] for c in csv_rows]
print(f'PASS: {len(listed)} payload file hashes; all 32 inputs, assertions, SQL statements and returned digests cross-checked. No finding closed.')
