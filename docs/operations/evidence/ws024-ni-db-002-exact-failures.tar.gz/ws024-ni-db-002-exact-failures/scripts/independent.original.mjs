import pg from '/private/tmp/ws024-corrected-candidate/ui/node_modules/pg/lib/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {openSecureConnection} from '/private/tmp/ws024-corrected-candidate/ui/lib/edge/security/connection.ts';
import {createModelBRoute} from '/private/tmp/ws024-corrected-candidate/ui/lib/edge/security/route.ts';
const file=p=>{let s=readFileSync('/private/tmp/ws024-corrected-candidate/'+p,'utf8');return p.endsWith('network-intelligence-security.sql')?s.replace(/^create role .*;$/gm,''):s;};
const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const token='PUBLIC-SYNTHETIC-BEARER-0000000000000001';
const admin=new pg.Client({host:'127.0.0.1',port:56832,user:'postgres',database:'postgres'});await admin.connect();
await admin.query('create database ni_disposable_independent');await admin.end();
const client=new pg.Client({host:'127.0.0.1',port:56832,user:'postgres',database:'ni_disposable_independent'});await client.connect();
const db={exec:sql=>client.query(sql),query:(s,v)=>client.query(s,v)};
 await db.exec(`create table public.tracekit_organizations(id uuid primary key);`);
 await db.exec(file('supabase/migrations/20261004204330_edge_intelligence_v1_ingestion.sql'));
 await db.exec(file('supabase/migrations/20261004204342_edge_intelligence_multitenant_delivery.sql'));
 await db.exec(file('docs/operations/prepared/network-intelligence-security.sql'));
 // Separate command: the function-local SET clause is not a statement timer.
 await db.exec("set statement_timeout='8s';set lock_timeout='2s';set idle_in_transaction_session_timeout='10s'");
 await db.exec(`insert into tracekit_organizations values('${id(2)}'),('${id(22)}');
 insert into edge_intelligence_service_credentials(id,label,token_hash) values('${id(4)}','synthetic',encode(sha256(convert_to('${token}','UTF8')),'hex'));
 insert into edge_intelligence_tenant_bindings(tenant_ref,organization_id,environment,binding_epoch,approval_ref,approved_by) values('tenant_test0001','${id(2)}','test','${id(3)}','synthetic','controller');
 insert into ni_security.grants(id,credential_id,environment,tenant_ref,organization_id,binding_epoch,status,valid_from,approval_ref,approved_by) values('${id(5)}','${id(4)}','test','tenant_test0001','${id(2)}','${id(3)}','active','2020-01-01Z','synthetic','controller');
 insert into ni_security.audit_streams(id) values('${id(15)}');insert into ni_security.admission values('test','${id(15)}',clock_timestamp(),true);`);
const payload=(revision=1)=>({schemaVersion:'1.0',observationId:'obs_test0001',tenantRef:'tenant_test0001',revision,...(revision>1?{previousRevision:revision-1}:{}),semanticsVersion:'m23-v1',derivationRuleVersion:'hybrid-derived-v1',sessionRef:'session_test0001',observedAt:'2026-10-17T00:00:00.000000Z',updatedAt:'2026-10-17T00:00:00.000000Z',status:'PARTIAL',completedStages:[],pendingStages:[],intelligence:{},evidence:[],conflicts:[],explanations:[],errors:[]});
async function ingest(p=payload(),overrides={}){
 await db.exec('set role ni_delivery_executor');try{return (await db.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text) as result',[overrides.token??token,overrides.environment??'test',overrides.tenant??'tenant_test0001',overrides.epoch??id(3),overrides.delivery??id(6+p.revision),JSON.stringify(p)])).rows[0].result;}finally{await db.exec('reset role');}
}
const results=[];const check=(name,ok,detail={})=>{const r={name,status:ok?'PASS':'FAIL',...detail};results.push(r);console.log(JSON.stringify(r));};
const tables=['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams'];
async function snapshot(){let s={};for(const t of tables)s[t]=(await client.query('select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),\'[]\'::jsonb) s from '+t+' x')).rows[0].s;return JSON.stringify(s);}
async function attempt(name,fn,expected){let e;try{await fn();}catch(x){e=x;}check(name,!!e&&(!expected||e.code===expected),{sqlstate:e?.code??'00000',message:e?.message??'accepted'});}
const original='/Users/nomadm/Projects/tracekit-ws024-security-review/docs/operations/evidence/ws024-native-completion/';
const exactSql=readFileSync(original+'digest-vectors.sql','utf8').split('\n').filter(x=>x.includes("'negative'"));
check('original 32 invalid-record SQL statements recovered',exactSql.length===32);
for(const sql of exactSql)await attempt('original '+sql.match(/'negative','([^']+)'/)[1],()=>client.query(sql));
const vectors=JSON.parse(readFileSync(original+'vectors.json','utf8'));
for(const v of vectors.invalid.filter(x=>x.id.startsWith('timestamp-invalid')))await attempt(v.id,()=>client.query('select ni_security.normalize_state(jsonb_build_object(\'updated_at\',$1::text))',[v.input]));
for(const v of vectors.invalid.filter(x=>'input_json'in x)){const r=await client.query('select ni_security.raw_json_valid($1) valid',[v.input_json]);check(v.id,r.rows[0].valid===false,{actual:r.rows[0].valid});}
check('SQL NULL raw rejection',(await client.query('select ni_security.raw_json_valid(null) valid')).rows[0].valid===false);
let before=await snapshot();
async function rawIngest(raw){await client.query('set role ni_delivery_executor');try{return await client.query('select ni_security.ingest($1,$2,$3,$4,$5,$6)',[token,'test','tenant_test0001',id(3),id(80),raw]);}finally{await client.query('reset role');}}
for(const v of vectors.invalid.filter(x=>'input_json'in x))await attempt('persisted original '+v.id,()=>rawIngest(v.input_json),'22023');
await attempt('persisted SQL NULL',()=>rawIngest(null),'22023');
for(const v of vectors.invalid.filter(x=>x.id.startsWith('timestamp-invalid'))){let p=payload();p.observedAt=v.input;await attempt('persisted '+v.id,()=>rawIngest(JSON.stringify(p)),'22023');}
check('all original persisted negatives leave seven-table exact snapshot unchanged',before===await snapshot());
for(const setting of ['0','9s']){await client.query("set statement_timeout='"+setting+"'");await attempt('direct executor deadline '+setting,()=>rawIngest(JSON.stringify(payload())),'55000');}
await client.query("set statement_timeout='8s'");
await client.query('create function public.ind_delay() returns trigger language plpgsql as $$begin perform pg_sleep(9);return new;end$$;create trigger ind_delay before insert on ni_security.outbox for each row execute function public.ind_delay()');
before=await snapshot();let start=performance.now();await attempt('independent direct RPC outbox cancellation',()=>rawIngest(JSON.stringify(payload())),'57014');check('direct RPC cancellation window',performance.now()-start>=7000&&performance.now()-start<9000,{elapsed_ms:performance.now()-start});check('direct cancellation exact rollback including audit sequence/digest',before===await snapshot());
await client.query('drop trigger ind_delay on ni_security.outbox');
await client.query("create role ws024_native_executor login password 'PUBLIC-SYNTHETIC-LOCAL-ONLY';grant ni_delivery_executor to ws024_native_executor");
const config={host:'localhost',port:56832,database:'ni_disposable_independent',user:'ws024_native_executor',password:'PUBLIC-SYNTHETIC-LOCAL-ONLY',ca:readFileSync('/private/tmp/ws024-native-server.crt','utf8'),environment:'test',telemetryApprovalRef:'synthetic-independent'};
const request=()=>new Request('https://synthetic.test/api/edge/intelligence-v1',{method:'POST',headers:{authorization:'Bearer '+token,'TraceKit-Authorization-Contract':'NI-AUTH-001/Model-B/v1','TraceKit-Environment':'test','TraceKit-Tenant-Ref':'tenant_test0001','TraceKit-Binding-Epoch':id(3),'TraceKit-Delivery-Id':id(81)},body:JSON.stringify(payload())});
await client.query('create trigger ind_delay before insert on ni_security.outbox for each row execute function public.ind_delay()');
let connection,queries=[];const handler=createModelBRoute({enabled:true,environment:'test',authenticateUnversioned:async()=>false,log:()=>{},open:async()=>{connection=await openSecureConnection(config);return {...connection,query:async(s,v)=>{queries.push(s);return connection.query(s,v);}};}});
before=await snapshot();start=performance.now();const response=await handler(request());const elapsed=performance.now()-start;check('real TLS adapter timeout HTTP 503',response.status===503,{elapsed_ms:elapsed,body:await response.json(),queries});check('real adapter cancellation window',elapsed>=7000&&elapsed<10000);check('real adapter zero partial writes and sequence/digest unchanged',before===await snapshot());await attempt('real adapter disposed connection',()=>connection.query('select 1',[]),'CONNECTION_CLOSED');
await client.query('drop trigger ind_delay on ni_security.outbox');
const secure=await openSecureConnection(config,undefined,600);await secure.query('begin',[]);before=await snapshot();start=performance.now();await attempt('real adapter watchdog closes transaction',()=>secure.query('select pg_sleep(2)',[]),'TRANSPORT');check('watchdog elapsed',performance.now()-start<1500,{elapsed_ms:performance.now()-start});await new Promise(r=>setTimeout(r,250));check('watchdog rollback snapshot',before===await snapshot());await secure.dispose();
// Persistent-session lock ordering: ingestion locks grant before controller revocation.
const i=new pg.Client({host:'127.0.0.1',port:56832,user:'postgres',database:'ni_disposable_independent'}),c=new pg.Client({host:'127.0.0.1',port:56832,user:'postgres',database:'ni_disposable_independent'});await i.connect();await c.connect();await i.query("set statement_timeout='8s'");await i.query('begin');await i.query('set local role ni_delivery_executor');await i.query('select ni_security.ingest($1,$2,$3,$4,$5,$6)',[token,'test','tenant_test0001',id(3),id(82),JSON.stringify(payload())]);await c.query('begin');await c.query('set local role ni_authorization_controller');const cp=(await c.query('select pg_backend_pid() pid')).rows[0].pid;const revoke=c.query('select ni_security.revoke_grant($1,$2,$3)',[id(5),'independent','test']);await new Promise(r=>setTimeout(r,100));const blocking=(await client.query('select pg_blocking_pids($1) pids',[cp])).rows[0].pids;check('ingestion-first observed controller lock blocking',blocking.length>0,{blocking});await i.query('commit');await revoke;await c.query('commit');await i.end();await c.end();before=await snapshot();await attempt('post-revocation direct RPC denied',()=>rawIngest(JSON.stringify(payload())),'42501');check('post-revocation exact historical preservation',before===await snapshot());
const integrity=(await client.query("select count(*)::int n from (select *,lag(record_digest,1,repeat('0',64)) over(partition by stream_id order by sequence) prev,row_number() over(partition by stream_id order by sequence) seq from ni_security.audit_events) a full join ni_security.outbox o on o.event_id=a.id where a.id is null or o.event_id is null or a.previous_digest<>a.prev or a.sequence<>a.seq or o.sequence<>a.sequence or o.event_digest<>a.record_digest or a.record_digest<>ni_security.digest(case when a.body?'actor_ref' then 'authorization_audit' else 'observation_audit' end,a.body)")).rows[0].n;check('audit chain and outbox native integrity',integrity===0,{mismatches:integrity});
before=await snapshot();await client.query(file('docs/operations/prepared/network-intelligence-pause.sql'));await attempt('safe-pause executor denial',()=>rawIngest(JSON.stringify(payload())),'42501');await client.query('set role service_role');await attempt('safe-pause historical delete denied',()=>client.query('delete from edge_intelligence_observations'),'42501');await client.query('reset role');check('safe-pause exact preservation',before===await snapshot());
writeFileSync(new URL('independent-results.json',import.meta.url),JSON.stringify(results,null,2));await client.end();
