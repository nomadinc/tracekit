-- Disposable-only structural setup, not executed by the handoff replay.
create role service_role nologin bypassrls;
create role anon;
create role authenticated;
create role authenticator;
create table public.tracekit_organizations(id uuid primary key);
