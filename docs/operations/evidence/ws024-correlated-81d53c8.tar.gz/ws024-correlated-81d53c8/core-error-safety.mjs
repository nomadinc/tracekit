import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
import {randomUUID,createHash} from 'node:crypto';
const root=process.env.NI_CANDIDATE_ROOT,pg=createRequire(root+'/ui/package.json')('pg');
const {openSecureConnection}=await import(root+'/ui/lib/edge/security/connection.ts');
const {deliverCore}=await import(root+'/ui/lib/edge/security/core.ts');
const {observePgWire}=await import(root+'/ui/scripts/ni-db001-wire-observer.mjs');
const {disposableTarget}=await import(root+'/ui/scripts/ni-db001-deadline-probe.mjs');
const observer=new pg.Client({connectionString:disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE)});await observer.connect();
const config={host:process.env.NI_TLS_HOST,port:Number(process.env.NI_TLS_PORT),database:process.env.NI_TLS_DATABASE,user:process.env.NI_TLS_USER,password:process.env.NI_TLS_PASSWORD,ca:readFileSync(process.env.NI_TLS_CA_FILE,'utf8'),environment:'test',telemetryApprovalRef:process.env.NI_TLS_TELEMETRY_APPROVAL_REF};
const tables=['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams','ni_security.grants','edge_intelligence_tenant_bindings','edge_intelligence_service_credentials'];
const snapshot=async()=>{const rows={};for(const t of tables)rows[t]=(await observer.query("select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb)::text body from "+t+' t')).rows[0].body;return rows;};
let connection,detach,pid;const events=[],loop=monitorEventLoopDelay({resolution:10});loop.enable();
try{
 const before=await snapshot();
 connection=await openSecureConnection(config,options=>{
  const client=new pg.Client(options),connect=client.connect.bind(client),end=client.end.bind(client);
  client.connect=async()=>{await connect();pid=client.processID;detach=observePgWire(client,e=>events.push(e));events.push({event:'tls-connected',pid,tlsAuthorized:client.connection.stream.authorized===true,atWall:new Date().toISOString(),atMono:performance.now()});};
  client.end=async()=>{events.push({event:'adapter-end-requested',pid,atWall:new Date().toISOString(),atMono:performance.now()});return end();};return client;
 });
 const backend=(await observer.query('select a.pid,a.backend_start::text,a.application_name,a.usename,s.ssl,s.version,s.cipher from pg_stat_activity a join pg_stat_ssl s using(pid) where a.pid=$1',[pid])).rows[0];
 const source=readFileSync(root+'/ui/scripts/ni-db001-tls-probe.mjs','utf8');const payload=Function('return '+source.split('const payload=')[1].split(';\n')[0])();
 const bearer='PUBLIC-SYNTHETIC-BEARER-0000000000000001';
 const request=new Request('https://synthetic.test',{method:'POST',headers:{authorization:'Bearer '+bearer,'TraceKit-Authorization-Contract':'NI-AUTH-001/Model-B/v1','TraceKit-Environment':'test','TraceKit-Tenant-Ref':'tenant_test0001','TraceKit-Binding-Epoch':'00000000-0000-4000-8000-000000000003','TraceKit-Delivery-Id':randomUUID()},body:JSON.stringify(payload)});
 const sentWall=new Date().toISOString(),start=performance.now();const response=await deliverCore(request,connection,'test',true);const callbackMs=performance.now(),callbackWall=new Date().toISOString();
 const serialized=JSON.stringify(response),credentialSafe=![bearer,config.password,'ni_security.ingest','obs_deadline_probe'].some(v=>serialized.includes(v));
 let commitDenied=false,reuseDenied=false,commitCode,reuseCode;
 try{await connection.query('commit',[]);}catch(e){commitDenied=true;commitCode=e.code;}
 try{await connection.query('select 1',[]);}catch(e){reuseDenied=true;reuseCode=e.code;}
 await connection.dispose();const disposedAt={wall:new Date().toISOString(),mono:performance.now()};
 const backendAbsent=(await observer.query('select 1 from pg_stat_activity where pid=$1',[pid])).rows.length===0;
 const absenceObservedAt={wall:new Date().toISOString(),mono:performance.now()};
 const after=await snapshot(),unchanged=JSON.stringify(before)===JSON.stringify(after),cancellationObserved=events.some(e=>e.event==='backend-error'&&e.sqlstate==='57014');
 const elapsedMs=callbackMs-start;
 const result={candidate:process.env.NI_CANDIDATE_SHA,backend,sentWall,callbackWall,callbackMs,elapsedMs,response:credentialSafe?response:{credentialSafe:false,responseSha256:createHash('sha256').update(serialized).digest('hex')},credentialSafe,commitDenied,commitCode,reuseDenied,reuseCode,disposedAt,backendAbsent,absenceObservedAt,unchanged,before,after,cancellationObserved,eventLoopMaxMs:loop.max/1e6,eventLoopP99Ms:loop.percentile(99)/1e6,events,pass:response.status===503&&credentialSafe&&commitDenied&&reuseDenied&&backendAbsent&&unchanged&&cancellationObserved&&elapsedMs>=7000&&elapsedMs<9000};
 writeFileSync(new URL('core-error-safety.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({pass:result.pass,elapsedMs,cancellationObserved,credentialSafe,unchanged}));process.exitCode=result.pass?0:1;
}finally{await connection?.dispose();detach?.();loop.disable();await observer.end();}
