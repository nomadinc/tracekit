import { canonical, ContractError, digest, normalizeTimestamp, verifySignature, type ExactValue } from './integrity.ts';
import { normalizeRecord } from './manifests.ts';
export const CONTRACT='NI-AUTH-001/Model-B/v1';
export type Envelope={contract:string;environment:string;tenantRef:string;bindingEpoch:string;deliveryId:string};
export function envelope(headers:Headers,payloadTenant:unknown):Envelope {
 const names=['TraceKit-Authorization-Contract','TraceKit-Environment','TraceKit-Tenant-Ref','TraceKit-Binding-Epoch','TraceKit-Delivery-Id'];
 const values=names.map(k=>headers.get(k));if(values.some(v=>!v||v.includes(',')||v!==v.trim()))throw new ContractError('ENVELOPE');
 const [contract,environment,tenantRef,bindingEpoch,deliveryId]=values as string[];
 if(contract!==CONTRACT||!/^[a-z][a-z0-9_-]{0,31}$/.test(environment)||!/^tenant_[A-Za-z0-9_-]{8,128}$/.test(tenantRef)||tenantRef!==payloadTenant||![bindingEpoch,deliveryId].every(x=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(x)))throw new ContractError('ENVELOPE');
 return {contract,environment,tenantRef,bindingEpoch,deliveryId};
}
export function classify(status:number,outcome?:string):'ack'|'retry'|'quarantine'{
 if(status===201&&outcome==='accepted'||status===200&&['duplicate','stale'].includes(outcome??''))return 'ack';
 if([408,429].includes(status)||status>=500||status<400)return 'retry';return 'quarantine';
}
export function retryDelay(attempts:number,first:number,now:number,jitter:number,retryAfterMs=0):number|null{
 const bases=[5000,15000,45000,120000,300000,600000,900000];
 if(!Number.isInteger(attempts)||attempts<1||attempts>=8||!Number.isFinite(jitter)||jitter<0||jitter>1||!Number.isFinite(retryAfterMs)||retryAfterMs<0)return null;
 const delay=Math.ceil(Math.max(bases[attempts-1]*(0.8+0.4*jitter),retryAfterMs));return now+delay>first+3600000?null:delay;
}
export function sourceEvidence(observation:Record<string,ExactValue>):Record<string,ExactValue>{
 const names=['environment','organization_id','tenant_ref','binding_epoch','observation_id','revision','previous_revision','schema_version','semantics_version','derivation_rule_version','session_ref','event_ref','observed_at','updated_at_source','completed_at_source','status','payload','digest_version'];
 return normalizeRecord('source_evidence',Object.fromEntries(names.map(k=>[k,observation[k]])));
}
export const sameSource=(a:Record<string,ExactValue>,b:Record<string,ExactValue>)=>canonical(sourceEvidence(a))===canonical(sourceEvidence(b));
export type Trust={environment:string;destinationId:string;purpose:'audit'|'quarantine';keyId:string;version:number;publicKeyHex:string;activeFrom:string;activeUntil:string;revoked:boolean};
export type ReceiptExpectation={environment:string;destinationId:string;streamId?:string;sequence?:bigint;eventDigest?:string;previousReceiptDigest?:string;deliveryId?:string;entryId?:string;envelopeDigest?:string;payloadDigest?:string;kind?:string};
/** Call only with a pinned, independently administered registry snapshot, never receipt-supplied trust. */
export function verifyReceipt(input:Record<string,ExactValue>,trust:Trust,expected:ReceiptExpectation,now:string):string{
 const purpose=trust.purpose,r=normalizeRecord(purpose==='audit'?'independent_receipt':'quarantine_receipt',input);
 const str=(k:string)=>String(r[k]);const epoch=(s:string)=>Date.parse(normalizeTimestamp(s));
 const durable=epoch(str('durable_at'));
 if(trust.revoked||str('key_id')!==trust.keyId||str('key_version')!==String(trust.version)||str('environment')!==trust.environment||trust.environment!==expected.environment||str('destination_id')!==trust.destinationId||trust.destinationId!==expected.destinationId||durable<epoch(trust.activeFrom)||durable>=epoch(trust.activeUntil)||durable>epoch(now)+60000)throw new ContractError('RECEIPT');
 if(purpose==='audit'){
  if(str('receipt_version')!=='NI-AUDIT-RECEIPT-v1'||str('contract_version')!==CONTRACT||str('receipt_kind')!==expected.kind||str('stream_id')!==expected.streamId||str('sequence')!==String(expected.sequence)||str('event_digest')!==expected.eventDigest||str('previous_receipt_digest')!==expected.previousReceiptDigest)throw new ContractError('RECEIPT');
 }else if(str('receipt_version')!=='NI-QUARANTINE-RECEIPT-v1'||str('delivery_id')!==expected.deliveryId||str('entry_id')!==expected.entryId||str('envelope_digest')!==expected.envelopeDigest||str('payload_digest')!==expected.payloadDigest)throw new ContractError('RECEIPT');
 const {signature,...unsigned}=r;if(!verifySignature(trust.publicKeyHex,String(signature),purpose,unsigned))throw new ContractError('RECEIPT');return digest(purpose==='audit'?'independent_receipt':'quarantine_receipt',r);
}
