import {ContractError,canonical,digest,type ExactValue} from './integrity.ts';
import {verifyReceipt,type Trust,type ReceiptExpectation,type Envelope} from './contracts.ts';

export type DurablePark={id:string;envelope:Envelope;payloadDigest:string;attempts:number;firstAttemptAt:string;version:number;state:'parked'|'quarantined'|'replay_authorized'};
export interface ParkingStore {
 insertImmutable(record:DurablePark):Promise<void>;
 getForReconciliation(id:string):Promise<DurablePark|null>;
 compareAndSet(id:string,version:number,nextState:'quarantined'|'replay_authorized',evidence:Record<string,ExactValue>):Promise<boolean>;
}
/** Independent verifier integration remains disabled until destinations/registry and role custody are approved. */
export class GovernedRecovery {
 private readonly store:ParkingStore;
 private readonly enabled:boolean;
 constructor(store:ParkingStore,enabled=false){this.store=store;this.enabled=enabled;}
 async quarantineReceipt(id:string,receipt:Record<string,ExactValue>,trust:Trust,expected:ReceiptExpectation,now:string):Promise<boolean>{
  if(!this.enabled)throw new ContractError('RECOVERY_DISABLED');
  const record=await this.store.getForReconciliation(id);if(!record||record.state!=='parked'||trust.purpose!=='quarantine')throw new ContractError('PARK_STATE');
  const original=record.envelope;
  const context={'TraceKit-Authorization-Contract':original.contract,'TraceKit-Environment':original.environment,'TraceKit-Tenant-Ref':original.tenantRef,'TraceKit-Binding-Epoch':original.bindingEpoch,'TraceKit-Delivery-Id':original.deliveryId};
  if(expected.environment!==original.environment||expected.deliveryId!==original.deliveryId||expected.envelopeDigest!==digest('delivery_envelope',context)||expected.payloadDigest!==record.payloadDigest)throw new ContractError('RECEIPT');
  const receiptDigest=verifyReceipt(receipt,trust,expected,now);
  return this.store.compareAndSet(id,record.version,'quarantined',{receipt_digest:receiptDigest,receipt});
 }
 async authorizeReplay(id:string,approval:{id:string;actor:string;originalEnvelope:Envelope},freshAuthorization:(scope:Envelope)=>Promise<boolean>):Promise<boolean>{
  if(!this.enabled)throw new ContractError('RECOVERY_DISABLED');
  const record=await this.store.getForReconciliation(id);
  if(!record||!['parked','quarantined'].includes(record.state)||!approval.id||!approval.actor||canonical(approval.originalEnvelope)!==canonical(record.envelope)||!await freshAuthorization(record.envelope))throw new ContractError('REPLAY_DENIED');
  // Only records an approval. It cannot publish/redeliver, alter original context, or reset a retry budget.
  return this.store.compareAndSet(id,record.version,'replay_authorized',{approval_id:approval.id,actor:approval.actor,original_envelope:record.envelope});
 }
}
