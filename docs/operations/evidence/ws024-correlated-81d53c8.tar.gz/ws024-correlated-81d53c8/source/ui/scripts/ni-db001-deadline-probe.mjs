// Disposable, synthetic, read-only diagnostics. No production connection fallback.
import pg from 'pg';
import {observePgWire} from './ni-db001-wire-observer.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
import {pathToFileURL} from 'node:url';
export function strictDeadlineVerdict({sqlstate,elapsedMs,abortedSqlstate}){
 return sqlstate==='57014'&&abortedSqlstate==='25P02'&&elapsedMs>=7000&&elapsedMs<9000;
}
export function disposableTarget(raw,ack){
 const target=new URL(raw);
 if(ack!=='synthetic-only'||target.search||!['localhost','127.0.0.1','[::1]'].includes(target.hostname)||!/^\/ni_disposable_[a-z0-9_]+$/.test(target.pathname))throw new Error('DISPOSABLE_TARGET_REQUIRED');
 return raw;
}
export async function run(){
 const connectionString=disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE);
 const client=new pg.Client({connectionString}),observer=new pg.Client({connectionString});
 const results=[];const wire=[];const runId=process.env.NI_DIAGNOSTIC_RUN_ID??randomUUID();if(!/^[a-zA-Z0-9_-]{1,64}$/.test(runId))throw new Error('RUN_ID');let connected=false,detach;
 try{
  await client.connect();connected=true;detach=observePgWire(client,event=>wire.push(event));await observer.connect();
  const meta=(await client.query("select pg_backend_pid() pid,version() version,current_database() database,current_setting('server_version_num') server_version,(select backend_start::text from pg_stat_activity where pid=pg_backend_pid()) backend_start")).rows[0];
  const literal=readFileSync(new URL('../tests/fixtures/network-security/ws024-literal-query.original.sql',import.meta.url),'utf8');
  const vectors=JSON.parse(readFileSync(new URL('../tests/fixtures/network-security/vectors.json',import.meta.url),'utf8'));
  const v=vectors.records.find(v=>v.record_type==='authorization_audit');
  const decode=x=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===1&&x.exact_json_number_token?x.exact_json_number_token:Array.isArray(x)?'['+x.map(decode).join(',')+']':x&&typeof x==='object'?'{'+Object.entries(x).map(([k,y])=>JSON.stringify(k)+':'+decode(y)).join(',')+'}':JSON.stringify(x);
  const probes=[
   {id:'original-literal-cold',text:literal,values:[],golden:true},
   {id:'same-input-parameterized',text:"select encode(convert_to(ni_security.canonical($1::jsonb),'UTF8'),'hex')=$2 canonical_pass,ni_security.digest($3,$1::jsonb)=$4 digest_pass",values:[decode(v.input),v.canonical_hex,v.record_type,v.sha256],golden:true},
   {id:'original-literal-warm',text:literal,values:[],golden:true},
   {id:'prearmed-literal-sleep',text:'select pg_sleep(9)',values:[],cancel:true},
   {id:'prearmed-parameterized-sleep',text:'select pg_sleep($1)',values:[9],cancel:true},
   // Negative control: changing a GUC inside an already running statement is not timer arming.
   {id:'same-command-setting-control',text:"with armed as materialized (select set_config('statement_timeout','8s',true)) select pg_sleep(9) from armed",values:[],sameCommand:true}
  ];
  for(const [probeIndex,probe] of probes.entries()){
   const applicationName='ni-db001-'+runId.slice(0,12)+'-'+probeIndex;
   await client.query("select set_config('application_name',$1,false)",[applicationName]);
   await client.query('begin read only');await client.query('set local role ni_integrity_writer');
   await client.query("set local lock_timeout='2s'");
   await client.query("set local statement_timeout='"+(probe.sameCommand?'0':'8s')+"'");
   const settings=(await client.query("select current_setting('statement_timeout') statement_timeout,current_setting('lock_timeout') lock_timeout")).rows[0];
   const loop=monitorEventLoopDelay({resolution:10});loop.enable();
   const samples=[];const observerEnabled=process.env.NI_DEADLINE_OBSERVER!=='off';let done=false,observerError;
   // The observer captures no SQL text, arguments, credentials or payloads.
   const sampling=(async()=>{while(observerEnabled&&!done){try{
    await observer.query('select pg_stat_clear_snapshot()');
    const state=(await observer.query("select clock_timestamp()::text server_at,query_start::text statement_start,backend_start::text backend_start,state,wait_event_type,wait_event,extract(epoch from (clock_timestamp()-query_start))*1000 query_age_ms from pg_stat_activity where pid=$1",[meta.pid])).rows[0];
    if(state)samples.push({clientMs:performance.now(),...state});
   }catch(error){observerError=error.code??'OBSERVER_FAILED';break;}
   if(!done)await new Promise(resolve=>setTimeout(resolve,100));}})();
   const wireStart=wire.length;const sentWall=new Date().toISOString();const start=performance.now();let sqlstate='00000',rows,errorCategory,abortedSqlstate;
   try{rows=(await client.query({text:probe.text,values:probe.values})).rows;}
   catch(error){sqlstate=error.code??'TRANSPORT';errorCategory=sqlstate==='57014'?'STATEMENT_CANCELLED':'QUERY_FAILED';}
   const callbackMs=performance.now();const callbackWall=new Date().toISOString();const elapsedMs=callbackMs-start;done=true;await sampling;loop.disable();
   if(sqlstate!=='00000'){try{await client.query('select 1');}catch(error){abortedSqlstate=error.code;}}
   await client.query('rollback');
   const golden=rows?.[0]?.json_build_object??rows?.[0];
   const pass=probe.cancel?strictDeadlineVerdict({sqlstate,elapsedMs,abortedSqlstate}):probe.golden?sqlstate==='00000'&&golden?.canonical_pass===true&&golden?.digest_pass===true:sqlstate==='00000'&&elapsedMs>=9000;
   const result={id:probe.id,runId,applicationName,protocol:probe.values.length?'extended':'simple',observerEnabled,pass,sqlstate,elapsedMs,sentWall,callbackWall,callbackMs,wire:wire.slice(wireStart),abortedSqlstate,errorCategory,settings,observerError,eventLoopMaxMs:loop.max/1e6,eventLoopP99Ms:loop.percentile(99)/1e6,samples};
   results.push(result);console.log(JSON.stringify(result));
  }
  const report={runId,candidate:process.env.NI_CANDIDATE_SHA??'UNSPECIFIED',meta,results,pass:results.every(r=>r.pass)};
  writeFileSync(process.env.NI_DEADLINE_REPORT_PATH??'ni-db001-deadline-results.json',JSON.stringify(report,null,2)+'\n');
  process.exitCode=report.pass?0:1;
 }finally{detach?.();if(connected)await client.query('rollback').catch(()=>{});await Promise.allSettled([client.end(),observer.end()]);}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)run().catch(error=>{console.error(JSON.stringify({pass:false,code:error.code??'PROBE_FAILED'}));process.exitCode=1;});
