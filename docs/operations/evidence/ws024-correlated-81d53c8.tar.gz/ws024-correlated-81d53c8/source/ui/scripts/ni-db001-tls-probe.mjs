// Run with node --import tsx. Requires independently prepared synthetic TLS database.
import pg from 'pg';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';
import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
import {openSecureConnection} from '../lib/edge/security/connection.ts';
import {deliverCore} from '../lib/edge/security/core.ts';
import {observePgWire} from './ni-db001-wire-observer.mjs';
import {disposableTarget} from './ni-db001-deadline-probe.mjs';
const reports=[];let observer;
try{
 if(process.env.NI_TLS_DELAY_FIXTURE!=='installed-nine-second-outbox-delay'||process.env.NI_TLS_CORE_FIXTURE!=='approved-synthetic-modelb')throw new Error('SYNTHETIC_FIXTURE_ACK_REQUIRED');
 const connectionString=disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE);
 const observerUrl=new URL(connectionString);
 const config={host:process.env.NI_TLS_HOST??'',port:Number(process.env.NI_TLS_PORT??5432),database:process.env.NI_TLS_DATABASE??'',user:process.env.NI_TLS_USER??'',password:process.env.NI_TLS_PASSWORD??'',ca:readFileSync(process.env.NI_TLS_CA_FILE??'','utf8'),environment:'test',telemetryApprovalRef:process.env.NI_TLS_TELEMETRY_APPROVAL_REF??''};
 if(!['localhost','127.0.0.1','::1'].includes(config.host)||!/^ni_disposable_[a-z0-9_]+$/.test(config.database)||observerUrl.pathname!=='/'+config.database)throw new Error('DISPOSABLE_TARGET_REQUIRED');
 observer=new pg.Client({connectionString});await observer.connect();
 const snapshot=async()=>{const result={};for(const table of ['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams','ni_security.grants','edge_intelligence_tenant_bindings','edge_intelligence_service_credentials']){const row=(await observer.query("select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb)::text body from "+table+' t')).rows[0];result[table]=createHash('sha256').update(row.body).digest('hex');}return result;};
 for(const mode of ['literal-sleep','parameterized-sleep','core-ingestion']){
  const events=[];let backendPid,detach,connection;
  const before=await snapshot(),loop=monitorEventLoopDelay({resolution:10});loop.enable();
  try{
   // Factory preserves every actual production adapter option, including pinned TLS and timeouts.
   connection=await openSecureConnection(config,options=>{
    const client=new pg.Client(options),connect=client.connect.bind(client),end=client.end.bind(client);
    client.connect=async()=>{await connect();backendPid=client.processID;detach=observePgWire(client,event=>events.push(event));events.push({event:'connected',clientMs:performance.now(),clientWall:new Date().toISOString(),backendPid,tlsAuthorized:client.connection.stream.authorized===true});};
    client.end=async()=>{events.push({event:'adapter-end-requested',clientMs:performance.now(),clientWall:new Date().toISOString(),backendPid});return end();};
    return client;
   });
   events.push({event:'operation-start',clientMs:performance.now(),clientWall:new Date().toISOString(),backendPid});
   const start=performance.now();let sqlstate,status;
   if(mode==='core-ingestion'){
    // The independent harness must install a disposable nine-second outbox delay beforehand.
    const payload={schemaVersion:'1.0',observationId:'obs_deadline_probe',tenantRef:'tenant_test0001',revision:1,semanticsVersion:'m23-v1',derivationRuleVersion:'hybrid-derived-v1',sessionRef:'session_test0001',observedAt:'2026-10-17T00:00:00.000001Z',updatedAt:'2026-10-17T00:00:00.000001Z',status:'PARTIAL',completedStages:[],pendingStages:[],intelligence:{},evidence:[],conflicts:[],explanations:[],errors:[]};
    const request=new Request('https://synthetic.test',{method:'POST',headers:{authorization:'Bearer PUBLIC-SYNTHETIC-BEARER-0000000000000001','TraceKit-Authorization-Contract':'NI-AUTH-001/Model-B/v1','TraceKit-Environment':'test','TraceKit-Tenant-Ref':'tenant_test0001','TraceKit-Binding-Epoch':'00000000-0000-4000-8000-000000000003','TraceKit-Delivery-Id':randomUUID()},body:JSON.stringify(payload)});
    const response=await deliverCore(request,connection,'test',true);status=response.status;
   }else{
    await connection.query('begin',[]);await connection.query("set local statement_timeout='8s'",[]);await connection.query("set local lock_timeout='2s'",[]);
    try{await connection.query(mode==='literal-sleep'?'select pg_sleep(9)':'select pg_sleep($1)',mode==='literal-sleep'?[]:[9]);sqlstate='00000';}catch(error){sqlstate=/^[0-9A-Z]{5}$/.test(error.code??'')?error.code:'SANITIZED_TRANSPORT';}
   }
   const elapsedMs=performance.now()-start;
   events.push({event:'operation-callback',clientMs:performance.now(),clientWall:new Date().toISOString(),backendPid});
   // Any error must make the adapter terminal, preventing a queued late COMMIT.
   let commitDenied=false;try{await connection.query('commit',[]);}catch{commitDenied=true;}
   await connection.dispose();
   const rollbackProbeStart=performance.now();let backendPresent=true;
   while(backendPresent&&performance.now()-rollbackProbeStart<2000){backendPresent=(await observer.query('select 1 from pg_stat_activity where pid=$1',[backendPid])).rows.length>0;if(backendPresent)await new Promise(resolve=>setTimeout(resolve,50));}
   const after=await snapshot(),unchanged=JSON.stringify(before)===JSON.stringify(after);
   const cancellationObserved=events.some(event=>event.event==='backend-error'&&event.sqlstate==='57014');
   // Report failures, including client-only timeout/disposal, rather than relabeling them server cancellation.
   const pass=elapsedMs>=7000&&elapsedMs<9000&&commitDenied&&!backendPresent&&unchanged&&cancellationObserved&&(mode==='core-ingestion'?status===503:sqlstate==='57014');
   reports.push({mode,pass,backendPid,elapsedMs,sqlstate,status,commitDenied,backendPresent,unchanged,before,after,cancellationObserved,eventLoopMaxMs:loop.max/1e6,events});
  }catch(error){reports.push({mode,pass:false,backendPid,code:/^[0-9A-Z_]{3,64}$/.test(error.code??'')?error.code:'PROBE_FAILED',events});}
  finally{await connection?.dispose();detach?.();loop.disable();}
 }
}catch(error){reports.push({pass:false,code:/^[0-9A-Z_]{3,64}$/.test(error.code??'')?error.code:'PROBE_FAILED'});}
finally{await observer?.end();writeFileSync(process.env.NI_TLS_REPORT_PATH??'ni-db001-tls-results.json',JSON.stringify({candidate:process.env.NI_CANDIDATE_SHA??'UNSPECIFIED',reports},null,2)+'\n');process.exitCode=reports.length===3&&reports.every(r=>r.pass)?0:1;}
