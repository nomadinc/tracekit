// Read disposable PostgreSQL JSON logs. Emit only correlation fields, never raw messages/context.
import {readFileSync,writeFileSync} from 'node:fs';
const input=process.env.NI_PG_JSON_LOG,output=process.env.NI_PG_CORRELATION_PATH;
if(!input||!output)throw new Error('PATHS_REQUIRED');
const events=[];
for(const line of readFileSync(input,'utf8').split('\n')){
 if(!line.trim())continue;let row;try{row=JSON.parse(line);}catch{continue;}
 const timeout=row.error_severity==='ERROR'&&row.state_code==='57014'&&row.message==='canceling statement due to statement timeout';
 const marker=/^NI_DB001_(START|CANCEL) pid=([0-9]+) statement_start=([0-9T:.+ Z-]+) backend_at=([0-9T:.+ Z-]+)$/.exec(row.message??'');
 if(!timeout&&!marker)continue;
 events.push({serverLogTimestamp:row.timestamp,backendPid:row.pid,sessionId:row.session_id,applicationName:row.application_name,event:timeout?'STATEMENT_TIMEOUT':marker[1],sqlstate:row.state_code,statementStart:marker?.[3],backendAt:marker?.[4]});
}
writeFileSync(output,JSON.stringify({events,limitations:'Markers are diagnostic fixture execution times; unwrapped query starts require matching pg_stat_activity observations. Missing events are not passing timing evidence.'},null,2)+'\n');
if(!events.length)process.exitCode=1;
