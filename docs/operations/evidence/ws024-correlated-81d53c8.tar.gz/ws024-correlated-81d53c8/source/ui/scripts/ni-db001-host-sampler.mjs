// Run separately on the disposable host AND container. No database access or secret reads.
import {readFileSync,appendFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
const output=process.env.NI_HOST_REPORT_PATH;
if(!output||!/^[a-zA-Z0-9_-]{1,64}$/.test(process.env.NI_DIAGNOSTIC_RUN_ID??''))throw new Error('OUTPUT_AND_RUN_ID_REQUIRED');
const files=['/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/memory.events','/proc/pressure/cpu','/proc/pressure/memory','/proc/pressure/io'];
let last=performance.now();
const timer=setInterval(()=>{
 const now=performance.now(),stats={};
 for(const path of files){try{stats[path]=readFileSync(path,'utf8');}catch{stats[path]='UNAVAILABLE';}}
 appendFileSync(output,JSON.stringify({runId:process.env.NI_DIAGNOSTIC_RUN_ID,wall:new Date().toISOString(),monotonicMs:now,sampleGapMs:now-last,resourceUsage:process.resourceUsage(),stats})+'\n');last=now;
},100);
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{clearInterval(timer);process.exitCode=0;});
