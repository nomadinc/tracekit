// Diagnostics only: never retain packet bytes, SQL text, parameters or raw error messages.
import {performance} from 'node:perf_hooks';
export function observePgWire(client,emit){
 const connection=client.connection,stream=connection?.stream;
 if(!connection?.on||!stream?.on||typeof stream.write!=='function')throw new Error('WIRE_UNAVAILABLE');
 const record=(event,fields={})=>{try{emit({event,clientMs:performance.now(),clientWall:new Date().toISOString(),backendPid:client.processID,...fields});}catch{/* Diagnostics cannot interrupt driver operations. */}};
 const originalWrite=stream.write;
 function write(...args){record('transport-write',{bytes:typeof args[0]==='string'?Buffer.byteLength(args[0]):args[0]?.byteLength??null});return originalWrite.apply(this,args);}
 const onData=bytes=>record('transport-data',{bytes:bytes?.byteLength??null});
 const onError=error=>record('backend-error',{sqlstate:/^[0-9A-Z]{5}$/.test(error?.code)?error.code:'UNCLASSIFIED'});
 const onReady=message=>record('backend-ready',{transactionStatus:['I','T','E'].includes(message?.status)?message.status:'UNKNOWN'});
 const onClose=()=>record('transport-close');
 stream.write=write;
 if(stream.prependListener)stream.prependListener('data',onData);else stream.on('data',onData);
 stream.on('close',onClose);connection.on('errorMessage',onError);connection.on('readyForQuery',onReady);
 record('wire-attached',{tlsAuthorized:stream.authorized===true});
 return()=>{if(stream.write===write)stream.write=originalWrite;stream.off('data',onData);stream.off('close',onClose);connection.off('errorMessage',onError);connection.off('readyForQuery',onReady);};
}
