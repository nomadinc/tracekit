import test from 'node:test';
import assert from 'node:assert/strict';
import {strictDeadlineVerdict,disposableTarget} from '../scripts/ni-db001-deadline-probe.mjs';
test('strict deadline classifier preserves timing window and SQLSTATE requirements',()=>{
 assert(strictDeadlineVerdict({sqlstate:'57014',elapsedMs:8000,abortedSqlstate:'25P02'}));
 for(const sample of [{sqlstate:'57014',elapsedMs:9337.421333,abortedSqlstate:'25P02'},{sqlstate:'57014',elapsedMs:9000,abortedSqlstate:'25P02'},{sqlstate:'57014',elapsedMs:6999,abortedSqlstate:'25P02'},{sqlstate:'00000',elapsedMs:8000,abortedSqlstate:'25P02'},{sqlstate:'57014',elapsedMs:8000}])assert.equal(strictDeadlineVerdict(sample),false);
});
test('native diagnostics refuse remote, ambiguous and unacknowledged database targets',()=>{
 assert.equal(disposableTarget('postgresql://localhost/ni_disposable_probe','synthetic-only'),'postgresql://localhost/ni_disposable_probe');
 for(const raw of ['postgresql://production.example/ni_disposable_probe','postgresql://localhost/production','postgresql://localhost/ni_disposable_probe?host=production.example'])assert.throws(()=>disposableTarget(raw,'synthetic-only'));
 assert.throws(()=>disposableTarget('postgresql://localhost/ni_disposable_probe',''));
});

test('wire observer captures timing and codes without retaining SQL, credentials or buffers',async()=>{
 const {EventEmitter}=await import('node:events');const {observePgWire}=await import('../scripts/ni-db001-wire-observer.mjs');
 const stream=new EventEmitter(),connection=new EventEmitter(),events=[];connection.stream=stream;stream.authorized=true;
 const originalWrite=function(){return false;};stream.write=originalWrite;
 const detach=observePgWire({connection,processID:123},event=>events.push(event));
 assert.equal(stream.write(Buffer.from('SYNTHETIC-SECRET-SQL')),false);
 stream.emit('data',Buffer.from('SYNTHETIC-SECRET-RESPONSE'));
 connection.emit('errorMessage',{code:'57014',message:'SYNTHETIC-SECRET-ERROR',detail:'SYNTHETIC-SECRET-DETAIL'});
 connection.emit('readyForQuery',{status:'E'});stream.emit('close');
 assert(events.some(e=>e.event==='backend-error'&&e.sqlstate==='57014'));
 assert(events.some(e=>e.event==='backend-ready'&&e.transactionStatus==='E'));
 assert.doesNotMatch(JSON.stringify(events),/SYNTHETIC-SECRET/);assert(events.every(e=>e.backendPid===123&&Number.isFinite(e.clientMs)));
 detach();assert.equal(stream.write,originalWrite);assert.equal(stream.listenerCount('data'),0);assert.equal(connection.listenerCount('errorMessage'),0);
});

 test('server log extraction omits SQL, parameters and error context',async()=>{
 const {mkdtempSync,writeFileSync,readFileSync,rmSync}=await import('node:fs');
 const {tmpdir}=await import('node:os');const {join}=await import('node:path');const {execFileSync}=await import('node:child_process');
 const dir=mkdtempSync(join(tmpdir(),'ni-log-'));
 try{const input=join(dir,'input'),output=join(dir,'output');
 writeFileSync(input,JSON.stringify({timestamp:'2026-10-18 00:00:08 UTC',pid:123,session_id:'safe-session',application_name:'ni-db001-test',error_severity:'ERROR',state_code:'57014',message:'canceling statement due to statement timeout',statement:'SYNTHETIC-SECRET',context:'SYNTHETIC-SECRET',parameters:'SYNTHETIC-SECRET'})+'\n');
 execFileSync(process.execPath,[new URL('../scripts/ni-db001-server-log-extract.mjs',import.meta.url).pathname],{env:{...process.env,NI_PG_JSON_LOG:input,NI_PG_CORRELATION_PATH:output}});
 const text=readFileSync(output,'utf8');assert.doesNotMatch(text,/SYNTHETIC-SECRET/);assert.equal(JSON.parse(text).events[0].sqlstate,'57014');
 }finally{rmSync(dir,{recursive:true,force:true});}
 });
