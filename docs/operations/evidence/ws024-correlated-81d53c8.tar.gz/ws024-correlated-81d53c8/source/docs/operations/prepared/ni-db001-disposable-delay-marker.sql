-- DIAGNOSTIC FIXTURE ONLY. Never apply to production or automatic migration chains.
-- WS-024 installs this instead of its plain nine-second outbox delay in its isolated database.
-- No trigger is installed automatically. Keep unwrapped literal/parameterized controls unchanged.
create function public.ni_db001_disposable_delay_marker() returns trigger
language plpgsql set search_path='' as $$
begin
 raise log 'NI_DB001_START pid=% statement_start=% backend_at=%',pg_backend_pid(),statement_timestamp(),clock_timestamp();
 begin
  perform pg_sleep(9);
 exception when query_canceled then
  raise log 'NI_DB001_CANCEL pid=% statement_start=% backend_at=%',pg_backend_pid(),statement_timestamp(),clock_timestamp();
  raise;
 end;
 return new;
end $$;
revoke all on function public.ni_db001_disposable_delay_marker() from public;
-- Independent fixture owner installs/removes its chosen BEFORE INSERT outbox trigger.
