-- Safe rollback: stop new path; keep evidence, protected audit and old-path denial.
-- Disposable/review only. This is NOT a production operational command authorization.
begin;
revoke execute on function ni_security.ingest(text,text,text,uuid,uuid,text) from ni_delivery_executor;
revoke execute on function ni_security.create_grant(uuid,uuid,text,text,uuid,uuid,timestamptz,text,text),
 ni_security.revoke_grant(uuid,text,text),ni_security.disable_binding(text,text,text) from ni_authorization_controller;
commit;
