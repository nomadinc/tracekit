# NI-DB-001 correlated diagnostic candidate

Status: PARTIAL — instrumentation prepared; independent native execution pending.
Base: `b91f40c90b0449eee7cf6ca90c8c724666c473b6`.
Contract: NI-AUTH-001/Model-B/v1, review-assembly-2; SHA-256 `9a0baa2812a6b4825b1e378f6a695e37458363d8575fbffcf6b8300f8123ca71`.

## Scope and safety

This candidate adds diagnostic scripts, a manually installed disposable delay fixture, and diagnostic unit tests. Core runtime, security SQL, contract, migrations and the disabled production write gate are unchanged. It does not resolve NI-DB-001. No production execution, provisioning, deployment or activation is authorized.

Prior owner-reported native result remains **52 PASS / 3 FAIL / 0 SKIP**. Observer-on literal: 10748.915 ms FAIL; observer-on parameterized: 8221.738 ms PASS; observer-off literal: 8306.364 ms PASS; observer-off parameterized: 10219.840 ms FAIL. All four reported 57014 then 25P02. The separate 8596.056 ms ingestion pass does not replace the failed original ingestion assertion. Preserve all prior artifacts. No root cause has been established.

## Instrument inventory

- `ui/scripts/ni-db001-wire-observer.mjs`: socket write/data arrival, parser error SQLSTATE, transaction status and close events; excludes SQL, buffers and error messages. It wraps internal pg interfaces and requires native compatibility validation.
- `ui/scripts/ni-db001-deadline-probe.mjs`: original strict controls plus run/session identity, server activity samples, command/callback wall and monotonic times, wire events. Observer-off preserves absence of activity sampling.
- `ui/scripts/ni-db001-tls-probe.mjs`: actual dedicated Core adapter with synthetic TLS configuration; literal, parameterized and actual ingestion modes; terminal connection behavior, backend disappearance and ten-table equality checks.
- `ui/scripts/ni-db001-host-sampler.mjs`: separate 100 ms process/cgroup/pressure sampler. Unavailable counters are reported as unavailable.
- `ui/scripts/ni-db001-server-log-extract.mjs`: allowlisted extraction from independently collected PostgreSQL JSON logs; excludes statements, parameters, contexts and raw messages.
- `docs/operations/prepared/ni-db001-disposable-delay-marker.sql`: manually installed diagnostic trigger function only. No trigger is installed automatically. WS-024 may substitute it for its existing nine-second outbox delay fixture.

## Independent execution procedure

Verify bundle hash, complete history and exact HEAD before execution. Record HEAD as `NI_CANDIDATE_SHA`. Install dependencies using the accepted lockfiles; record versions and installation logs. Use a fresh isolated synthetic database named `ni_disposable_*`. All database URLs must be private environment values; never include them in evidence.

Use one safe `NI_DIAGNOSTIC_RUN_ID` for each correlated run. Set `NI_NATIVE_DISPOSABLE=synthetic-only` and `NI_NATIVE_TEST_URL` privately. Run from repository root:

```bash
NI_DEADLINE_OBSERVER=on NI_DEADLINE_REPORT_PATH=observer-on.json node ui/scripts/ni-db001-deadline-probe.mjs
NI_DEADLINE_OBSERVER=off NI_DEADLINE_REPORT_PATH=observer-off.json node ui/scripts/ni-db001-deadline-probe.mjs
```

Repeat both commands, preserving every output and exit status; each runs literal and parameterized controls. Do not overwrite failed samples. The acceptance predicate remains **7000 <= elapsedMs < 9000**, SQLSTATE 57014 and aborted transaction 25P02. Same-command timeout configuration is a negative control, not proof of effective pre-arming.

Run the host sampler concurrently as a separately managed process on both host and container where available:

```bash
NI_HOST_REPORT_PATH=host-samples.ndjson node ui/scripts/ni-db001-host-sampler.mjs
```

Terminate with SIGTERM after probes. Record scheduler/cgroup quotas and missing counters. A container-only sample cannot establish host scheduling behavior.

### Actual Core TLS adapter

WS-024 must prepare the accepted synthetic Model B fixture and nine-second outbox delay in its disposable database, with a dedicated restricted login, trusted CA/hostname and required safe telemetry profile. Provisioning is a test prerequisite, not implemented by this script. Configure private `NI_TLS_HOST`, `NI_TLS_PORT`, `NI_TLS_DATABASE`, `NI_TLS_USER`, `NI_TLS_PASSWORD`, `NI_TLS_CA_FILE`, and `NI_TLS_TELEMETRY_APPROVAL_REF`. The database must match the observer database; loopback only.

```bash
NI_TLS_DELAY_FIXTURE=installed-nine-second-outbox-delay NI_TLS_CORE_FIXTURE=approved-synthetic-modelb NI_TLS_REPORT_PATH=tls-results.json node --import tsx ui/scripts/ni-db001-tls-probe.mjs
```

Inspect the script's fixed synthetic observation/grant identifiers before preparing the fixture. A missing fixture is a failed prerequisite, never an accepted timing sample. The script uses the actual unmodified `openSecureConnection` and `deliverCore`. Confirm TLS authorization, server cancellation evidence, terminal COMMIT denial, connection disposal/backend disappearance and unchanged ten-table state. A client-only timeout is not substituted for server 57014. Native SQLSTATE/transaction-abort assertions must also run in the original native suite; adapter disposal alone does not prove 25P02.

### Server correlation

Use disposable-owner PostgreSQL JSON logging with `log_statement=none`, `log_min_error_statement=panic`, both parameter logging lengths zero, pgaudit disabled and terse error verbosity. Do not weaken the adapter's telemetry checks. Enable collector/JSON destination only in the isolated environment. Preserve raw logs under restricted access; publish only reviewed allowlisted output.

```bash
NI_PG_JSON_LOG=private-server.jsonlog NI_PG_CORRELATION_PATH=server-correlation.json node ui/scripts/ni-db001-server-log-extract.mjs
```

Correlate PID, backend start/session ID and diagnostic application name. Marker timestamps directly observe execution inside the delay fixture; JSON error timestamps directly observe error logging. Neither is an exact kernel cancellation instant. Activity `query_start` is an observed server statement start only when sampled for that matching session. Missing observer-off start samples remain unavailable; do not invent them. Socket data arrival precedes parser/callback processing but does not identify which byte contained the error. Client monotonic duration and server wall timestamps occupy different clock domains; measure/document clock offset, resolution and synchronization uncertainty before subtracting them. Log writes and scheduling can introduce additional latency. Missing samples cannot isolate root cause.

## Required independent regressions

Run the complete existing native security suite with the accepted synthetic fixture and record command, environment profile, source hashes, stdout/stderr and exit status. Specifically require the snapshot-negative test to reach its intended rejection assertion and the grant-expiry test to return 42501; 57014 is not an authorization PASS. Preserve rollback comparisons of observations, projections, links, audit/outbox, sequence and digest. Repeat disposal/reuse checks and inspect credential-safe failure paths. No assertions or timing thresholds are changed by this candidate.

## Local evidence and remaining gates

Focused security tests: 142 PASS / 0 FAIL / 0 SKIP (local PGlite/unit scope). Diagnostic tests: 4 PASS / 0 FAIL / 0 SKIP. Script syntax checks pass. These results do not certify native PostgreSQL, TLS, backend cancellation, platform logging or independent execution.

WS-024 must execute the exact new candidate independently. WS-022 acceptance follows that evidence. NI-DB-001 and NI-CRYPTO-001 remain OPEN. Missing S4 writer boundaries and operational governance remain separate activation blockers. Accepted NI-DB-002 and timestamp findings remain closed within their existing scopes. Production V1 remains HOLD.
