"""Expand only timestamp/session/error-code allowlist; never emit message/SQL/context."""
from pathlib import Path
import json,sys,re,hashlib
inputs=[Path(p) for p in sys.argv[1:]];events=[];private=[]
for p in inputs:
 data=p.read_bytes();private.append({'file':p.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 for line in data.decode(errors='replace').splitlines():
  try:r=json.loads(line)
  except ValueError:continue
  event=None
  if r.get('message','').startswith('disconnection:'):event='DISCONNECTION_LOGGED'
  elif r.get('error_severity')=='ERROR':event='BACKEND_ERROR_LOGGED'
  elif r.get('message','').startswith('NI_DB001_START '):event='START_MARKER_LOGGED'
  elif r.get('message','').startswith('NI_DB001_CANCEL '):event='CANCEL_MARKER_LOGGED'
  if event:
   events.append({'event':event,'serverLogTimestamp':r.get('timestamp'),'backendPid':r.get('pid'),'sessionId':r.get('session_id'),'sessionStart':r.get('session_start'),'applicationName':r.get('application_name'),'sqlstate':r.get('state_code'),'severity':r.get('error_severity')})
E=Path(__file__).resolve().parent
(E/'server-session-events.json').write_text(json.dumps({'events':events,'limitations':'Disconnection log time is observable backend cleanup logging, not the exact OS process-exit timestamp. Error messages, statements, parameters, contexts and connection addresses excluded.'},indent=2)+'\n')
(E/'private-server-log-hashes.json').write_text(json.dumps({'privateInputs':private,'rawLogsPackaged':False,'privateStorage':'Restricted local diagnostics directory; raw logs retained for authorized inspection only.'},indent=2)+'\n')
print('Allowlisted session events:',len(events))
