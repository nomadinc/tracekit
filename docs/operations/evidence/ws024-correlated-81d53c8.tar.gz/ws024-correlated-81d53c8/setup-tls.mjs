import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
const root=process.env.NI_CANDIDATE_ROOT,pg=createRequire(root+'/ui/package.json')('pg');
const {disposableTarget}=await import(root+'/ui/scripts/ni-db001-deadline-probe.mjs');
const c=new pg.Client({connectionString:disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE)});await c.connect();
try{
 await c.query('create role ws024_native_executor login nosuperuser nobypassrls nocreatedb nocreaterole');
 await c.query('grant ni_delivery_executor to ws024_native_executor');
 await c.query("select format('alter role ws024_native_executor password %L',$1) command",[process.env.NI_TLS_PASSWORD]).then(r=>c.query(r.rows[0].command));
 await c.query(readFileSync(root+'/docs/operations/prepared/ni-db001-disposable-delay-marker.sql','utf8'));
 await c.query('create trigger ws024_correlated_delay before insert on ni_security.outbox for each row execute function public.ni_db001_disposable_delay_marker()');
 console.log(JSON.stringify((await c.query("select version(),current_database() database,(select proconfig from pg_proc where oid='ni_security.ingest(text,text,text,uuid,uuid,text)'::regprocedure) ingest_function_settings,current_setting('log_statement') log_statement,current_setting('log_min_error_statement') log_min_error_statement,current_setting('log_parameter_max_length') parameter_length,current_setting('log_parameter_max_length_on_error') error_parameter_length,current_setting('log_error_verbosity') verbosity,current_setting('ssl') ssl")).rows[0]));
}finally{await c.end();}
