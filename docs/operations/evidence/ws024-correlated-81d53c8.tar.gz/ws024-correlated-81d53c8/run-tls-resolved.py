import os,sys,json,subprocess,time
from pathlib import Path
E=Path(__file__).resolve().parent;cfg=json.loads(Path(sys.argv[1]).read_text());env=os.environ.copy();env.update(cfg);C=Path(cfg['NI_CANDIDATE_ROOT'])
henv=env.copy();henv.update(NI_HOST_REPORT_PATH=str(E/'host-samples-tls-resolved.ndjson'),NI_DIAGNOSTIC_RUN_ID='ws024-tls-resolved')
with (E/'host-sampler-tls-resolved.log').open('wb') as hlog:
 host=subprocess.Popen(['node',str(C/'ui/scripts/ni-db001-host-sampler.mjs')],env=henv,stdout=hlog,stderr=subprocess.STDOUT)
 try:
  env['NI_TLS_REPORT_PATH']=str(E/'actual-core-tls.json');start=time.monotonic_ns();wall=time.time_ns()
  args=['node','--import','tsx','scripts/ni-db001-tls-probe.mjs']
  with (E/'actual-core-tls-resolved.log').open('wb') as f:p=subprocess.run(args,cwd=C/'ui',env=env,stdout=f,stderr=subprocess.STDOUT)
  status=json.loads((E/'execution-status.json').read_text());status.append({'id':'actual-core-tls-resolved','argv':args,'cwd':str(C/'ui'),'exit_code':p.returncode,'startWallNs':wall,'startMonotonicNs':start,'endWallNs':time.time_ns(),'endMonotonicNs':time.monotonic_ns()});(E/'execution-status.json').write_text(json.dumps(status,indent=2)+'\n');print('actual-core-tls-resolved exit',p.returncode,flush=True)
 finally:
  host.terminate()
  try:host.wait(timeout=10)
  except subprocess.TimeoutExpired:host.kill();host.wait()
