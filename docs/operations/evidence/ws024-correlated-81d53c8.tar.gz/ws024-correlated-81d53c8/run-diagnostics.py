"""Evidence orchestration only. Input configuration is private and never printed."""
import os,sys,json,subprocess,time,signal
from pathlib import Path
E=Path(__file__).resolve().parent
cfg=json.loads(Path(sys.argv[1]).read_text());env=os.environ.copy();env.update(cfg)
C=Path(cfg['NI_CANDIDATE_ROOT']);status=[]
def run(label,args,overrides=None,cwd=None):
 taskenv=env.copy();taskenv.update(overrides or {})
 start=time.monotonic_ns();wall=time.time_ns()
 with (E/(label+'.log')).open('wb') as f:
  p=subprocess.run(args,cwd=cwd or C,env=taskenv,stdout=f,stderr=subprocess.STDOUT)
 status.append({'id':label,'argv':args,'exit_code':p.returncode,'startWallNs':wall,'startMonotonicNs':start,'endWallNs':time.time_ns(),'endMonotonicNs':time.monotonic_ns()})
 (E/'execution-status.json').write_text(json.dumps(status,indent=2)+'\n')
 print(label,'exit',p.returncode,flush=True);return p.returncode
hostenv=env.copy();hostenv.update(NI_DIAGNOSTIC_RUN_ID='ws024-correlated-all',NI_HOST_REPORT_PATH=str(E/'host-samples.ndjson'))
hostlog=(E/'host-sampler.log').open('wb');host=subprocess.Popen(['node',str(C/'ui/scripts/ni-db001-host-sampler.mjs')],env=hostenv,stdout=hostlog,stderr=subprocess.STDOUT)
try:
 run('native-suite',['node','--import','tsx','--test','tests/network-intelligence-security-database.test.mjs'],{'NI_NATIVE_TEST_URL':cfg['NI_NATIVE_TEST_URL'].replace('ni_disposable_correlated_probes','ni_disposable_correlated_suite')},C/'ui')
 if run('provision-probes',['node',str(E/'provision-probes.mjs')]):raise RuntimeError('DISPOSABLE_PROVISION_FAILED')
 run('clock-before',['node',str(E/'clock-calibration.mjs')])
 # Alternate observer configurations; retain all six complete reports and exit statuses.
 for repetition in range(1,4):
  for mode in ['on','off']:
   label='native-'+mode+'-'+str(repetition)
   run(label,['node','ui/scripts/ni-db001-deadline-probe.mjs'],{'NI_DEADLINE_OBSERVER':mode,'NI_DIAGNOSTIC_RUN_ID':label,'NI_DEADLINE_REPORT_PATH':str(E/(label+'.json'))})
 run('clock-after-native',['node',str(E/'clock-calibration.mjs')])
 if run('setup-tls',['node',str(E/'setup-tls.mjs')]):raise RuntimeError('TLS_SETUP_FAILED')
 run('native-ingestion',['node',str(E/'native-ingestion.mjs')])
 run('actual-core-tls',['node','--import','tsx','ui/scripts/ni-db001-tls-probe.mjs'],{'NI_TLS_REPORT_PATH':str(E/'actual-core-tls.json')})
 run('core-error-safety',['node','--import',str(C/'ui/node_modules/tsx/dist/loader.mjs'),str(E/'core-error-safety.mjs')])
 run('clock-after-tls',['node',str(E/'clock-calibration.mjs')])
 run('diagnostic-unit',['node','--test','tests/network-intelligence-deadline.test.mjs'],cwd=C/'ui')
 # Fresh focused DB; only duplicate cluster role declarations are omitted in harness setup.
 run('create-focused-db',['docker','exec','ws024-correlated-postgres','createdb','-U','postgres','ni_disposable_correlated_focused'])
 run('interrupted-regressions',['node','--import','tsx','--test','--test-name-pattern=WS024 exact rejection: extra-independent_receipt|ingestion, duplicate, advancement|expiry during duplicate processing','tests/ws024-focused.test.mjs'],{'NI_NATIVE_TEST_URL':cfg['NI_NATIVE_TEST_URL'].replace('ni_disposable_correlated_probes','ni_disposable_correlated_focused')},C/'ui')
finally:
 host.terminate()
 try:host.wait(timeout=10)
 except subprocess.TimeoutExpired:host.kill();host.wait()
 hostlog.close()
