import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
const root=process.env.NI_CANDIDATE_ROOT;
const pg=createRequire(root+'/ui/package.json')('pg');
const {observePgWire}=await import(pathToFileURL(root+'/ui/scripts/ni-db001-wire-observer.mjs'));
const wire=[];let detach;
const {disposableTarget,strictDeadlineVerdict}=await import(pathToFileURL(root+'/ui/scripts/ni-db001-deadline-probe.mjs'));
const connectionString=disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE);
const c=new pg.Client({connectionString}),o=new pg.Client({connectionString});
const tables=['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams','ni_security.grants','edge_intelligence_tenant_bindings','edge_intelligence_service_credentials'];
const snapshot=async()=>{const out={};for(const table of tables)out[table]=(await o.query("select count(*)::int rows,coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb)::text data from "+table+' t')).rows[0];return out;};
const trace=[];const q=async(text,values)=>{trace.push(text);return c.query(text,values);};
let result,installed=false;
try{
 await c.connect();detach=observePgWire(c,event=>wire.push(event));await o.connect();await c.query("set application_name='ws024-native-ingestion'");
 const before=await snapshot();const meta=(await c.query("select pg_backend_pid() pid,version() version,(select backend_start::text from pg_stat_activity where pid=pg_backend_pid()) backend_start")).rows[0];
 const source=readFileSync(root+'/ui/tests/network-intelligence-security-database.test.mjs','utf8');
 const payload=Function('return '+source.split('const payload=')[1].split('\n')[0].slice(0,-1))();
 const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
 await q('begin');await q('set local role ni_delivery_executor');await q("set local lock_timeout='2s'");await q("set local statement_timeout='8s'");
 const settings=(await q("select current_setting('statement_timeout') statement_timeout,current_setting('lock_timeout') lock_timeout")).rows[0];
 let done=false;const samples=[];const loop=monitorEventLoopDelay({resolution:10});loop.enable();
 const sampling=(async()=>{while(!done){await o.query('select pg_stat_clear_snapshot()');const s=(await o.query("select clock_timestamp()::text server_at,query_start::text statement_start,backend_start::text backend_start,state,wait_event_type,wait_event,extract(epoch from (clock_timestamp()-query_start))*1000 query_age_ms from pg_stat_activity where pid=$1",[meta.pid])).rows[0];samples.push({clientMs:performance.now(),...s});if(!done)await new Promise(r=>setTimeout(r,100));}})();
 let sqlstate='00000',message,abortedSqlstate;const sentWall=new Date().toISOString(),wireStart=wire.length,start=performance.now();
 try{await q('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text) as result',['PUBLIC-SYNTHETIC-BEARER-0000000000000001','test','tenant_test0001',id(3),id(77),JSON.stringify(payload(1))]);}catch(e){sqlstate=e.code;message=e.message;}
 const callbackMs=performance.now(),callbackWall=new Date().toISOString(),elapsedMs=callbackMs-start;done=true;await sampling;loop.disable();
 try{await q('select 1');}catch(e){abortedSqlstate=e.code;}
 await q('rollback');const after=await snapshot();
 result={candidate:process.env.NI_CANDIDATE_SHA,meta,sqlstate,message,abortedSqlstate,elapsedMs,sentWall,callbackWall,callbackMs,wire:wire.slice(wireStart),settings,eventLoopMaxMs:loop.max/1e6,eventLoopP99Ms:loop.percentile(99)/1e6,samples,trace,before,after,unchanged:JSON.stringify(before)===JSON.stringify(after),strictTimingPass:strictDeadlineVerdict({sqlstate,elapsedMs,abortedSqlstate})};
 result.pass=result.strictTimingPass&&result.unchanged;
 writeFileSync(new URL('native-ingestion.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));process.exitCode=result.pass?0:1;
}finally{await c.query('rollback').catch(()=>{});if(installed)await c.query('drop trigger synthetic_deadline_detail on ni_security.outbox;drop function public.synthetic_deadline_detail()');detach?.();await Promise.allSettled([c.end(),o.end()]);}
