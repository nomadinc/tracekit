import {createRequire} from 'node:module';
import {performance} from 'node:perf_hooks';
const root=process.env.NI_CANDIDATE_ROOT,pg=createRequire(root+'/ui/package.json')('pg');
const {disposableTarget}=await import(root+'/ui/scripts/ni-db001-deadline-probe.mjs');
const c=new pg.Client({connectionString:disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE)});await c.connect();
try{const samples=[];for(let i=0;i<7;i++){
 const startWall=Date.now(),startMono=performance.now();
 const server=(await c.query("select clock_timestamp()::text server_at,extract(epoch from clock_timestamp())::text server_epoch_s,pg_backend_pid() pid,(select backend_start::text from pg_stat_activity where pid=pg_backend_pid()) backend_start")).rows[0];
 const endMono=performance.now(),endWall=Date.now(),serverMs=Number(server.server_epoch_s)*1000;
 samples.push({...server,startWall,endWall,startMono,endMono,rttMs:endMono-startMono,offsetLowerMs:serverMs-endWall,offsetUpperMs:serverMs-startWall,wallMinusMonotonicDurationMs:(endWall-startWall)-(endMono-startMono)});
}
let last=performance.now(),minStep=Infinity;for(let i=0;i<10000;i++){const now=performance.now();if(now>last)minStep=Math.min(minStep,now-last);last=now;}
console.log(JSON.stringify({samples,observedMonotonicMinimumStepMs:minStep,clientWallNominalResolutionMs:1,postgresTimestampStorageResolutionUs:1,limitations:'Offsets bound only the sampled round trip, plus clock quantization and scheduling. No independent NTP synchronization proof, no symmetric latency assumption, no exact kernel cancellation instant. Date.now clock adjustments/virtualization may invalidate interpolation between calibrations.'}));
}finally{await c.end();}
