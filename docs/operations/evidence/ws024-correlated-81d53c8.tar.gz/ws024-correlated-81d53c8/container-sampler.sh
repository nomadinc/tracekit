#!/bin/bash
trap 'exit 0' TERM INT
while :; do
 printf 'SAMPLE wall_ns=%s uptime=%s\n' "$(date +%s%N)" "$(cut -d' ' -f1 /proc/uptime)"
 for f in /sys/fs/cgroup/cpu.stat /sys/fs/cgroup/cpu.max /sys/fs/cgroup/memory.events /proc/pressure/cpu /proc/pressure/memory /proc/pressure/io; do
  printf 'FILE %s\n' "$f"
  if test -r "$f"; then cat "$f"; else printf 'UNAVAILABLE\n'; fi
 done
 printf 'END\n'
 sleep 0.1
done
