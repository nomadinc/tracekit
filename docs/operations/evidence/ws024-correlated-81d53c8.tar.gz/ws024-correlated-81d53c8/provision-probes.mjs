import {createRequire} from 'node:module';
const pg=createRequire(process.env.NI_CANDIDATE_ROOT+'/ui/package.json')('pg');
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=process.env.NI_CANDIDATE_ROOT;
const {disposableTarget}=await import(pathToFileURL(root+'/ui/scripts/ni-db001-deadline-probe.mjs'));
const client=new pg.Client({connectionString:disposableTarget(process.env.NI_NATIVE_TEST_URL,process.env.NI_NATIVE_DISPOSABLE)});await client.connect();
try {
 const count=(await client.query("select count(*)::int n from pg_tables where schemaname in ('public','ni_security')")).rows[0].n;
 if(count!==0)throw new Error('EMPTY_DATABASE_REQUIRED');
 await client.query('create table public.tracekit_organizations(id uuid primary key)');
 for(const name of ['supabase/migrations/20261004204330_edge_intelligence_v1_ingestion.sql','supabase/migrations/20261004204342_edge_intelligence_multitenant_delivery.sql','docs/operations/prepared/network-intelligence-security.sql']){
  const original=readFileSync(root+'/'+name,'utf8');
  // Roles are cluster-wide and were already created by the unchanged native suite.
  const sql=original.replace(/^create role ni_.*;\n/gm,'');await client.query(sql);
 }
 const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
 const token='PUBLIC-SYNTHETIC-BEARER-0000000000000001';
 const source=readFileSync(root+'/ui/tests/network-intelligence-security-database.test.mjs','utf8');
 const setup=source.split('await db.exec(`insert into tracekit_organizations')[1].split('`);')[0];
 const sql=Function('id','token','return `insert into tracekit_organizations'+setup+'`;')(id,token);
 await client.query(sql);
 console.log(JSON.stringify({database:client.database,initial_table_count:count,version:(await client.query('select version()')).rows[0].version,setup:'candidate native suite synthetic fixtures, preexisting cluster role declarations omitted only'}));
}finally{await client.end();}
