"""Allowlisted evidence joins; no raw SQL, error messages, credentials or packet bytes."""
from pathlib import Path
from datetime import datetime
import json,re,math,statistics
E=Path(__file__).resolve().parent

def epoch_ms(value):
 if not value:return None
 text=value.replace(' UTC','+00:00').replace('Z','+00:00')
 text=re.sub(r'([+-][0-9]{2})$',r'\1:00',text)
 text=re.sub(r'\.([0-9]+)',lambda m:'.'+m[1].ljust(6,'0'),text)
 return datetime.fromisoformat(text).timestamp()*1000

def bounds(values):return {'min':min(values),'max':max(values)} if values else None

server=json.loads((E/'server-allowlisted.json').read_text())['events']
clock=[]
for f in sorted(E.glob('clock-*.log')):
 try:clock.append({'file':f.name,**json.loads(f.read_text())})
 except ValueError:pass
lo=min(x['offsetLowerMs'] for c in clock for x in c['samples']);hi=max(x['offsetUpperMs'] for c in clock for x in c['samples'])
rows=[]
def join(source,identity,r,pid,events,app=None,samples=None,backend_start=None):
 err=[e for e in events if e.get('event')=='backend-error' and e.get('sqlstate')=='57014']
 backend_error=err[0] if err else None
 writes=[e for e in events if e.get('event')=='transport-write' and (not backend_error or e['clientMs']<=backend_error['clientMs'])]
 data=[e for e in events if e.get('event')=='transport-data' and (not backend_error or e['clientMs']<=backend_error['clientMs'])]
 receipt=data[-1] if data and backend_error else None
 se=[e for e in server if e['backendPid']==pid and (not app or e.get('applicationName')==app)]
 timeouts=[e for e in se if e['event']=='STATEMENT_TIMEOUT']
 matching=next((e for e in timeouts if not backend_error or abs(epoch_ms(e['serverLogTimestamp'])-epoch_ms(backend_error['clientWall']))<60000),None)
 starts=[s.get('statement_start') for s in (samples or []) if s.get('state')=='active' and s.get('wait_event')=='PgSleep']
 marker_starts=[e.get('statementStart') for e in se if e['event']=='START']
 start=next(iter(marker_starts or starts),None)
 row={'source':source,'sample':identity,'backendPid':pid,'backendStart':backend_start,'applicationName':app,'elapsedMs':r.get('elapsedMs'),'pass':r.get('pass',r.get('strictTimingPass')),'sqlstate':r.get('sqlstate'),'abortedSqlstate':r.get('abortedSqlstate'),'sentWall':r.get('sentWall'),'callbackWall':r.get('callbackWall'),'firstObservedWrite':writes[0] if writes else None,'lastWriteBefore57014':writes[-1] if writes else None,'dataArrivalBefore57014':receipt,'backendError':backend_error,'serverTimeout':matching,'observedStatementStart':start,'serverSessionIds':sorted(set(e['sessionId'] for e in se if e.get('sessionId'))),'serverEvents':se}
 if matching and start:row['statementStartToServerLogMs']=epoch_ms(matching['serverLogTimestamp'])-epoch_ms(start)
 if matching and receipt:
  gap=epoch_ms(receipt['clientWall'])-epoch_ms(matching['serverLogTimestamp'])
  row['serverLogToDataMsUsingSampledClockOffsetEnvelope']={'lower':gap+lo,'upper':gap+hi,'assumption':'Sampled server-minus-client clock offset envelope remains valid between calibrations; this is not a continuous synchronization guarantee.'}
 if backend_error and receipt:row['dataToParser57014Ms']=backend_error['clientMs']-receipt['clientMs']
 if r.get('callbackMs') is not None and backend_error:row['parser57014ToCallbackMs']=r['callbackMs']-backend_error['clientMs']
 rows.append(row)
for f in sorted(E.glob('native-*-*.json')):
 if not re.fullmatch(r'native-(on|off)-[1-3]\.json',f.name):continue
 d=json.loads(f.read_text())
 for r in d['results']:
  join(f.name,r['id'],r,d['meta']['pid'],r['wire'],r['applicationName'],r['samples'],d['meta']['backend_start'])
native=E/'native-ingestion.json'
if native.exists():
 d=json.loads(native.read_text());join(native.name,'native-ingestion',d,d['meta']['pid'],d['wire'],'ws024-native-ingestion',d['samples'],d['meta'].get('backend_start'))
tls=E/'actual-core-tls.json'
if tls.exists():
 for r in json.loads(tls.read_text())['reports']:
  join(tls.name,r.get('mode'),r,r.get('backendPid'),r.get('events',[]),'tracekit-ni-model-b')
core=E/'core-error-safety.json'
if core.exists():
 d=json.loads(core.read_text());join(core.name,'core-error-safety',d,d['backend']['pid'],d['events'],'tracekit-ni-model-b',backend_start=d['backend']['backend_start'])
(E/'correlations.json').write_text(json.dumps({'clockOffsetEnvelopeMs':{'lower':lo,'upper':hi},'clockCalibrations':clock,'samples':rows,'limitations':['Server LOG timestamp is error logging time, not kernel timer firing or send time.','A socket data event does not itself identify packet contents; selected event precedes observed 57014 parser event.','Observer-off statement starts remain unavailable for unwrapped sleep controls.','Missing server or parser events remain missing and never become PASS.','Sampled clock offsets cannot rule out unsampled clock adjustments.']},indent=2)+'\n')
host=sorted([json.loads(x) for f in E.glob('host-samples*.ndjson') for x in f.read_text().splitlines()],key=lambda x:x['wall'])
container=[];block=None
for line in (E/'container-samples.txt').read_text().splitlines():
 if line.startswith('SAMPLE '):
  m=re.match(r'SAMPLE wall_ns=(\d+) uptime=([0-9.]+)',line)
  if m:block={'wallNs':int(m[1]),'uptimeSeconds':float(m[2]),'text':[]};container.append(block)
 elif block is not None:block['text'].append(line)
cgaps=[(b['uptimeSeconds']-a['uptimeSeconds'])*1000 for a,b in zip(container,container[1:])]
wgaps=[(b['wallNs']-a['wallNs'])/1e6 for a,b in zip(container,container[1:])]
wallminusmono=[epoch_ms(b['wall'])-epoch_ms(a['wall'])-(b['monotonicMs']-a['monotonicMs']) for a,b in zip(host,host[1:]) if b['monotonicMs']>a['monotonicMs']]
def percentile(xs,p):return sorted(xs)[min(len(xs)-1,int(p*len(xs)))] if xs else None
sched={'host':{'samples':len(host),'gapMs':bounds([x['sampleGapMs'] for x in host]),'p99GapMs':percentile([x['sampleGapMs'] for x in host],.99),'wallMinusMonotonicGapMs':bounds(wallminusmono),'unavailableCounterPaths':sorted(k for k,v in host[0]['stats'].items() if v=='UNAVAILABLE') if host else []},'container':{'samples':len(container),'uptimeGapMs':bounds(cgaps),'wallGapMs':bounds(wgaps),'p99WallGapMs':percentile(wgaps,.99),'firstCounters':container[0] if container else None,'lastCounters':container[-1] if container else None},'limitations':['Sampling gaps bound sampler scheduling and execution, not the database backend scheduler alone.','The container bash sampler incurs process/file-read overhead; it is an independent fallback because Node is unavailable in the image.','Host process counters are not host-wide scheduler counters; Linux /proc and cgroup metrics are unavailable on macOS.']}
(E/'scheduling-summary.json').write_text(json.dumps(sched,indent=2)+'\n')

for row in rows:
 if not row.get('sentWall') or not row.get('callbackWall'):continue
 begin=epoch_ms(row['sentWall']);end=epoch_ms(row['callbackWall'])
 overlapping=[{'wallStartNs':a['wallNs'],'wallEndNs':b['wallNs'],'gapMs':(b['wallNs']-a['wallNs'])/1e6} for a,b in zip(container,container[1:]) if a['wallNs']/1e6<=end and b['wallNs']/1e6>=begin]
 row['maxOverlappingContainerSamplerGap']=max(overlapping,key=lambda x:x['gapMs']) if overlapping else None
 row['hostSamplerMaxGapInClientWindowMs']=max([x['sampleGapMs'] for x in host if begin<=epoch_ms(x['wall'])<=end],default=None)
(E/'correlations.json').write_text(json.dumps({'clockOffsetEnvelopeMs':{'lower':lo,'upper':hi},'clockCalibrations':clock,'samples':rows,'limitations':['Offsets are sampled bounds, not continuous clock synchronization; clock-consistency-findings.json records a sample outside the interpolated envelope.','Data arrival is linked only when a 57014 parser event was observed; absent events remain unavailable.','Overlapping sampler gaps are scheduling observations, not proof of causal mechanism.']},indent=2)+'\n')

print(json.dumps({'correlated_samples':len(rows),'clockOffsetEnvelopeMs':[lo,hi],'hostGapMs':sched['host']['gapMs'],'containerGapMs':sched['container']['wallGapMs']}))
