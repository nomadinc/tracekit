import pg from '/private/tmp/ws024-boundary-candidate/ui/node_modules/pg/lib/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
const vectors=JSON.parse(readFileSync('/Users/nomadm/Projects/tracekit-ws024-security-review/docs/operations/evidence/ws024-native-completion/vectors.json','utf8'));
const encode=x=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===1&&x.exact_json_number_token?x.exact_json_number_token:Array.isArray(x)?'['+x.map(encode).join(',')+']':x&&typeof x==='object'?'{'+Object.entries(x).map(([k,v])=>JSON.stringify(k)+':'+encode(v)).join(',')+'}':JSON.stringify(x);
const client=new pg.Client({host:'127.0.0.1',port:56852,user:'postgres',database:'ni_disposable_boundary_independent'});await client.connect();
const results=[];
try{
 await client.query('begin read only');await client.query("set local statement_timeout='8s'");await client.query('set local role ni_integrity_writer');
 for(const v of vectors.records){
  await client.query('savepoint vector');const start=performance.now();let r,error;
  try{const value=v.normalized?"jsonb_build_object('timestamp',ni_security.timestamp_text($1))":'$1::jsonb';r=(await client.query('select ni_security.canonical('+value+') bytes,ni_security.digest($2,'+value+') digest',[v.normalized?v.input:encode(v.input),v.record_type])).rows[0];}catch(e){error=e;}
  await client.query('rollback to savepoint vector');await client.query('release savepoint vector');
  const row={id:v.id,status:!error&&Buffer.from(r.bytes).toString('hex')===v.canonical_hex&&r.digest===v.sha256?'PASS':'FAIL',elapsed_ms:performance.now()-start,sqlstate:error?.code??'00000',message:error?.message??null,expected_digest:v.sha256,actual_digest:r?.digest,canonical_bytes_match:!!r&&Buffer.from(r.bytes).toString('hex')===v.canonical_hex};results.push(row);console.log(JSON.stringify(row));
 }
}finally{await client.query('rollback').catch(()=>{});await client.end();writeFileSync(new URL('positive-results.json',import.meta.url),JSON.stringify(results,null,2)+'\n');process.exitCode=results.some(r=>r.status==='FAIL')?1:0;}
