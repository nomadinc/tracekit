WS-024 independent NI-DB-002 boundary validation for e8d2252637945bb5eea685566585320d376a7c3b

Read REPORT.txt and execution-summary.json first. This is a LOCAL evidence package, not a public upload or production acceptance. Both known failed executions remain preserved. Hash manifest covers payload files; external archive checksum covers the manifest. Previous packages remain unchanged.

Exact environment and setup

Bundle: /Users/nomadm/Downloads/ws001-ni-db-002-boundaries.bundle
Verified SHA-256: 93dd7766f70aa3bb1168243f02579de180e2110604000f2b8e15550bccebb06b
Separate candidate: /private/tmp/ws024-boundary-candidate, detached at exact SHA.
Dependency reuse: ui/node_modules -> /Users/nomadm/Projects/tracekit-ws024-security-review/ui/node_modules. No npm install or lockfile change.

Executed new isolated container command:
docker run --name ws024-ni-db002-boundary-postgres -e POSTGRES_HOST_AUTH_METHOD=trust -p 127.0.0.1:56852:5432 -d postgres:17 -c log_statement=none -c log_min_error_statement=panic -c log_parameter_max_length=0 -c log_parameter_max_length_on_error=0

Create EMPTY ni_disposable_boundary_suite in this new cluster using localhost psql/postgres. Do not use a shared cluster or one with pre-existing NI roles. Wait for the exact new cluster's readiness. All roles and credentials here are synthetic test fixtures. Never substitute a production connection or credential.

Executed unmodified candidate suite from candidate/ui:
NI_NATIVE_TEST_URL=postgresql://postgres@127.0.0.1:56852/ni_disposable_boundary_suite NI_NATIVE_DISPOSABLE=synthetic-only node --import tsx --test tests/network-intelligence-security-database.test.mjs
Output: native-suite.log; process exit 1; 53 PASS / 1 FAIL. Native test/assertion copy in fixtures/candidate-native-suite.mjs is byte-identical and was not edited. Its relative imports are for inspection; execute the original in the exact candidate checkout.

Independent harnesses and actual phase order

Commands were run from /Users/nomadm/Projects/tracekit-ws024-security-review. Use node --import /private/tmp/ws024-boundary-candidate/ui/node_modules/tsx/dist/loader.mjs followed by each harness path below. stdout/stderr were captured together in the matching .log.

1. docs/operations/evidence/ws024-ni-db002-boundary-e8d2252/independent.mjs
Creates a fresh EMPTY ni_disposable_boundary_independent database. Since the dedicated cluster roles already exist from the suite, it omits only duplicate CREATE ROLE statements in memory; function/trigger SQL is unchanged. It creates a valid synthetic fixture and commits an accepted baseline delivery, then executes every original negative SQL statement under ni_integrity_writer with ten-table snapshots. All 32 return 22023. Six golden literal-SQL vectors then pass; the next literal authorization-audit query returned 57014 under statement_timeout=8s. This run exited 2 before its writer phase. The original source, log, completed results and exact failed-query attribution are preserved. No timing cause is asserted.

2. docs/operations/evidence/ws024-ni-db002-boundary-e8d2252/writers.mjs
This is the separately resumed writer phase for that exact partially completed fixture. It records/refreshed the disposable admission checkpoint before assertion snapshots. It runs exact invalid internal states, role denial, final-row faults, valid post-fault ingestion, digest integrity, both native lock orderings and safe pause. 55 PASS, exit 0. It does not recreate/drop data or silently relabel the earlier timeout. Only run this continuation if the initial run actually stopped before writers and the fixture is still active. If the initial literal SQL does not time out on another machine, independent.mjs can run its remaining writer phase itself; preserve that actual outcome and do not blindly rerun writers.mjs over the already-revoked/paused fixture.

3. docs/operations/evidence/ws024-ni-db002-boundary-e8d2252/positive-vectors.mjs
Read-only parameterized replay of all 32 original positive canonical/digest vectors against the same independent database, under ni_integrity_writer, same eight-second statement setting. 32 PASS, exit 0. Original raw numeric token wrappers are encoded exactly rather than rounded through floating-point values. For timestamp golden cases, actual SQL normalization supplies the encoded timestamp; expected hex/hash remain untouched. No new writes, role/grant setup or timeout relaxation occurs in this phase.

4. Lossless read-only diagnosis against suite database:
NI_CANDIDATE_PATH=/private/tmp/ws024-boundary-candidate NI_CANDIDATE_SHA=e8d2252637945bb5eea685566585320d376a7c3b NI_NATIVE_TEST_URL=postgresql://postgres@127.0.0.1:56852/ni_disposable_boundary_suite node --import /private/tmp/ws024-boundary-candidate/ui/node_modules/tsx/dist/loader.mjs scripts/ws024-regression/verify-lossless-native.mjs
Output: lossless-suite.json; three stored observation digests plus microsecond assertions PASS, exit 0. The original failing assertion is still in native-suite.log. The independent lossless code copies are in fixtures/ for review; repo-relative original runner paths are used for execution.

5. Final read-only catalogue and integrity queries after safe pause:
Use psql -h 127.0.0.1 -p 56852 -U postgres -d ni_disposable_boundary_independent -X -At -v ON_ERROR_STOP=1. native-catalog.jsonl records installed ni_security function signatures, owners, SECURITY DEFINER flags, ACLs, and non-internal trigger definitions. final-integrity.json records zero mismatches for audit/outbox joins, stream counters, native observation/source digests, current pointers and journey scope. Catalog ACLs are AFTER safe pause; before-pause role authority is evidenced by runtime requests/denials and the source grants.

Input provenance and boundaries

cases.json/csv map every original case to helper rejection and separately classify actual internal writer coverage, constructed observation/source input scope, and partial/unimplemented controls. fixtures/original-handoff-cases.json and negative-statements.original.sql preserve original inputs/SQL. fixtures/vectors.original.json preserves all positive and negative vectors. All candidate fixture raw byte comparisons pass; file-provenance.json inventories exact copied files. Source/helper manifest success is not a replacement for an unavailable persisted writer. No malformed Edge envelope was used to claim complete internal record-boundary coverage.

Snapshot evidence covers all complete sorted rows of ten tables: observations, pointers, links, deliveries, grants, bindings, credential rows, audit, outbox and audit streams. Each rejected call includes before/after row counts and SHA-256. Synthetic injection triggers modify final rows before the candidate guard and are removed in finally. No candidate SQL/TS/migrations or original negative assertions are modified. Owner/superuser DDL attacks are outside the runtime caller guarantee and are not tested as prevented.

All paths/names in these one-shot scripts intentionally identify disposable resources. If moving the package, adjust only independent harness paths and disposable fixture names after verifying the exact candidate bundle/SHA; never edit candidate source or substitute prior evidence. Preserve every new run separately, including failures. No implicit authorization exists to upload this new evidence or send it to external services. No production action is included.
