import pg from '/private/tmp/ws024-boundary-candidate/ui/node_modules/pg/lib/index.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {digest} from '/private/tmp/ws024-boundary-candidate/ui/lib/edge/security/integrity.ts';
import {normalizeRecord} from '/private/tmp/ws024-boundary-candidate/ui/lib/edge/security/manifests.ts';
const candidate='/private/tmp/ws024-boundary-candidate/';
const file=p=>{const s=readFileSync(candidate+p,'utf8');return p.endsWith('network-intelligence-security.sql')?s.replace(/^create role .*;$/gm,''):s;};
const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const token='PUBLIC-SYNTHETIC-BEARER-0000000000000001';
const config={host:'127.0.0.1',port:56852,user:'postgres',database:'ni_disposable_boundary_independent'};
const client=new pg.Client(config);await client.connect();
const db={exec:sql=>client.query(sql),query:(s,v)=>client.query(s,v)};
const payload=(revision=1)=>({schemaVersion:'1.0',observationId:'obs_test0001',tenantRef:'tenant_test0001',revision,...(revision>1?{previousRevision:revision-1}:{}),semanticsVersion:'m23-v1',derivationRuleVersion:'hybrid-derived-v1',sessionRef:'session_test0001',observedAt:'2026-10-17T00:00:00.000000Z',updatedAt:'2026-10-17T00:00:00.000000Z',status:'PARTIAL',completedStages:[],pendingStages:[],intelligence:{},evidence:[],conflicts:[],explanations:[],errors:[]});
async function ingest(p=payload(),overrides={}){
 await db.exec('set role ni_delivery_executor');try{return (await db.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text) as result',[overrides.token??token,overrides.environment??'test',overrides.tenant??'tenant_test0001',overrides.epoch??id(3),overrides.delivery??id(6+p.revision),JSON.stringify(p)])).rows[0].result;}finally{await db.exec('reset role');}
}
const results=[];const hash=s=>createHash('sha256').update(s).digest('hex');
const check=(id,ok,detail={})=>{const row={id,status:ok?'PASS':'FAIL',...detail};results.push(row);console.log(JSON.stringify(row));};
const tables=['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams','ni_security.grants','edge_intelligence_tenant_bindings','edge_intelligence_service_credentials'];
async function snapshot(){const out={};for(const t of tables){const s=(await client.query("select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),'[]'::jsonb)::text value from "+t+' x')).rows[0].value;out[t]={sha256:hash(s),rows:JSON.parse(s).length};}return out;}
async function role(name,fn){await client.query('set role '+name);try{return await fn();}finally{await client.query('reset role');}}
async function rejected(id,fn,expected='22023',extra={}){const before=await snapshot();let error,value;try{value=await fn();}catch(e){error=e;}const after=await snapshot();check(id,error?.code===expected&&JSON.stringify(before)===JSON.stringify(after),{sqlstate:error?.code??'00000',message:error?.message??'accepted',expected_sqlstate:expected,actual:value?.rows,unchanged:JSON.stringify(before)===JSON.stringify(after),before,after,...extra});}
const root='/Users/nomadm/Projects/tracekit-ws024-security-review/';
const original=JSON.parse(readFileSync(root+'docs/operations/evidence/ws024-ni-db-002-exact-failures/cases.json','utf8')).cases;
const vectors=JSON.parse(readFileSync(root+'docs/operations/evidence/ws024-native-completion/vectors.json','utf8'));
const originalSql=readFileSync(root+'docs/operations/evidence/ws024-native-completion/digest-vectors.sql','utf8').split('\n');
try{
 console.log(JSON.stringify({phase:'WRITER_BOUNDARIES',metadata:(await client.query('select version(),current_database(),clock_timestamp()')).rows[0]}));
 await client.query("set statement_timeout='8s';set lock_timeout='2s'");
 const admission=(await client.query("select checkpoint_at,clock_timestamp()-checkpoint_at as age from ni_security.admission")).rows;console.log(JSON.stringify({fixture_admission_before:admission}));
 await client.query('update ni_security.admission set checkpoint_at=clock_timestamp()');console.log(JSON.stringify({synthetic_fixture_admission_refreshed:true,scope:'disposable setup only; before assertion snapshots'}));
 check('baseline valid replay before writer tests',(await ingest()).outcome==='duplicate');
 for(const item of original.filter(v=>['credential_grant','tenant_binding','current_projection','journey_link'].includes(v.record_type))){
  const auth=['credential_grant','tenant_binding'].includes(item.record_type);
  const body=auth?{event_type:item.record_type==='credential_grant'?'grant_created':'binding_disabled',grant_id:id(5),tenant_ref:'tenant_test0001',actor:'independent-synthetic-controller',approval_ref:'synthetic-approval',reason:'synthetic-test'}:{event_type:item.record_type==='current_projection'?'projection_changed':'link_changed',record_type:item.record_type,record_key:{id:id(1)},authorization_context:{},outcome:'accepted'};
  const key=auth?'after':item.record_type==='current_projection'?'after_projection':'after_link';
  await rejected('AUDIT_WRITER:'+item.test_id,()=>role(auth?'ni_controller_writer':'ni_integrity_writer',()=>client.query('select ni_security.audit($1::uuid,$2::jsonb || jsonb_build_object($3::text,$4::jsonb))',[id(15),JSON.stringify(body),key,item.exact_raw_json])),'22023',{boundary:'INTERNAL_AUDIT_WRITER',raw_sha256:item.exact_input_sha256});
 }
 for(const roleName of ['ni_delivery_executor','ni_authorization_controller','service_role','anon','authenticated']){
  for(const [fn,sql,args] of [
   ['digest','select ni_security.digest($1,$2::jsonb)',['observation',original[0].exact_raw_json]],
   ['record_value','select ni_security.record_value($1,$2::jsonb)',['observation',original[0].exact_raw_json]],
   ['canonical','select ni_security.canonical($1::jsonb)',['{}']],
   ['audit','select ni_security.audit($1::uuid,$2::jsonb)',[id(15),'{}']]])await rejected('DENIED:'+roleName+':'+fn,()=>role(roleName,()=>client.query(sql,args)),'42501',{boundary:'DIRECT_SQL_RPC'});
 }
 const privileges=(await client.query("select r.rolname,r.rolcanlogin,r.rolsuper,r.rolbypassrls,pg_has_role(r.rolname,'ni_integrity_writer','MEMBER') writer_member,pg_has_role(r.rolname,'ni_controller_writer','MEMBER') controller_member from pg_roles r where r.rolname in ('ni_integrity_writer','ni_controller_writer','ni_delivery_executor','ni_authorization_controller','service_role') order by rolname")).rows;
 console.log(JSON.stringify({role_inventory:privileges}));
 check('writer roles non-login, non-superuser, no bypass',privileges.filter(r=>['ni_integrity_writer','ni_controller_writer'].includes(r.rolname)).every(r=>!r.rolcanlogin&&!r.rolsuper&&!r.rolbypassrls));
 check('application roles not members of internal writer roles',privileges.filter(r=>['ni_delivery_executor','ni_authorization_controller','service_role'].includes(r.rolname)).every(r=>!r.writer_member&&!r.controller_member));
 const faults=[
 ['observation-null-epoch','edge_intelligence_observations','insert','new.binding_epoch=null;','ingest'],
 ['observation-record-digest','edge_intelligence_observations','insert',"new.record_digest=repeat('f',64);",'ingest'],
 ['observation-source-digest','edge_intelligence_observations','insert',"new.source_digest=repeat('f',64);",'ingest'],
 ['projection-zero-revision','edge_intelligence_current','insert','new.revision=0;','ingest'],
 ['link-null-evidence','edge_intelligence_journey_links','insert','new.linkage_evidence=null;','ingest'],
 ['audit-extra-field','ni_security.audit_events','insert',"new.body=new.body||jsonb_build_object('unclassified_column',true);",'ingest'],
 ['audit-row-sequence','ni_security.audit_events','insert','new.sequence=new.sequence+1;','ingest'],
 ['outbox-forged-digest','ni_security.outbox','insert',"new.event_digest=repeat('f',64);",'ingest'],
 ['grant-null-epoch','ni_security.grants','update','new.binding_epoch=null;','revoke'],
 ['binding-null-epoch','edge_intelligence_tenant_bindings','update','new.binding_epoch=null;','disable']
 ];
 for(const item of original.filter(v=>['authorization_audit','observation_audit'].includes(v.record_type)))faults.push(['exact-body-'+item.test_id,'ni_security.audit_events','insert',"new.body='"+item.exact_raw_json.replaceAll("'","''")+"'::jsonb;",'ingest']);
 for(const [name,table,event,mutation,operation] of faults){
  await client.query(`create function public.ws024_fault() returns trigger language plpgsql as $$begin ${mutation} return new;end$$;create trigger aa_ws024_fault before ${event} on ${table} for each row execute function public.ws024_fault()`);
  try{await rejected('FAULT:'+name,()=>operation==='ingest'?ingest(payload(2),{delivery:id(120)}):role('ni_authorization_controller',()=>operation==='revoke'?client.query('select ni_security.revoke_grant($1,$2,$3)',[id(5),'synthetic-controller','fault-test']):client.query('select ni_security.disable_binding($1,$2,$3)',['tenant_test0001','synthetic-controller','fault-test'])),'22023',{boundary:'FINAL_ROW_GUARD',table,event,mutation,operation});}
  finally{await client.query(`drop trigger aa_ws024_fault on ${table};drop function public.ws024_fault()`);}
 }
 check('authorized ingestion still works after all rejected faults',(await ingest(payload(2),{delivery:id(122)})).outcome==='accepted');
 const integrity=(await client.query("select count(*)::int mismatches from (select *,lag(record_digest,1,repeat('0',64)) over(partition by stream_id order by sequence) prev,row_number() over(partition by stream_id order by sequence) seq from ni_security.audit_events) a full join ni_security.outbox o on o.event_id=a.id where a.id is null or o.event_id is null or a.previous_digest<>a.prev or a.sequence<>a.seq or o.sequence<>a.sequence or o.event_digest<>a.record_digest or a.record_digest<>ni_security.digest(case when a.body?'actor_ref' then 'authorization_audit' else 'observation_audit' end,a.body)")).rows[0];check('native audit sequence/digest/outbox integrity',integrity.mismatches===0,integrity);
 const observations=(await client.query("select ni_security.normalize_state(to_jsonb(x)-'source_digest'-'record_digest') record,record_digest from edge_intelligence_observations x order by revision")).rows;
 for(const r of observations)check('lossless independent TS observation digest revision '+r.record.revision,digest('observation',normalizeRecord('observation',r.record))===r.record_digest,{received_at:r.record.received_at,expected:r.record_digest,actual:digest('observation',normalizeRecord('observation',r.record))});
 // Repeat both lock orderings inside rollback-only controller transactions where
 // needed; the committed ingestion-first revision has real audit/outbox records.
 const i=new pg.Client(config),c=new pg.Client(config);await i.connect();await c.connect();
 try{
  await i.query("set statement_timeout='8s'");await i.query('begin');await i.query('set local role ni_delivery_executor');
  await i.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text)',[token,'test','tenant_test0001',id(3),id(123),JSON.stringify(payload(3))]);
  await c.query('begin');await c.query('set local role ni_authorization_controller');const cp=(await c.query('select pg_backend_pid() pid')).rows[0].pid;
  const revoke=c.query('select ni_security.revoke_grant($1,$2,$3)',[id(5),'synthetic-controller','ingestion-first']).then(()=>({code:'00000'}),e=>({code:e.code}));
  await new Promise(r=>setTimeout(r,100));const blockers=(await client.query('select pg_blocking_pids($1) pids',[cp])).rows[0].pids;
  await i.query('commit');const resumed=await revoke;await c.query('rollback');check('ingestion-first native lock order',blockers.length>0&&resumed.code==='00000',{blockers,controller_sqlstate:resumed.code});
  await c.query('begin');await c.query('set local role ni_authorization_controller');await c.query('select ni_security.revoke_grant($1,$2,$3)',[id(5),'synthetic-controller','revocation-first']);
  await i.query('begin');await i.query('set local role ni_delivery_executor');const ip=(await i.query('select pg_backend_pid() pid')).rows[0].pid;
  const pending=i.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text)',[token,'test','tenant_test0001',id(3),id(124),JSON.stringify(payload(4))]).then(()=>({code:'00000'}),e=>({code:e.code}));
  await new Promise(r=>setTimeout(r,100));const waiting=(await client.query('select pg_blocking_pids($1) pids',[ip])).rows[0].pids;await c.query('commit');const before=await snapshot();const denied=await pending;await i.query('rollback');check('revocation-first native lock order and zero ingestion writes',waiting.length>0&&denied.code==='42501'&&JSON.stringify(before)===JSON.stringify(await snapshot()),{blockers:waiting,sqlstate:denied.code});
 }finally{await i.query('rollback').catch(()=>{});await c.query('rollback').catch(()=>{});await i.end();await c.end();}
 const before=await snapshot();await client.query(file('docs/operations/prepared/network-intelligence-pause.sql'));await rejected('safe pause direct ingestion denial',()=>ingest(payload(4)),'42501');check('safe pause complete snapshot preservation',JSON.stringify(before)===JSON.stringify(await snapshot()));
}catch(error){console.log(JSON.stringify({HARNESS_ERROR:error.message,code:error.code,stack:error.stack}));process.exitCode=2;}
finally{writeFileSync(new URL('writer-results.json',import.meta.url),JSON.stringify(results,null,2)+'\n');await client.end();if(!process.exitCode&&results.some(r=>r.status==='FAIL'))process.exitCode=1;}
