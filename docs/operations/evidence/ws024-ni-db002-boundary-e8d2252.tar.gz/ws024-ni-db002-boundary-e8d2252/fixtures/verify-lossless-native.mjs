import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {checkCandidate} from './check-candidate.mjs';
import {verifyLosslessObservations} from './lossless-observations.mjs';
const checked = checkCandidate();
const require = createRequire(checked.candidate+'/ui/package.json');
const {Client} = require('pg');
const {digest,normalizeTimestamp} = await import(pathToFileURL(checked.candidate+'/ui/lib/edge/security/integrity.ts'));
const {normalizeRecord} = await import(pathToFileURL(checked.candidate+'/ui/lib/edge/security/manifests.ts'));
const client = new Client({connectionString:checked.databaseUrl.toString()});
await client.connect();
try {
 await client.query('begin read only');
 await client.query("set local statement_timeout='8s'");
 const results = await verifyLosslessObservations(client,{digest,normalizeRecord});
 // Distinct timestamps within one millisecond must remain distinct after
 // native serialization and TypeScript normalization. Fractions include the
 // last microsecond of a second.
 const fractions = ['000001','123456','999999'];
 for (const fraction of fractions) {
  const input = '2026-10-17T00:00:00.'+fraction+'Z';
  const result = (await client.query(`select to_char($1::timestamptz at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') value`,[input])).rows[0].value;
  assert.equal(result,input); assert.equal(normalizeTimestamp(result),input);
 }
 assert.notEqual(normalizeTimestamp('2026-10-17T00:00:00.123456Z'),normalizeTimestamp('2026-10-17T00:00:00.123457Z'));
 console.log(JSON.stringify({sha:checked.sha,contractHash:checked.contractHash,
  results,microsecondBoundaryChecks:'PASS'},null,2));
 assert(results.every(row => row.status === 'PASS'),'lossless observation digest mismatch');
} finally {await client.query('rollback').catch(()=>{});await client.end();}
