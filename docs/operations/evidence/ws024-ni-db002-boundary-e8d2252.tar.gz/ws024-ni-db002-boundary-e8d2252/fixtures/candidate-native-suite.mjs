import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {PGlite} from '@electric-sql/pglite';
import pg from 'pg';
const nativeUrl=process.env.NI_NATIVE_TEST_URL;
import {normalizeRecord} from '../lib/edge/security/manifests.ts';
import {digest,normalizeTimestamp} from '../lib/edge/security/integrity.ts';
import {deliverCore} from '../lib/edge/security/core.ts';
import {createModelBRoute} from '../lib/edge/security/route.ts';
const root=new URL('../../',import.meta.url);
const file=p=>readFileSync(new URL(p,root),'utf8');
const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const token='PUBLIC-SYNTHETIC-BEARER-0000000000000001';
let db;
test.before(async()=>{
 if(nativeUrl){
  const target=new URL(nativeUrl);
  if(target.search||process.env.NI_NATIVE_DISPOSABLE!=='synthetic-only'||!['localhost','127.0.0.1','[::1]'].includes(target.hostname)||!/^\/ni_disposable_[a-z0-9_]+$/.test(target.pathname))throw new Error('disposable native database required');
  const client=new pg.Client({connectionString:nativeUrl});await client.connect();
  const existing=await client.query("select count(*)::int n from pg_tables where schemaname in ('public','ni_security')");
  if(existing.rows[0].n!==0){await client.end();throw new Error('empty disposable database required');}
  db={exec:sql=>client.query(sql),query:(sql,values)=>client.query(sql,values),close:()=>client.end()};
 }else db=new PGlite();
 await db.exec(`create role service_role nologin bypassrls;create role anon;create role authenticated;create role authenticator;create table public.tracekit_organizations(id uuid primary key);`);
 await db.exec(file('supabase/migrations/20261004204330_edge_intelligence_v1_ingestion.sql'));
 await db.exec(file('supabase/migrations/20261004204342_edge_intelligence_multitenant_delivery.sql'));
 await db.exec(file('docs/operations/prepared/network-intelligence-security.sql'));
 // Separate command: the function-local SET clause is not a statement timer.
 await db.exec("set statement_timeout='8s';set lock_timeout='2s';set idle_in_transaction_session_timeout='10s'");
 await db.exec(`insert into tracekit_organizations values('${id(2)}'),('${id(22)}');
 insert into edge_intelligence_service_credentials(id,label,token_hash) values('${id(4)}','synthetic',encode(sha256(convert_to('${token}','UTF8')),'hex'));
 insert into edge_intelligence_tenant_bindings(tenant_ref,organization_id,environment,binding_epoch,approval_ref,approved_by) values('tenant_test0001','${id(2)}','test','${id(3)}','synthetic','controller');
 insert into ni_security.grants(id,credential_id,environment,tenant_ref,organization_id,binding_epoch,status,valid_from,approval_ref,approved_by) values('${id(5)}','${id(4)}','test','tenant_test0001','${id(2)}','${id(3)}','active','2020-01-01Z','synthetic','controller');
 insert into ni_security.audit_streams(id) values('${id(15)}');insert into ni_security.admission values('test','${id(15)}',clock_timestamp(),true);`);
});
test.after(async()=>{await db?.close();});
const payload=(revision=1)=>({schemaVersion:'1.0',observationId:'obs_test0001',tenantRef:'tenant_test0001',revision,...(revision>1?{previousRevision:revision-1}:{}),semanticsVersion:'m23-v1',derivationRuleVersion:'hybrid-derived-v1',sessionRef:'session_test0001',observedAt:'2026-10-17T00:00:00.000000Z',updatedAt:'2026-10-17T00:00:00.000000Z',status:'PARTIAL',completedStages:[],pendingStages:[],intelligence:{},evidence:[],conflicts:[],explanations:[],errors:[]});
async function ingest(p=payload(),overrides={}){
 await db.exec('set role ni_delivery_executor');try{return (await db.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text) as result',[overrides.token??token,overrides.environment??'test',overrides.tenant??'tenant_test0001',overrides.epoch??id(3),overrides.delivery??id(6+p.revision),JSON.stringify(p)])).rows[0].result;}finally{await db.exec('reset role');}
}
async function routeIngest(p,tenant='tenant_test0001',epoch=id(3)){
 const handler=createModelBRoute({enabled:true,environment:'test',authenticateUnversioned:async()=>{throw new Error('unexpected legacy authentication');},log:()=>{throw new Error('unexpected route error');},open:async()=>({query:(sql,values)=>db.query(sql,values),tlsVerified:true,parameterCaptureDisabled:true,errorCaptureDisabled:true,dispose:async()=>{}})});
 const request=new Request('https://synthetic.test/api/edge/intelligence-v1',{method:'POST',headers:{authorization:'Bearer '+token,'TraceKit-Authorization-Contract':'NI-AUTH-001/Model-B/v1','TraceKit-Environment':'test','TraceKit-Tenant-Ref':tenant,'TraceKit-Binding-Epoch':epoch,'TraceKit-Delivery-Id':id(6+p.revision)},body:JSON.stringify(p)});
 await db.exec('set role ni_delivery_executor');try{return await handler(request);}finally{await db.exec('reset role');}
}
test('disposable only: independently recomputed SQL canonical bytes match all norm vectors',async()=>{
 const vectors=JSON.parse(file('ui/tests/fixtures/network-security/vectors.json'));
 // Canonical typed-tree is an independently implemented SQL encoder, not caller-supplied bytes.
 for(const v of vectors.records.filter(v=>!v.normalized)){
  const decode=x=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===1&&x.exact_json_number_token?x.exact_json_number_token:Array.isArray(x)?'['+x.map(decode).join(',')+']':x&&typeof x==='object'?'{'+Object.entries(x).map(([k,y])=>JSON.stringify(k)+':'+decode(y)).join(',')+'}':JSON.stringify(x);
  const r=(await db.query('select ni_security.canonical($1::jsonb) as bytes,ni_security.digest($2,$1::jsonb) as digest',[decode(v.input),v.record_type])).rows[0];
  assert.equal(Buffer.from(r.bytes).toString('hex'),v.canonical_hex,v.id);assert.equal(r.digest,v.sha256,v.id);
 }
});
const protectedSnapshot=async()=>{const out={};for(const table of ['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.deliveries','ni_security.audit_events','ni_security.outbox','ni_security.audit_streams','ni_security.grants','edge_intelligence_tenant_bindings'])out[table]=(await db.query('select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),\'[]\'::jsonb)::text value from '+table+' t')).rows[0].value;return out;};
const boundaryEvidence=(testId,scope,sqlstate,before,after)=>console.log(JSON.stringify({testId,scope,sqlstate,states:Object.fromEntries(Object.keys(before).map(k=>[k,{before: createHash('sha256').update(before[k]).digest('hex'),after:createHash('sha256').update(after[k]).digest('hex'),unchanged:before[k]===after[k]}]))}));
const exactNegatives=JSON.parse(file('ui/tests/fixtures/network-security/ws024-exact-negative.json'));
for(const item of exactNegatives.cases)test('WS024 exact rejection: '+item.id,async()=>{
 const before=await protectedSnapshot();let sqlstate;await db.exec('set role ni_integrity_writer');
 try{await assert.rejects(db.query('select ni_security.digest($1,$2::jsonb)',[item.record_type,item.raw]),error=>{sqlstate=error.code;return sqlstate==='22023';});}
 finally{await db.exec('reset role');}const after=await protectedSnapshot();assert.deepEqual(after,before);boundaryEvidence(item.id,'EXACT_HELPER',sqlstate,before,after);
});
test('direct ingestion without a pre-armed deadline fails before persistence',async()=>{
 for(const value of ['0','9s']){await db.exec(`set statement_timeout='${value}'`);try{await assert.rejects(ingest(),error=>error.code==='55000'&&error.message==='deadline_not_armed');}finally{await db.exec("set statement_timeout='8s'");}}
 assert.equal((await db.query('select count(*)::int n from edge_intelligence_observations')).rows[0].n,0);
});
test('S4 negative helper inputs reject SQL absence, timestamp overprecision and type confusion',async()=>{
 assert.equal((await db.query('select ni_security.raw_json_valid(null) as valid')).rows[0].valid,false);
 for(const value of ['2026-10-17T00:00:00.0000001Z','2026-10-17T00:00:60Z','2026-02-30T00:00:00Z','2026-10-17T00:00:00','0001-01-01T00:00:00+14:00','9999-12-31T23:59:59-14:00','infinity',42,true])await assert.rejects(db.query('select ni_security.normalize_state($1::jsonb)',[JSON.stringify({observed_at:value})]));
 for(const raw of ['{"x":1,"\\u0078":2}','{"x":"\\ud800"}','1e4097','1e4096','1e-4096'])assert.equal((await db.query('select ni_security.raw_json_valid($1) as valid',[raw])).rows[0].valid,false);
});
test('SQL timestamp boundaries match S4 and malformed evidence cannot persist',async()=>{
 for(const value of ['0001-01-01T00:00:00Z','9999-12-31T23:59:59.999999Z','2026-10-17T00:00:00.123456+14:00','2026-10-17T00:00:00-07:00'])assert.equal((await db.query('select ni_security.timestamp_text($1) value',[value])).rows[0].value,normalizeTimestamp(value));
 for(const value of ['2026-10-17T00:00:00.0000001Z','2026-10-17T00:00:60Z','2026-10-17T00:00:00',null,42]){
  const p=payload();p.evidence=[{id:'synthetic_evidence',provider:'synthetic',sourceClass:'OWNED_OBSERVATION',freshness:'CURRENT',observedAt:value}];
  await assert.rejects(ingest(p),error=>error.code==='22023');
 }
 for(const table of ['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links','ni_security.audit_events','ni_security.outbox'])assert.equal((await db.query('select count(*)::int n from '+table)).rows[0].n,0,table);
});
test('proof, explicit scope, expiry and epoch checks deny foreign delivery',async()=>{
 for(const options of [{token:'WRONG-SYNTHETIC-BEARER-0000000000000000'},{environment:'foreign'},{tenant:'tenant_foreign01'},{epoch:id(99)}])await assert.rejects(ingest(payload(),options));
 assert.equal((await db.query('select count(*)::int as n from edge_intelligence_observations')).rows[0].n,0);
});
test('approved Model B Core handler returns HTTP 403 for an authenticated foreign active tenant',async()=>{
 await db.exec(`insert into edge_intelligence_tenant_bindings(tenant_ref,organization_id,environment,binding_epoch,approval_ref,approved_by) values('tenant_foreign01','${id(22)}','test','${id(33)}','synthetic','controller')`);
 const p=JSON.parse(file('ui/tests/fixtures/edge-intelligence-v1.examples.json')).scenarios.normalResidential;p.tenantRef='tenant_foreign01';
 const result=await routeIngest(p,'tenant_foreign01',id(33));assert.equal(result.status,403);
 for(const table of ['edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links'])assert.equal((await db.query('select count(*)::int n from '+table)).rows[0].n,0,table);
});
test('direct writer validates payload, duplicate decoded keys and redaction independently',async()=>{
 for(const p of [{...payload(),email:'not-allowed'},{...payload(),intelligence:{network:{vpn:{freshness:'CURRENT'}}}},{...payload(),completedStages:['NOT_A_STAGE']}])await assert.rejects(ingest(p));
 await db.exec('set role ni_delivery_executor');try{
  await assert.rejects(db.query('select ni_security.ingest($1,$2,$3,$4::uuid,$5::uuid,$6::text)',[token,'test','tenant_test0001',id(3),id(6),'{"a":1,"\\u0061":2}']));
 }finally{await db.exec('reset role');}
});
test('expired grant and revoked credential cannot use a formerly accepted scope',async()=>{
 await db.exec("update ni_security.grants set expires_at=clock_timestamp()-interval '1 minute'");await assert.rejects(ingest());await db.exec('update ni_security.grants set expires_at=null');
 await db.exec("update edge_intelligence_service_credentials set status='revoked'");await assert.rejects(ingest());await db.exec("update edge_intelligence_service_credentials set status='active'");
});
test('ingestion, duplicate, advancement, stale and conflict retain history/current authority',async()=>{
 const response=await routeIngest(payload());assert.equal(response.status,201);assert.equal((await response.json()).outcome,'accepted');assert.equal((await ingest()).outcome,'duplicate');
 assert.equal((await ingest(payload(3))).outcome,'accepted');assert.equal((await ingest(payload(2))).outcome,'stale');
 await assert.rejects(ingest({...payload(1),status:'UNKNOWN'}));
 assert.equal((await db.query('select revision from edge_intelligence_current')).rows[0].revision,3);
 assert.equal((await db.query('select count(*)::int as n from edge_intelligence_observations')).rows[0].n,3);
});
test('expiry during duplicate processing denies and rolls back all replay side effects',async()=>{
 const counts=async()=>{const result={};for(const table of ['ni_security.deliveries','ni_security.audit_events','ni_security.outbox','edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links'])result[table]=(await db.query('select count(*)::int n from '+table)).rows[0].n;return result;};
 const before=await counts();
 // Disposable-only delay expires the grant after initial authorization.
 await db.exec(`create function public.synthetic_replay_delay() returns trigger language plpgsql as $$begin if new.body->>'event_type'='delivery_replay' then perform pg_sleep(0.3);end if;return new;end$$;
 create trigger synthetic_replay_delay before insert on ni_security.audit_events for each row execute function public.synthetic_replay_delay();
 update ni_security.grants set expires_at=clock_timestamp()+interval '0.2 seconds';`);
 try{await assert.rejects(ingest(payload(1),{delivery:id(90)}),error=>error.code==='42501'&&error.message==='forbidden');assert.deepEqual(await counts(),before);}
 finally{await db.exec('drop trigger synthetic_replay_delay on ni_security.audit_events;drop function public.synthetic_replay_delay();update ni_security.grants set expires_at=null');}
 assert.equal((await ingest(payload(1))).outcome,'duplicate');
});
if(nativeUrl)test('native pre-armed eight-second deadline cancels nine-second ingestion and rolls back',async()=>{
 const counts=async()=>{const result={};for(const table of ['ni_security.deliveries','ni_security.audit_events','ni_security.outbox','edge_intelligence_observations','edge_intelligence_current','edge_intelligence_journey_links'])result[table]=(await db.query('select count(*)::int n from '+table)).rows[0].n;return result;};
 const before=await counts();
 await db.exec(`create function public.synthetic_deadline_delay() returns trigger language plpgsql as $$begin perform pg_sleep(9);return new;end$$;
 create trigger synthetic_deadline_delay before insert on ni_security.outbox for each row execute function public.synthetic_deadline_delay();`);
 const start=Date.now();
 try{await assert.rejects(ingest(payload(4)),error=>error.code==='57014');const elapsed=Date.now()-start;assert(elapsed>=7000&&elapsed<9000,'statement must cancel before the nine-second delay completes');assert.deepEqual(await counts(),before);}
 finally{await db.exec('drop trigger synthetic_deadline_delay on ni_security.outbox;drop function public.synthetic_deadline_delay()');}
});
test('invalid internal snapshots deny through the actual audit writer with no state changes',async()=>{
 for(const item of exactNegatives.cases.filter(x=>['credential_grant','tenant_binding','current_projection','journey_link'].includes(x.record_type))){
  const before=await protectedSnapshot();const state=JSON.parse(item.raw);let body,sqlstate;
  if(['credential_grant','tenant_binding'].includes(item.record_type))body={event_type:item.record_type==='credential_grant'?'grant_created':'binding_disabled',grant_id:id(5),tenant_ref:'tenant_test0001',actor:'synthetic-controller',approval_ref:'synthetic-approval',reason:'synthetic-test',after:state};
  else body={event_type:item.record_type==='current_projection'?'projection_changed':'link_changed',record_type:item.record_type,record_key:{id:id(1)},authorization_context:{},outcome:'accepted',[item.record_type==='current_projection'?'after_projection':'after_link']:state};
  await db.exec('set role '+(['credential_grant','tenant_binding'].includes(item.record_type)?'ni_controller_writer':'ni_integrity_writer'));
  try{await assert.rejects(db.query('select ni_security.audit($1::uuid,$2::jsonb)',[id(15),JSON.stringify(body)]),error=>{sqlstate=error.code;return sqlstate==='22023';});}finally{await db.exec('reset role');}
  const after=await protectedSnapshot();assert.deepEqual(after,before,item.id);boundaryEvidence(item.id,'INTERNAL_AUDIT_WRITER',sqlstate,before,after);
 }
});
test('final persisted row validation rolls back authorized ingestion on invalid internal rows',async()=>{
 for(const [table,mutation] of [['edge_intelligence_observations','new.binding_epoch=null;'],['edge_intelligence_current','new.revision=0;'],['edge_intelligence_journey_links','new.linkage_evidence=null;'],['ni_security.audit_events',`new.body=new.body||'{}'::jsonb||jsonb_build_object('unclassified_column',true);`],['ni_security.outbox',`new.event_digest=repeat('f',64);`]]){
  const before=await protectedSnapshot();
  await db.exec(`create function public.synthetic_invalid_row() returns trigger language plpgsql as $$begin ${mutation} return new;end$$;create trigger aa_synthetic_invalid_row before insert on ${table} for each row execute function public.synthetic_invalid_row();`);
  try{await assert.rejects(ingest(payload(4)),error=>['22023','23502'].includes(error.code));assert.deepEqual(await protectedSnapshot(),before,table);}
  finally{await db.exec(`drop trigger aa_synthetic_invalid_row on ${table};drop function public.synthetic_invalid_row();`);}
 }
});
test('application roles cannot reach internal record helpers or audit persistence RPC',async()=>{
 const before=await protectedSnapshot();
 for(const role of ['ni_delivery_executor','service_role','ni_authorization_controller']){
  await db.exec('set role '+role);try{
   await assert.rejects(db.query('select ni_security.digest($1,$2::jsonb)',['observation',exactNegatives.cases[0].raw]),error=>error.code==='42501');
   await assert.rejects(db.query('select ni_security.audit($1::uuid,$2::jsonb)',[id(15),'{}']),error=>error.code==='42501');
  }finally{await db.exec('reset role');}
 }
 assert.deepEqual(await protectedSnapshot(),before);
});
test('every persisted audit body conforms to the frozen manifest and recomputes its digest',async()=>{
 const rows=(await db.query('select body,record_digest from ni_security.audit_events')).rows;
 assert(rows.length>=8);
 for(const r of rows){const kind=r.body.actor_ref?'authorization_audit':'observation_audit';assert.equal(digest(kind,normalizeRecord(kind,r.body)),r.record_digest);}
 const row=(await db.query('select * from edge_intelligence_observations order by revision limit 1')).rows[0];
 const {source_digest,record_digest,...record}=row;
 for(const k of ['observed_at','updated_at_source','received_at'])record[k]=new Date(record[k]).toISOString().replace('.000Z','.000000Z');
 assert.equal(digest('observation',normalizeRecord('observation',record)),record_digest);
});
test('service-role historical writes, proof-free RPC and forged acknowledgement are denied',async()=>{
 await db.exec('set role service_role');try{
  for(const sql of ["update edge_intelligence_observations set payload='{}',payload_hash='fake'",'delete from edge_intelligence_observations','truncate edge_intelligence_observations cascade',"select ingest_edge_intelligence_v1('"+id(2)+"','{}')",'update ni_security.admission set reconciled=true'])await assert.rejects(db.exec(sql));
 }finally{await db.exec('reset role');}
 for(const sql of ["update edge_intelligence_observations set payload='{}'",'delete from edge_intelligence_observations','truncate edge_intelligence_observations cascade'])await assert.rejects(db.exec(sql));
});
test('cross-organization pointer, journey link and organization cascade fail',async()=>{
 const row=(await db.query('select id from edge_intelligence_observations limit 1')).rows[0].id;
 await assert.rejects(db.query("insert into edge_intelligence_current values($1,'tenant_test0001','obs_test0001',$2,1,now())",[id(22),row]));
 await assert.rejects(db.query("insert into edge_intelligence_journey_links(organization_id,observation_row_id,journey_id,linkage_basis) values($1,$2,$3,'session_ref')",[id(2),row,id(99)]));
 await assert.rejects(db.query('delete from tracekit_organizations where id=$1',[id(2)]));
});
test('audit failure rolls back evidence and pointers atomically',async()=>{
 await db.exec(`create function ni_security.test_audit_fail() returns trigger language plpgsql as $$begin raise exception 'synthetic_audit_failure';end$$;create trigger test_fail before insert on ni_security.outbox for each row execute function ni_security.test_audit_fail();`);
 const before=(await db.query('select count(*)::int n from edge_intelligence_observations')).rows[0].n;
 await assert.rejects(ingest(payload(4)));
 assert.equal((await db.query('select count(*)::int n from edge_intelligence_observations')).rows[0].n,before);
 assert.equal((await db.query('select revision from edge_intelligence_current')).rows[0].revision,3);
 await db.exec('drop trigger test_fail on ni_security.outbox');
});
test('destination not provisioned or stale checkpoint stops admission',async()=>{
 await db.exec("update ni_security.admission set checkpoint_at=clock_timestamp()-interval '16 minutes'");await assert.rejects(ingest(payload(4)));
 await db.exec('update ni_security.admission set checkpoint_at=clock_timestamp()');
});
test('governed grant revocation is atomic and application cannot invoke controller',async()=>{
 await db.exec('set role ni_delivery_executor');try{await assert.rejects(db.query('select ni_security.revoke_grant($1,$2,$3)',[id(5),'controller','test']));}finally{await db.exec('reset role');}
 await db.exec('set role ni_authorization_controller');try{await db.query('select ni_security.revoke_grant($1,$2,$3)',[id(5),'controller','test']);}finally{await db.exec('reset role');}
 await assert.rejects(ingest(payload(4)));
});
test('controller cannot silently expand scope or reuse a disabled binding',async()=>{
 await db.exec('set role ni_authorization_controller');try{
  await assert.rejects(db.query('select ni_security.create_grant($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id(55),id(4),'test','tenant_test0001',id(22),id(3),'2030-01-01Z','controller','approved']));
  await db.query('select ni_security.disable_binding($1,$2,$3)',['tenant_test0001','controller','offboard']);
  await assert.rejects(db.query('select ni_security.create_grant($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id(55),id(4),'test','tenant_test0001',id(2),id(3),'2030-01-01Z','controller','approved']));
 }finally{await db.exec('reset role');}
 await assert.rejects(ingest(payload(4)));
 const rows=(await db.query("select body,record_digest from ni_security.audit_events where body?'actor_ref'")).rows;
 for(const row of rows)assert.equal(digest('authorization_audit',normalizeRecord('authorization_audit',row.body)),row.record_digest);
});
test('rollback pauses execution and preserves protected evidence and audit',async()=>{
 const before=(await db.query('select count(*)::int n from ni_security.audit_events')).rows[0].n;
 await db.exec(file('docs/operations/prepared/network-intelligence-pause.sql'));
 await assert.rejects(ingest(payload(4)));
 assert.equal((await db.query('select count(*)::int n from ni_security.audit_events')).rows[0].n,before);
 await db.exec('set role service_role');try{await assert.rejects(db.exec('delete from edge_intelligence_observations'));}finally{await db.exec('reset role');}
});
