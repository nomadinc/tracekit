import assert from 'node:assert/strict';

// Nested JSON prevents pg's timestamptz -> Date conversion. PostgreSQL renders
// all six fractional digits explicitly, including nullable completed_at_source.
export const losslessObservationSql = `
select (to_jsonb(x) - 'source_digest' - 'record_digest') ||
 jsonb_build_object(
  'observed_at', to_char(observed_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
  'updated_at_source', to_char(updated_at_source at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
  'completed_at_source', to_char(completed_at_source at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
  'received_at', to_char(received_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')
 ) as record, record_digest
from public.edge_intelligence_observations x order by revision,id`;

export async function verifyLosslessObservations(client, {digest, normalizeRecord}) {
 const {rows} = await client.query(losslessObservationSql);
 assert(rows.length > 0, 'retained observations required; empty input is not a PASS');
 return rows.map(({record, record_digest}) => {
  for (const key of ['observed_at','updated_at_source','completed_at_source','received_at']) {
   if (key === 'completed_at_source' && record[key] === null) continue;
   assert.match(record[key], /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z$/, key);
  }
  const actual = digest('observation', normalizeRecord('observation', record));
  return {id:record.id, revision:record.revision, received_at:record.received_at,
   expected:record_digest, actual, status:actual === record_digest ? 'PASS' : 'FAIL'};
 });
}
