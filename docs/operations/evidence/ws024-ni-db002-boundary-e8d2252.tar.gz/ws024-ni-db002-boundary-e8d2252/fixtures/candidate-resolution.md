# WS-001 NI-DB-002 boundary resolution

Status: PARTIAL — exact helper discrepancy corrected locally; implemented boundaries exercised; native security acceptance and unimplemented controls remain HOLD.
Base: 55759aa3d9724b49f09850cd3a2d9395471ec51f. Contract unchanged: NI-AUTH-001/Model-B/v1 review-assembly-2.

## Evidence and reproduction

Supplied archive SHA-256 verified: fb55c11ca11fa03f431e9d47cad11fad72b265c15090d04bbd0e77f262bb35e7. All 72 internal file checksums pass. Publication provenance: 4d5a2baf16814db7f60f9c9db59a999a361d53b0. The 32 exact raw JSON strings, record types and REJECT expectations are retained in ui/tests/fixtures/network-security/ws024-exact-negative.json. Original source vectors/assertions remain unchanged.

Against the pre-correction prepared SQL, the new exact-case regression reproduced 0 PASS / 32 FAIL (missing expected rejection) in PGlite. WS-024 supplied native SQLSTATE 00000/digest observations; no new native reproduction is claimed here. These are helper-only baseline facts, not evidence of committed malformed internal records.

## Correction

ni_security.digest now requires ni_security.record_value before framing/hashing named S4 records. Complete SQL manifests reject missing and additional fields, disallowed nulls, wrong JSON types, integer ranges and malformed UUID/hash/environment/reference/timestamp values. SQL NULL is not an optional record. Known generic typed-tree test/payload domains remain generic; they are not used in place of a named persisted record manifest. Source equality still excludes authentication/delivery provenance as specified; original evidence is not rewritten.

Previously omitted auxiliary audit_stream_state, export_state and delivery_envelope schemas are explicit in the TypeScript/SQL manifest inventories. Nested authorization audit states and projection/link snapshots require their corresponding complete manifests. Exact fixtures and positive golden digests continue to pass.

Final-row triggers independently validate observations (including recomputed source and full record digests), current projections, unresolved journey links, grants, bindings and audit records. Audit envelope identity/sequence/previous digest must match the physical row. The current reference outbox requires a matching retained audit event/stream/sequence/digest; this does not pretend its physical reference row is the complete S4 destination outbox body.

The helpers have no application execution grant. The delivery executor/service role cannot invoke the internal audit writer or generic digest directly. ni_authorization_controller can invoke only the governed controller functions, not audit/digest. Internal non-login writer roles perform validation and persistence; they are not delivery credentials. Database owner/superuser DDL/trigger disabling is outside this application's writer-authority guarantee and is not claimed prevented.

## Exact boundary inventory

See ws001-ni-db-002-boundary-matrix.csv for all 32 cases, their record types, validators, writers, caller roles, implementation status and observed local disposition. No internal record object is falsely tested by submitting it as a malformed Edge delivery envelope.

Reachable implemented paths:

- Observation/source evidence/current/unresolved link: proof-aware ingest constructs exact records; mandatory named-record validation precedes digest; final-row guards run before insert/update.
- Grant creation/revocation and binding disable: independently controlled RPCs mutate typed state and emit mandatory validated before/after snapshots through audit. Binding issuance and credential provisioning remain unavailable.
- Authorization/observation audit: internal audit constructs its envelope; named record and nested snapshot validation precede event/outbox/counter writes; final-row envelope and digest guard protects the actual insert.
- Reference outbox and counter: internal audit owns them. Their atomic rollback is tested, but complete S4 outbox destination/export/state serialization remains an explicit implementation gap.

NOT IMPLEMENTED, not PASS: governed credential authorization/commitment provisioning, independent receipt persistence/acknowledgement, durable quarantine receipt storage, export-state writer, complete destination outbox body and full S4 audit-stream state representation. Available pure helpers or verification modules do not establish those missing persisted boundaries. Their activation remains blocked.

## Actual tests and atomicity evidence

1. All 32 exact helper calls under the internal writer role now reject with captured SQLSTATE 22023. Each compares complete sorted-row snapshots of nine tables (the seven WS-024 canonical/audit-state tables plus grants and bindings), including audit sequence and digest. Structured log evidence records before/after SHA-256 for each table and unchanged=true.
2. Exact invalid grant/binding/projection/link snapshots are passed through the real internal audit writer, using the appropriate internal writer role. Each returns 22023 and preserves all nine snapshots. These are internal writer-path tests, not external malformed-delivery tests.
3. Disposable fault-injection triggers corrupt final rows during an otherwise authorized revision delivery: observation null epoch; projection revision zero; link null evidence; extra audit body field; forged outbox event digest. Every delivery rejects and rolls back all protected rows, projections, links, audit/outbox and counter state. Missing/extra checks are at named-record boundaries; physical columns cannot represent unknown keys and must not silently discard them via jsonb_populate_record as a substitute for validation.
4. Direct helper/audit RPC calls by service_role, ni_delivery_executor and ni_authorization_controller return 42501 with unchanged snapshots. Existing scope denial, replay/expiry, immutability and rollback tests remain intact.

Local focused suite: 141 PASS, zero fail/skip. Included WS-023 copies: 11 PASS, zero fail/skip. Focused TypeScript: PASS. Logs are in evidence/network-security/ni-db-002-*. Native-only timeout test is not included in the PGlite count.

Rerun in ui: npm run test:network-security; node --import tsx --test tests/ws023-delivery-verification.test.ts tests/ws023-validator-verification.test.ts; npx tsc --project tsconfig.network-security.json. Native disposable execution uses the explicitly guarded NI_NATIVE_TEST_URL mode documented in ws001-native-validation-corrections.md.

## Remaining acceptance

WS-024 must independently run the original negative runner and these boundary regressions against the exact new candidate using native PostgreSQL. WS-022 determines security acceptance/severity. No claim of independent closure is made. NI-DB-001 cancellation and NI-CRYPTO-001 receipt/trust integration remain separate gates. Complete physical schema/manifest parity and the unimplemented writers above remain activation blockers.

No production schema/grant mutations, credential rotations, canary changes, customer access, merge or deployment. Prepared SQL is outside automatic migrations; versioned production writes remain compile-time disabled. Production V1 HOLD.
