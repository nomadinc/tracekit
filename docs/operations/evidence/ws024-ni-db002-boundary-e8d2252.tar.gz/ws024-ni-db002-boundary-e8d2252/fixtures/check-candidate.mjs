import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFileSync,realpathSync} from 'node:fs';
import {resolve} from 'node:path';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
export function checkCandidate() {
 const candidate = realpathSync(process.env.NI_CANDIDATE_PATH ?? '');
 const sha = process.env.NI_CANDIDATE_SHA ?? '';
 assert.match(sha,/^[a-f0-9]{40}$/, 'explicit immutable NI_CANDIDATE_SHA required');
 const git = (...args) => execFileSync('git',['-C',candidate,...args],{encoding:'utf8'}).trim();
 assert.equal(git('rev-parse','HEAD'),sha,'candidate SHA');
 git('diff','--quiet'); git('diff','--cached','--quiet');
 git('merge-base','--is-ancestor','548bcca0a166b7e2b64f4d86ca5ff15573c5a9df',sha);
 const contractHash = hash(readFileSync(resolve(candidate,'docs/operations/NI-AUTH-001-Model-B-v1-Technical-Specification.md')));
 assert.equal(contractHash,'9a0baa2812a6b4825b1e378f6a695e37458363d8575fbffcf6b8300f8123ca71','frozen contract');
 const original = new URL('../../docs/operations/evidence/ws024-native-completion/vectors.json',import.meta.url);
 const vectorBytes = readFileSync(original);
 assert.equal(hash(readFileSync(resolve(candidate,'ui/tests/fixtures/network-security/vectors.json'))),hash(vectorBytes),'original vectors must remain exact');
 const databaseUrl = new URL(process.env.NI_NATIVE_TEST_URL ?? '');
 assert(['postgres:','postgresql:'].includes(databaseUrl.protocol),'PostgreSQL URL required');
 assert(['localhost','127.0.0.1','[::1]'].includes(databaseUrl.hostname),'loopback only');
 assert.match(databaseUrl.pathname,/^\/ni_disposable_[a-z0-9_]+$/,'disposable database required');
 assert(!databaseUrl.search && !databaseUrl.hash,'no URL parameters or fragment');
 return {candidate,sha,contractHash,vectorHash:hash(vectorBytes),databaseUrl,
  vectors:JSON.parse(vectorBytes)};
}
